import io
import imaplib
import json
import os
import socket
import sys
import tempfile
import time
import unittest
import urllib.error
import zipfile
from datetime import datetime, timezone
from email.message import EmailMessage
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import maildesk as app


class FakeIMAP:
    fetch_calls = 0
    header_calls = 0
    def __init__(self, host, port):
        self.host, self.port = host, port
    def login(self, user, password):
        assert user == "martin@tabal.pl"
    def select(self, mailbox, readonly=False):
        assert readonly is True
        return "OK", [b"1"]
    def uid(self, action, *args):
        if action == "search":
            return "OK", [b"101"]
        assert args[-1] in ("(BODY.PEEK[])", "(BODY.PEEK[] INTERNALDATE)", "(BODY.PEEK[HEADER] INTERNALDATE)")
        if args[-1] in ("(BODY.PEEK[])", "(BODY.PEEK[] INTERNALDATE)"):
            FakeIMAP.fetch_calls += 1
        else:
            FakeIMAP.header_calls += 1
        msg = EmailMessage()
        msg["From"] = "Klient <klient@example.org>"
        msg["To"] = "martin@tabal.pl"
        msg["Subject"] = "Oferta tablic"
        msg["Message-ID"] = "<mail-101@example.org>"
        msg["Date"] = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
        msg.set_content("Proszę o ofertę do piątku")
        return "OK", [(b"1 (BODY[] {100}", msg.as_bytes())]
    def logout(self):
        pass


class FakeSMTP:
    sent = []
    def __init__(self, host, port, timeout):
        assert (host,port) == ("smtp.example.org",587)
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def starttls(self,context): pass
    def login(self,user,password):
        assert user == "martin@tabal.pl"
    def send_message(self,msg):
        self.sent.append(msg)


class FakeResponse:
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def read(self,*args): return self.blob


class MailDeskTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ,{
            "TABAL_LOGIN":"martin@tabal.pl","TABAL_PASSWORD":"fake-test-password",
            "TABAL_IMAP_HOST":"imap.example.org","TABAL_SMTP_HOST":"smtp.example.org",
            "TABAL_SMTP_PORT":"587","TABAL_SMTP_SECURITY":"starttls",
            "OPENAI_API_KEY":"fake-test-key"})
        self.env.start()
        FakeIMAP.fetch_calls = 0
        FakeIMAP.header_calls = 0
        FakeSMTP.sent = []
        app.JOBS.clear()
        app.DOCUMENT_JOBS.clear()
    def tearDown(self):
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()

    def test_full_flow_and_no_duplicate_send(self):
        first = app.sync_account("tabal", FakeIMAP)
        second = app.sync_account("tabal", FakeIMAP)
        self.assertEqual(first["imported"],1)
        self.assertEqual(second["skipped"],1)
        self.assertEqual(FakeIMAP.fetch_calls,1)
        self.assertEqual(FakeIMAP.header_calls,0)
        with app.connect() as db:
            row = db.execute("SELECT * FROM messages").fetchone()
            message_id = row["id"]
        app.analyze(message_id,"demo")
        with self.assertRaises(ValueError):
            app.send_mail(message_id,"klient@example.org","Treść",False,FakeSMTP)
        result = app.send_mail(message_id,"klient@example.org","Odpowiedź testowa",True,FakeSMTP)
        self.assertEqual(result["from"],"martin@tabal.pl")
        self.assertEqual(len(FakeSMTP.sent),1)
        self.assertEqual(FakeSMTP.sent[0]["In-Reply-To"],"<mail-101@example.org>")
        with self.assertRaises(ValueError):
            app.send_mail(message_id,"klient@example.org","Ponownie",True,FakeSMTP)

    def test_demo_messages_cannot_send(self):
        app.demo_seed()
        with app.connect() as db:
            row = db.execute("SELECT id FROM messages LIMIT 1").fetchone()
        app.analyze(row["id"],"demo")
        with self.assertRaisesRegex(ValueError,"Przykładowe"):
            app.send_mail(row["id"],"klient@example.org","Szkic",True,FakeSMTP)
        self.assertFalse(FakeSMTP.sent)

    def test_api_analysis_structured_response_and_untrusted_email(self):
        app.sync_account("tabal",FakeIMAP)
        with app.connect() as db:
            row = dict(db.execute("SELECT * FROM messages").fetchone())
        expected = {"category":"Zapytanie","priority":"wysoki","summary":"Prośba o ofertę",
                    "action":"Przygotować ofertę","due":"piątek","draft":"Dzień dobry..."}
        output = {"output":[{"content":[{"type":"output_text","text":json.dumps(expected)}]}]}
        def fake_open(request,timeout):
            self.assertEqual(request.full_url,"https://api.openai.com/v1/responses")
            body = json.loads(request.data)
            self.assertFalse(body["store"])
            self.assertEqual(body["text"]["format"]["type"],"json_schema")
            response = FakeResponse()
            response.blob = json.dumps(output).encode()
            return response
        result = app.ai_analysis(row, fake_open)
        self.assertEqual(result,expected)

    def test_project_date_company_sync_and_question_history(self):
        today = app.date.today().isoformat()
        project = app.create_project("Klient Example",today,today,"example.org","tabal")
        result = app.sync_project_account(project["id"],"tabal",FakeIMAP)
        self.assertEqual((result["checked"],result["added"]),(1,1))
        self.assertEqual(app.sync_project_account(project["id"],"tabal",FakeIMAP)["added"],0)
        answer = app.ask_project(project["id"],"Jaka oferta i termin?","local")
        self.assertIn("Oferta tablic",answer["answer"])
        self.assertEqual(len(answer["sources"]),1)
        saved = app.project_data(project["id"])
        self.assertEqual(saved["history"][0]["question"],"Jaka oferta i termin?")
        self.assertEqual(saved["messages"][0]["account"],"tabal")
        self.assertTrue(app.sender_matches("Firma ABC <zakupy@abc.pl>","ABC"))
        self.assertFalse(app.sender_matches("Firma ABC <zakupy@abc.pl>","Inna"))

    def test_date_filter_and_error_log_redacts_password(self):
        old = (app.date.today()-app.timedelta(days=3)).isoformat()
        project = app.create_project("Stary projekt",old,old,"","tabal")
        result = app.sync_project_account(project["id"],"tabal",FakeIMAP)
        self.assertEqual(result["added"],0)  # server mocked; header date still checked locally
        class BrokenIMAP(FakeIMAP):
            def login(self,user,password):
                raise imaplib.IMAP4.error("LOGIN failed: " + password)
        with self.assertRaises(imaplib.IMAP4.error):
            app.sync_project_account(project["id"],"tabal",BrokenIMAP)
        with app.connect() as db:
            detail = db.execute("SELECT detail FROM mail_errors ORDER BY id DESC LIMIT 1").fetchone()[0]
        self.assertIn("[REDACTED]",detail)
        self.assertNotIn("fake-test-password",detail)
        self.assertIn("odrzucił login lub hasło",app.sync_error_message(
            imaplib.IMAP4.error("[AUTHENTICATIONFAILED] Authentication failed.")))
        self.assertNotIn("fake-test-password",app.sync_error_message(
            RuntimeError("server error: fake-test-password")))

    def test_demo_project_and_both_mail_smtp_config(self):
        today=app.date.today().isoformat()
        project=app.create_project("Pokaz",today,today,"","both")
        self.assertEqual(app.add_demo_to_project(project["id"])["added"],3)
        self.assertEqual(len(app.project_data(project["id"])["messages"]),3)
        with patch.dict(os.environ,{"TABAL_SMTP_PORT":"465","TABAL_SMTP_SECURITY":"ssl"}):
            cfg=app.env_account("tabal")
            self.assertEqual((cfg["smtp_port"],cfg["smtp_security"]),(465,"ssl"))
        sky=app.env_account("skyfens")
        self.assertEqual((sky["imap_host"],sky["smtp_port"],sky["smtp_security"]),
                         ("mail.skyfens.pl",587,"starttls"))

    def test_imap_connection_check_separates_network_and_login(self):
        class GoodIMAP:
            def __init__(self,host,port,timeout):
                self.assertion = (host,port,timeout)
            def login(self,user,password):
                self.user = user
            def logout(self): pass
        good=app.check_imap_account("tabal",GoodIMAP)
        self.assertTrue(good["ok"])
        self.assertEqual(good["stage"],"login")
        class RejectedIMAP(GoodIMAP):
            def login(self,user,password):
                raise imaplib.IMAP4.error("[AUTHENTICATIONFAILED] " + password)
        rejected=app.check_imap_account("tabal",RejectedIMAP)
        self.assertEqual(rejected["stage"],"login")
        self.assertNotIn("fake-test-password",rejected["message"])
        def no_dns(host,port,timeout):
            raise socket.gaierror(-3,"temporary DNS error")
        network=app.check_imap_account("tabal",no_dns)
        self.assertEqual(network["stage"],"connection")
        self.assertIn("DNS",network["message"])
        with app.connect() as db:
            detail=db.execute("SELECT detail FROM mail_errors WHERE operation='IMAP login test'").fetchone()[0]
        self.assertNotIn("fake-test-password",detail)

    def test_ai_check_separates_invalid_key_and_billing(self):
        def error_response(http_status, error_code):
            blob=io.BytesIO(json.dumps({"error":{"code":error_code}}).encode())
            return urllib.error.HTTPError("https://api.openai.com/v1/responses",http_status,"failure",{},blob)
        def invalid(request,timeout):
            self.assertEqual(json.loads(request.data)["model"],"gpt-4.1-mini")
            raise error_response(401,"invalid_api_key")
        failed=app.check_ai(invalid)
        self.assertEqual(failed["stage"],"key")
        self.assertIn("HTTP 401",failed["message"])
        def no_credit(request,timeout):
            raise error_response(429,"credit_balance_exhausted")
        billing=app.check_ai(no_credit)
        self.assertEqual(billing["stage"],"billing")
        self.assertIn("HTTP 429",billing["message"])
        def success(request,timeout):
            response=FakeResponse()
            response.blob=json.dumps({"status":"completed","model":"gpt-4.1-mini",
                "output":[{"content":[{"type":"output_text","text":"OK"}]}]}).encode()
            return response
        self.assertTrue(app.check_ai(success)["ok"])

    def test_project_ai_answer_uses_only_eligible_sources(self):
        today=app.date.today().isoformat()
        project=app.create_project("Źródła",today,today,"","tabal")
        app.sync_project_account(project["id"],"tabal",FakeIMAP)
        m=app.project_data(project["id"])["messages"][0]
        output={"output":[{"content":[{"type":"output_text","text":json.dumps({
            "answer":"Termin to piątek.","source_ids":[m["id"],999999]})}]}]}
        def fake_open(request,timeout):
            body=json.loads(request.data)
            self.assertFalse(body["store"])
            self.assertIn(str(m["id"]),body["input"])
            response=FakeResponse()
            response.blob=json.dumps(output).encode()
            return response
        answer, ids=app.answer_with_ai("Jaki termin?",[m],fake_open)
        self.assertIn("piątek",answer)
        self.assertEqual(ids,[m["id"]])

    def test_setup_saves_company_credentials_and_api_key_locally(self):
        with patch.object(app,"ROOT",Path(self.temp.name)):
            with self.assertRaisesRegex(ValueError,"@tabal.pl"):
                app.save_account_settings("tabal","someone@gmail.com","secret")
            result=app.save_account_settings("tabal","gbartosik@tabal.pl","test=secret")
            self.assertEqual(result,{"saved":True,"account":"tabal"})
            app.save_account_settings("tabal","gbartosik@tabal.pl","")
            api_key="sk-proj-"+"x"*40
            self.assertEqual(app.save_ai_settings(api_key)["model"],"gpt-4.1-mini")
            cfg=Path(self.temp.name)/".env.local"
            contents=cfg.read_text()
            self.assertEqual(contents.count("TABAL_PASSWORD="),1)
            self.assertIn("TABAL_PASSWORD=test=secret",contents)
            self.assertIn("OPENAI_API_KEY="+api_key,contents)
            self.assertEqual(cfg.stat().st_mode & 0o777,0o600)
            self.assertNotIn("test=secret",app.redact_secrets("failed test=secret"))
            self.assertNotIn(api_key,app.redact_secrets("failed "+api_key))
            self.assertEqual(set(app.ACCOUNTS),{"tabal","skyfens"})

    def test_switching_mailbox_login_cannot_mix_cached_messages(self):
        app.sync_account("tabal",FakeIMAP)
        with self.assertRaisesRegex(ValueError,"osobnym folderze"):
            app.save_account_settings("tabal","gbartosik@tabal.pl","different-password")
        self.assertEqual(app.env_account("tabal")["login"],"martin@tabal.pl")

    def test_many_years_partial_sender_failed_uid_and_full_project_search(self):
        class ManyIMAP:
            full_fetches = 0
            def __init__(self,host,port): pass
            def login(self,user,password): pass
            def select(self,name,readonly=False): return "OK",[b"300"]
            def uid(self, action, *args):
                if action == "search": return "OK",[b" ".join(str(i).encode() for i in range(1,301))]
                uid=int(args[0]); spec=args[1]
                if uid == 137 and spec == "(BODY.PEEK[] INTERNALDATE)": return "NO",[]
                msg=EmailMessage()
                msg["From"]=("Peter Bauer" if uid<=260 else "Inny Klient")+" <pb@example.org>"
                msg["To"]="martin@tabal.pl"
                msg["Subject"]="kontrakt archeologiczny" if uid==1 else "Oferta nr "+str(uid)
                msg["Date"]="Mon, 01 Oct 2012 10:00:00 +0000"
                msg.set_content("Szczegóły współpracy " + str(uid))
                if spec=="(BODY.PEEK[] INTERNALDATE)": ManyIMAP.full_fetches+=1
                return "OK",[(b'1 (INTERNALDATE "01-Oct-2012 10:00:00 +0000")',msg.as_bytes())]
            def logout(self): pass
        project=app.create_project("Wiele lat","2012-01-01",app.date.today().isoformat(),"baue","tabal")
        result=app.sync_project_account(project["id"],"tabal",ManyIMAP)
        self.assertEqual((result["available"],result["checked"],result["added"],result["failed"]),(300,300,259,1))
        # 5.2 deliberately indexes every message in the selected date range once,
        # even if the project filter does not match, so later people/company
        # searches can reuse the local archive without another full download.
        self.assertEqual(ManyIMAP.full_fetches,299)
        first=app.project_data(project["id"])
        self.assertEqual((first["total_messages"],len(first["messages"])),(259,50))
        self.assertEqual(len(app.project_data(project["id"],200)["messages"]),50)
        answer=app.ask_project(project["id"],"kontrakt archeologiczny","local")
        self.assertIn("kontrakt archeologiczny",answer["answer"])
        with app.connect() as db:
            errors=db.execute("SELECT operation FROM mail_errors").fetchall()
        self.assertTrue(any("137" in x[0] for x in errors))
        self.assertTrue(app.sender_matches("Piotr Łęcki <sprzedaz@tabal.pl>","lecki"))
        self.assertTrue(app.sender_matches("Peter Bauer <pb@example.org>","pb@exa"))

    def test_all_folders_cc_company_attachment_index_and_hidden_message_list(self):
        today=datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
        class FolderIMAP:
            def __init__(self,host,port): self.folder="INBOX"
            def login(self,user,password): pass
            def list(self):
                return "OK",[b'(\\HasNoChildren) "/" "INBOX"',
                             b'(\\Sent \\HasNoChildren) "/" "Sent"',
                             b'(\\Trash \\HasNoChildren) "/" "Trash"']
            def select(self,name,readonly=False): self.folder=name; return "OK",[b"1"]
            def uid(self,action,*args):
                if action=="search": return "OK",[b"11" if self.folder=="INBOX" else b"22"]
                uid=int(args[0]); spec=args[1]
                msg=EmailMessage()
                if self.folder=="INBOX":
                    msg["From"]="Losowy <x@example.org>"; msg["To"]="martin@tabal.pl"
                    msg["Subject"]="Inny temat"; msg.set_content("Bez związku")
                else:
                    msg["From"]="martin@tabal.pl"
                    msg["To"]="Agnieszka Kafel <agnieszka.kafel@comarch.pl>"
                    msg["Cc"]="Biuro COMARCH <biuro@comarch.pl>"
                    msg["Subject"]="Oferta analityczna"
                    msg.set_content("Ustalenia dotyczące szkolenia")
                    msg.add_attachment(b"sekretny kod: ALFA-2042",maintype="text",subtype="plain",filename="ustalenia.txt")
                msg["Message-ID"]=f"<{self.folder}-{uid}@example.org>"; msg["Date"]=today
                meta=f'1 (INTERNALDATE "{datetime.now(timezone.utc).strftime("%d-%b-%Y %H:%M:%S +0000")}")'.encode()
                return "OK",[(meta,msg.as_bytes())]
            def logout(self): pass
        project=app.create_project("COMARCH",app.date.today().isoformat(),app.date.today().isoformat(),"comarch","tabal")
        result=app.sync_project_account(project["id"],"tabal",FolderIMAP)
        self.assertEqual(result["imported"],2)
        self.assertEqual(result["added"],1)
        self.assertEqual([x["folder"] for x in result["folders"]],["INBOX","Sent"])
        compact=app.project_data(project["id"],include_messages=False)
        self.assertEqual(compact["messages"],[])
        self.assertEqual(compact["total_messages"],1)
        self.assertEqual(compact["stats"]["attachments"],1)
        self.assertEqual(compact["stats"]["indexed_attachments"],1)
        answer=app.ask_project(project["id"],"sekretny kod ALFA-2042","local")
        self.assertTrue(answer["sources"])
        with app.connect() as db:
            entities=[r[0] for r in db.execute("SELECT normalized FROM message_entities WHERE normalized LIKE '%comarch%'")]
        self.assertTrue(entities)

    def test_universal_archive_search_across_initial_project_filter(self):
        today=app.date.today().isoformat()
        project=app.create_project("Leonardo",today,today,"Leonardo","tabal")
        self.assertTrue(app.project_query_matches({
            "sender":"Leonardo Ruiz <leonardo@empresa.es>", "recipient":"", "cc":"",
            "subject":"Oferta", "body":"Buenos días", "attachments":"[]"},"leonardo@empresa | BAUER"))
        with app.connect() as db:
            message={"message_id":"<leo@empresa.es>","sender":"Leonardo Ruiz <leo@empresa.es>",
                     "recipient":"martin@tabal.pl","cc":"","subject":"Oferta projektowa",
                     "received":today,"body":"Propuesta de proyecto", "attachments":"[]"}
            mid,_=app.save_message(db,"tabal","leo-test","INBOX",message)
            db.execute("INSERT INTO project_messages(project_id,message_id) VALUES (?,?)",(project["id"],mid))
            other=dict(message,message_id="<bauer@example.org>",sender="Peter Bauer <pb@example.org>",
                       subject="Raport techniczny",body="Ustalenia i wycena",attachments='["ceny.xlsx"]')
            other_id,_=app.save_message(db,"tabal","bauer-test","INBOX",other)
            app.index_attachment_record(db,other_id,0,"ceny.xlsx","Koszt montażu ogrodzenia", "text/plain",30)
            outside=dict(other,message_id="<outside@example.org>",received="2010-01-01",sender="Anna <anna@example.org>")
            app.save_message(db,"tabal","outside-test","INBOX",outside)
        self.assertEqual(app.search_archive(project["id"],"leo@empresa")["total"],1)
        self.assertEqual(app.search_archive(project["id"],'"oferta projektowa"')["messages"][0]["id"],mid)
        self.assertEqual(app.search_archive(project["id"],"bau")["messages"][0]["id"],other_id)
        self.assertEqual(app.search_archive(project["id"],"Leonardo | Bauer")["total"],2)
        self.assertEqual(app.search_archive(project["id"],"Leonardo Bauer")["total"],0)
        self.assertEqual(app.search_archive(project["id"],"montażu ogrodz")["messages"][0]["id"],other_id)
        self.assertEqual(app.search_archive(project["id"],"anna")["total"],0)
        with self.assertRaises(ValueError): app.search_archive(project["id"],'"niedomknięta')
        with self.assertRaises(ValueError): app.search_archive(project["id"],"A |")

    def test_archive_search_post_endpoint_and_pagination(self):
        today=app.date.today().isoformat()
        project=app.create_project("Archiwum",today,today,"Inny filtr","tabal")
        with app.connect() as db:
            for i in range(56):
                m={"message_id":f"<m{i}@example.org>","sender":"Klient <klient@example.org>",
                   "recipient":"martin@tabal.pl","cc":"","subject":f"Projekt {i}",
                   "received":today,"body":"Kod ALFA-2042", "attachments":"[]"}
                app.save_message(db,"tabal",str(800+i),"INBOX",m)
        first=app.search_archive(project["id"],"alfa-2042")
        self.assertEqual((first["total"],len(first["messages"])),(56,50))
        self.assertEqual(len(app.search_archive(project["id"],"alfa-2042",50)["messages"]),6)
        payload=json.dumps({"id":project["id"],"query":"@example.org | ALFA-2042","offset":50}).encode()
        handler=app.Handler.__new__(app.Handler)
        handler.headers={"Host":"127.0.0.1:8765","Content-Length":str(len(payload))}
        handler.path="/api/project/search"
        handler.rfile=io.BytesIO(payload)
        replies=[]
        handler.json_response=lambda status,data: replies.append((status,data))
        handler.do_POST()
        self.assertEqual(replies[0][0],200)
        result=replies[0][1]
        self.assertEqual((result["total"],len(result["messages"])),(56,6))

    def test_folder_parser_excludes_trash_junk_and_drafts(self):
        class Listing:
            def list(self): return "OK",[
                b'(\\HasNoChildren) "/" "INBOX"', b'(\\Sent) "/" "Sent Items"',
                b'(\\Trash) "/" "Trash"', b'(\\Junk) "/" "Junk"', b'(\\Drafts) "/" "Drafts"']
        self.assertEqual(app.list_mail_folders(Listing()),["INBOX","Sent Items"])

    def test_attachment_read_index_and_download_source(self):
        doc=io.BytesIO()
        with zipfile.ZipFile(doc,"w") as archive:
            archive.writestr("word/document.xml",'<w:document xmlns:w="x"><w:body><w:p><w:r><w:t>Termin targów 2030</w:t></w:r></w:p></w:body></w:document>')
        msg=EmailMessage()
        msg["From"]="Klient <klient@example.org>"
        msg["To"]="martin@tabal.pl"
        msg["Subject"]="Oferta"
        msg.set_content("Treść główna")
        msg.add_attachment(doc.getvalue(),maintype="application",subtype="vnd.openxmlformats-officedocument.wordprocessingml.document",filename="oferta.docx")
        raw=msg.as_bytes()
        class AttachedIMAP:
            def __init__(self,host,port): pass
            def login(self,user,password): pass
            def select(self,name,readonly=False): return "OK",[b"1"]
            def uid(self,action,*args):
                if action=="search": return "OK",[b"501"]
                return "OK",[(b"data",raw)]
            def logout(self): pass
        project=app.create_project("Załączniki",app.date.today().isoformat(),app.date.today().isoformat(),"klient","tabal")
        app.sync_project_account(project["id"],"tabal",AttachedIMAP)
        m=app.project_data(project["id"])["messages"][0]
        self.assertEqual(m["attachments"],["oferta.docx"])
        name,mime,blob=app.attachment_bytes(m["id"],0,AttachedIMAP)
        self.assertEqual((name,blob),("oferta.docx",doc.getvalue()))
        extracted=app.index_attachment(m["id"],0,AttachedIMAP)
        self.assertIn("Termin targów",extracted["text"])
        self.assertIn("Termin targów",app.attachment_text(m["id"],0)["text"])
        answer=app.ask_project(project["id"],"targów 2030","local")
        self.assertIn("targów",answer["answer"])

    def test_xlsx_shared_strings_and_pdf_text(self):
        sheet=io.BytesIO()
        with zipfile.ZipFile(sheet,"w") as archive:
            archive.writestr("xl/sharedStrings.xml",'<sst xmlns="x"><si><t>Grzegorz oferta</t></si></sst>')
            archive.writestr("xl/worksheets/sheet1.xml",'<worksheet xmlns="x"><sheetData><row><c t="s"><v>0</v></c><c><v>2027</v></c></row></sheetData></worksheet>')
        self.assertIn("Grzegorz oferta",app.extract_document("ceny.xlsx","application/octet-stream",sheet.getvalue()))
        try:
            from reportlab.pdfgen import canvas
            import pypdf
        except ImportError:
            return  # PDF dependency is installed by the launch script; XLSX still tested.
        pdf=io.BytesIO()
        c=canvas.Canvas(pdf)
        c.drawString(50,750,"Termin umowy 2027")
        c.save()
        self.assertIn("Termin umowy 2027",app.extract_document("umowa.pdf","application/pdf",pdf.getvalue()))

    def test_bulk_document_index_is_explicit_and_reports_progress(self):
        today=app.date.today().isoformat()
        project=app.create_project("Z dokumentami",today,today,"","tabal")
        with app.connect() as db:
            cur=db.execute("""INSERT INTO messages(account,uid,message_id,sender,recipient,subject,received,body,attachments)
                VALUES (?,?,?,?,?,?,?,?,?)""",("tabal","600","<600>","A <a@example.org>","martin@tabal.pl","Test",today,"Opis",'["plik.txt"]'))
            message_id=cur.lastrowid
            db.execute("INSERT INTO project_messages(project_id,message_id) VALUES (?,?)",(project["id"],message_id))
        with patch.object(app,"index_attachment",return_value={"indexed":True}) as mocked:
            app.start_document_index(project["id"])
            for _ in range(100):
                if not app.DOCUMENT_JOBS[project["id"]]["running"]: break
                time.sleep(.01)
            job=app.DOCUMENT_JOBS[project["id"]]
            self.assertFalse(job["running"])
            self.assertEqual((job["checked"],job["indexed"],job["total"]),(1,1,1))
            mocked.assert_called_once_with(message_id,0)


class SearchEngine55Tests(unittest.TestCase):
    """Mail Desk 5.5: fast SQL search, dates, fields, inflection, batch IMAP."""
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ,{"TABAL_LOGIN":"martin@tabal.pl","TABAL_PASSWORD":"fake-test-password",
                                          "TABAL_IMAP_HOST":"imap.example.org"})
        self.env.start()
        self.project = app.create_project("Szukanie","2023-01-01",app.date.today().isoformat(),"","tabal")
        self.ids = {}
        mails = [
            ("kow", "Jan Kowalski <jan@budimex.pl>", "Oferta na ogrodzenie", "2024-03-05T10:00:00+01:00",
             "Dzień dobry,\nprzesyłam ofertę na\nogrodzenie panelowe dla Pana Nowakowskiego.", "[]"),
            ("dat", "Biuro <biuro@stal.pl>", "Potwierdzenie", "Mon, 15 Jan 2024 09:00:00 +0100",
             "W imieniu Kowalskiego potwierdzam termin montażu w Łodzi.", "[]"),
            ("bau", "Peter Bauer <pb@bauer-zaun.de>", "Faktura 12/2024", "2024-06-20T08:00:00+02:00",
             "Rechnung im Anhang. Faktura do zapłaty.", '["cennik_2024.xlsx"]'),
            ("old", "Anna Zielińska <anna@zielinska.pl>", "Stara sprawa", "2023-02-01T08:00:00+01:00",
             "Spotkanie w sprawie bramy.", "[]"),
        ]
        with app.connect() as db:
            for key, sender, subject, received, body, files in mails:
                m = {"message_id":f"<{key}@t>","sender":sender,"recipient":"Grzegorz <gbartosik@tabal.pl>",
                     "cc":"Kierownik Budowy <kb@comarch.pl>" if key=="kow" else "","subject":subject,
                     "received":received,"body":body,"attachments":files}
                self.ids[key], _ = app.save_message(db,"tabal",key,"INBOX",m)
            app.index_attachment_record(db,self.ids["bau"],0,"cennik_2024.xlsx","Panel ogrodzeniowy antracyt 120 zł")
    def tearDown(self):
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()
    def search(self, query, **kw):
        return app.search_archive(self.project["id"], query, **kw)
    def found(self, query, **kw):
        return {m["id"] for m in self.search(query, **kw)["messages"]}

    def test_inflection_finds_polish_forms_and_can_be_disabled(self):
        self.assertEqual(self.found("Kowalski"), {self.ids["kow"], self.ids["dat"]})
        self.assertEqual(self.found("Kowalskiemu"), {self.ids["kow"], self.ids["dat"]})
        self.assertEqual(self.found("Kowalskiemu", inflect=False), set())
        self.assertEqual(self.found("ogrodzenia", inflect=False), set())
        self.assertEqual(self.found("Łódź"), {self.ids["dat"]})  # Łodzi; accents ignored
        self.assertEqual(self.found("lodz"), {self.ids["dat"]})
        self.assertIn(self.ids["kow"], self.found("ogrodzenia"))

    def test_phrase_matches_across_line_breaks(self):
        self.assertEqual(self.found('"ofertę na ogrodzenie"'), {self.ids["kow"]})

    def test_fields_and_exclusion(self):
        self.assertEqual(self.found("od:kowalski"), {self.ids["kow"]})
        self.assertEqual(self.found("do:comarch"), {self.ids["kow"]})
        self.assertEqual(self.found("temat:faktura"), {self.ids["bau"]})
        self.assertEqual(self.found("plik:cennik"), {self.ids["bau"]})
        self.assertEqual(self.found("antracyt"), {self.ids["bau"]})  # attachment text
        self.assertEqual(self.found("kowalski -montaz"), {self.ids["kow"]})
        self.assertEqual(self.found("https://x.pl"), set())  # unknown prefix stays plain text

    def test_dates_from_fields_operators_and_empty_query(self):
        self.assertEqual(self.found("", date_from="2024-01-01", date_to="2024-03-31"),
                         {self.ids["kow"], self.ids["dat"]})
        self.assertEqual(self.found("kowalski data:2024-01"), {self.ids["dat"]})
        self.assertEqual(self.found("od:2024-03-01 do:2024-12-31"), {self.ids["kow"], self.ids["bau"]})
        self.assertEqual(self.found("brama"), {self.ids["old"]})
        self.assertEqual(self.found("brama", date_from="2024-01-01", date_to=""), set())
        result = self.search("", date_from="", date_to="")
        self.assertEqual(result["total"], 4)
        self.assertEqual([m["id"] for m in result["messages"]][0], self.ids["bau"])  # newest first
        with self.assertRaises(ValueError):
            app.search_archive(self.project["id"], "x | ")
        with self.assertRaises(ValueError):
            app.search_archive(self.project["id"], "", date_from="2024-05-01", date_to="2024-01-01")

    def test_result_has_highlighted_snippet_and_place_of_match(self):
        hit = next(m for m in self.search("lodz")["messages"])
        self.assertEqual(hit["snippet"]["match"], "Łodz")
        self.assertIn("treść", hit["found_in"])
        hit = self.search("antracyt")["messages"][0]
        self.assertTrue(any(x.startswith("załącznik") for x in hit["found_in"]))
        self.assertEqual(hit["snippet"]["match"], "antracyt")
        hit = self.search("kowalski")["messages"][0]
        self.assertTrue(hit["day"])

    def test_question_dates(self):
        today = app.date(2026, 10, 9)
        self.assertEqual(app.question_dates("Co pisał Kowalski w marcu 2024?", today)[:2], ("2024-03-01","2024-03-31"))
        self.assertEqual(app.question_dates("maile od 2023 do 2024", today)[:2], ("2023-01-01","2024-12-31"))
        self.assertEqual(app.question_dates("termin 15.03.2024", today)[:2], ("2024-03-15","2024-03-15"))
        self.assertEqual(app.question_dates("oferty w zeszłym roku", today)[:2], ("2025-01-01","2025-12-31"))
        self.assertEqual(app.question_dates("cena 1999 zł za bramę", today)[:2], ("",""))
        self.assertEqual(app.question_dates("zamówienie ZAM-2024/15", today)[:2], ("",""))

    def test_chat_uses_dates_and_inflection(self):
        app.relink_project(self.project["id"])
        answer = app.ask_project(self.project["id"], "Co pisał Kowalskiemu biuro w styczniu 2024?", "local")
        self.assertEqual(answer["sources"][0], self.ids["dat"])
        self.assertEqual(answer["date_from"], "2024-01-01")
        self.assertIn("styczeń" if False else "2024-01-01", answer["answer"])
        count = app.ask_project(self.project["id"], "Ile maili od Kowalskiego?", "local")
        self.assertEqual(count["match_count"], 2)

    def test_project_filter_is_applied_in_sql(self):
        p = app.create_project("Bauer", "2024-01-01", "2024-12-31", "bauer | comarch", "tabal")
        self.assertEqual(p["local_messages"], 2)  # 5.6: filled from the local archive at once
        self.assertEqual(app.relink_project(p["id"]), 0)

    def test_old_database_is_migrated(self):
        with app.connect() as db:
            db.execute("""INSERT INTO messages(account,uid,message_id,sender,recipient,subject,received,body,attachments)
                          VALUES ('tabal','legacy','<l>','Stary <s@x.pl>','g@tabal.pl','Archiwum',
                          'Wed, 03 Apr 2024 10:00:00 +0200','Umowa ramowa z 2019','[]')""")
            db.execute("CREATE VIRTUAL TABLE search_documents USING fts5(content)")
        self.assertEqual(app.migrate_search_index(progress=None), 1)
        self.assertEqual(self.search('"umowa ramowa"')["total"], 1)
        with app.connect() as db:
            self.assertIsNone(db.execute("SELECT 1 FROM sqlite_master WHERE name='search_documents'").fetchone())
            self.assertEqual(db.execute("SELECT received_day FROM messages WHERE uid='legacy'").fetchone()[0], "2024-04-03")


class Imap55Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ,{"TABAL_LOGIN":"martin@tabal.pl","TABAL_PASSWORD":"fake-test-password",
                                          "TABAL_IMAP_HOST":"imap.example.org"})
        self.env.start()
    def tearDown(self):
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()

    def test_folder_names_quoting_decoding_and_name_exclusion(self):
        self.assertEqual(app.quote_mailbox("INBOX"), "INBOX")
        self.assertEqual(app.quote_mailbox("Sent Items"), '"Sent Items"')
        self.assertEqual(app.imap_utf7_decode("INBOX.Wys&AUI-ane"), "INBOX.Wysłane")
        self.assertEqual(app.imap_utf7_decode("Elementy usuni&ARk-te"), "Elementy usunięte")
        class Listing:
            def list(self): return "OK",[b'(\\HasNoChildren) "." "INBOX"', b'(\\HasNoChildren) "." "INBOX.Trash"',
                                         b'(\\HasNoChildren) "." "INBOX.Kosz"', b'(\\HasNoChildren) "." "INBOX.Wys&AUI-ane"',
                                         b'(\\HasNoChildren) "." "INBOX.Spam"']
        self.assertEqual(app.list_mail_folders(Listing()), ["INBOX","INBOX.Wys&AUI-ane"])

    def test_batch_download_size_check_and_duplicate_copies(self):
        def mail(uid, size_pad=0):
            m = EmailMessage()
            m["From"] = "Klient <k@firma.pl>"; m["To"] = "martin@tabal.pl"
            m["Subject"] = f"Wiadomość {uid}"; m["Message-ID"] = f"<{uid % 100}@firma.pl>"
            m["Date"] = "Tue, 05 Mar 2024 10:00:00 +0100"
            m.set_content("Treść " + str(uid) + "x" * size_pad)
            return m.as_bytes()
        folders = {"INBOX": {str(u): mail(u) for u in range(1, 51)},
                   "Sent Items": {"7": mail(7)}}  # identical copy of INBOX 7 -> stored once
        folders["INBOX"]["50"] = mail(50)
        class BatchIMAP:
            commands = []
            def __init__(self, host, port): self.folder = None
            def login(self, u, p): pass
            def list(self): return "OK",[b'(\\HasNoChildren) "/" "INBOX"', b'(\\Sent) "/" "Sent Items"']
            def select(self, name, readonly=False):
                if " " in name and not name.startswith('"'):
                    raise imaplib.IMAP4.error("BAD Extra arguments")
                self.folder = name.strip('"'); return "OK",[b"1"]
            def uid(self, action, *args):
                BatchIMAP.commands.append((action, args[-1]))
                box = folders[self.folder]
                if action == "search": return "OK",[" ".join(box).encode()]
                wanted = []
                spec = args[0].decode() if isinstance(args[0], bytes) else args[0]
                for part in spec.split(","):
                    a, _, b = part.partition(":")
                    wanted += [str(i) for i in range(int(a), int(b or a) + 1) if str(i) in box]
                if args[1] == "(RFC822.SIZE)":
                    return "OK",[f"1 (UID {u} RFC822.SIZE {40_000_000 if u=='50' else len(box[u])})".encode() for u in wanted]
                data = []
                for u in wanted:
                    # Some servers send UID after the message body.
                    data += [(b'1 (INTERNALDATE " 5-Mar-2024 10:00:00 +0100" BODY[] {9}', box[u]), f" UID {u})".encode()]
                return "OK", data
            def logout(self): pass
        p = app.create_project("Paczki","2024-01-01","2024-12-31","","tabal")
        result = app.sync_project_account(p["id"],"tabal",BatchIMAP)
        self.assertEqual(result["imported"], 49)
        self.assertEqual(result["too_large"], 1)
        with app.connect() as db:
            errors = [tuple(r) for r in db.execute("SELECT operation, detail FROM mail_errors")]
        self.assertEqual(result["failed"], 0, errors)
        fetches = [c for c in BatchIMAP.commands if c[1] == "(UID INTERNALDATE BODY.PEEK[])"]
        self.assertLessEqual(len(fetches), 3)  # 49 mails in a couple of round trips, not 49
        with app.connect() as db:
            day = db.execute("SELECT received_day FROM messages WHERE uid='1'").fetchone()[0]
        self.assertEqual(day, "2024-03-05")
        BatchIMAP.commands = []
        again = app.sync_project_account(p["id"],"tabal",BatchIMAP)
        self.assertEqual(again["imported"], 0)
        downloads = [c for c in BatchIMAP.commands if "BODY.PEEK[]" in c[1]]
        self.assertEqual(downloads, [])  # duplicate copy in Sent Items is remembered, not re-downloaded

    def test_html_stub_and_long_recipient_list(self):
        m = EmailMessage()
        m["From"] = "a@b.pl"
        m["To"] = ", ".join(f"Osoba {i} <osoba{i}@firma.pl>" for i in range(60)) + ", Zenon Ostatni <z@firma.pl>"
        m["Subject"] = "Test"
        m.set_content("Wiadomość w HTML")
        m.add_alternative("<html><head><style>.x{color:red}</style></head><body><p>" + "Szczegóły oferty. " * 60 +
                          "</p><p>Numer umowy UM-77</p></body></html>", subtype="html")
        parsed = app.parse_mail(m.as_bytes())
        self.assertIn("UM-77", parsed["body"])
        self.assertNotIn("color:red", parsed["body"])
        self.assertIn("Zenon Ostatni", parsed["recipient"])


def archive_server(folders_spec, drop_after=None):
    """Fake IMAP server with real UID sets, sizes, quoting rules and optional connection drop."""
    store = {}
    for folder, uids in folders_spec.items():
        store[folder] = {}
        for uid in uids:
            m = EmailMessage()
            m["From"] = "Jan Kowalski <jan@budimex.pl>" if uid % 2 else "Peter Bauer <pb@bauer.de>"
            m["To"] = "gbartosik@tabal.pl"; m["Subject"] = f"{folder} wiadomość {uid}"
            m["Message-ID"] = f"<{folder}-{uid}@sim>"; m["Date"] = "Tue, 05 Mar 2024 10:00:00 +0100"
            m.set_content(f"Treść {uid} oferta ogrodzenia")
            if uid % 5 == 0:
                m.add_attachment(f"Cennik {uid} antracyt".encode(), maintype="text", subtype="plain", filename=f"cennik_{uid}.txt")
            store[folder][str(uid)] = m.as_bytes()
    state = {"fetched": 0, "logins": 0, "dropped": False}

    class Server:
        def __init__(self, host, port, timeout=None): self.folder = None
        def login(self, u, p): state["logins"] += 1
        def list(self):
            return "OK", [f'(\\HasNoChildren) "/" "{f}"'.encode() for f in store]
        def select(self, name, readonly=False):
            if " " in name and not name.startswith('"'):
                raise imaplib.IMAP4.error("BAD Extra arguments")
            self.folder = name.strip('"'); return "OK", [b"1"]
        def uid(self, action, *args):
            box = store[self.folder]
            if action == "search": return "OK", [" ".join(box).encode()]
            spec = args[0].decode() if isinstance(args[0], bytes) else args[0]
            wanted = []
            for part in spec.split(","):
                a, _, b = part.partition(":")
                wanted += [str(i) for i in range(int(a), int(b or a) + 1) if str(i) in box]
            if args[1] == "(RFC822.SIZE)":
                return "OK", [f"1 (UID {u} RFC822.SIZE {len(box[u])})".encode() for u in wanted]
            if drop_after is not None and state["fetched"] >= drop_after and not state["dropped"]:
                state["dropped"] = True
                raise imaplib.IMAP4.abort("socket error: EOF")
            data = []
            for u in wanted:
                state["fetched"] += 1
                data += [(f'1 (UID {u} INTERNALDATE "05-Mar-2024 10:00:00 +0100" BODY[] {{1}}'.encode(), box[u]), b")"]
            return "OK", data
        def logout(self): pass
    return Server, state


class Archive56Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ,{"TABAL_LOGIN":"martin@tabal.pl","TABAL_PASSWORD":"fake-test-password",
                                          "TABAL_IMAP_HOST":"imap.example.org","SKYFENS_LOGIN":"","SKYFENS_PASSWORD":""})
        self.env.start()
        app.ARCHIVE_JOB.update({"running":False, "stop":False})
        self.sleep = patch.object(app.time, "sleep", lambda s: None)
        self.sleep.start()
    def tearDown(self):
        self.sleep.stop()
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()

    def test_archive_downloads_all_folders_keeps_copies_and_works_offline(self):
        Server, state = archive_server({"INBOX": range(1, 61), "Sent Items": range(1, 31), "Projekty/Bauer": range(1, 11)})
        results = app.run_archive("2021-01-01", True, Server)
        self.assertEqual(results[0]["imported"], 100)
        self.assertEqual(results[0]["raw_saved"], 100)
        status = app.archive_status()
        tabal = status["accounts"][0]
        self.assertEqual((tabal["messages"], tabal["with_copy"]), (100, 100))
        self.assertEqual({f["folder"] for f in tabal["folders"]}, {"INBOX", "Sent Items", "Projekty/Bauer"})
        self.assertTrue(status["settings"]["last_update"])
        project_id = status["settings"]["project_id"]
        self.assertEqual(app.project_data(project_id, include_messages=False)["total_messages"], 100)
        # Offline: the server is unreachable, attachments still open from the local copy.
        def offline(host, port, timeout=None):
            raise socket.gaierror(-2, "Name or service not known")
        with app.connect() as db:
            mid = db.execute("SELECT id FROM messages WHERE attachments!='[]' LIMIT 1").fetchone()[0]
        name, mime, blob = app.attachment_bytes(mid, 0, offline)
        self.assertTrue(name.startswith("cennik_"))
        self.assertIn(b"antracyt", blob)
        self.assertIn("antracyt", app.index_attachment(mid, 0, offline)["text"])
        # A new project is filled locally, without connecting anywhere.
        p = app.create_project("Bauer offline", "2024-01-01", "2024-12-31", "od:bauer", "tabal")
        self.assertEqual(p["local_messages"], 50)
        self.assertIn("offline", app.sync_error_message(socket.gaierror(-2, "Name or service not known")))
        # Second run only checks: nothing is downloaded again.
        before = state["fetched"]
        again = app.run_archive("2021-01-01", True, Server)
        self.assertEqual((again[0]["imported"], state["fetched"] - before), (0, 0))

    def test_copies_are_backfilled_without_duplicates(self):
        Server, state = archive_server({"INBOX": range(1, 21)})
        app.run_archive("2021-01-01", False, Server)
        self.assertEqual(app.archive_status()["accounts"][0]["with_copy"], 0)
        result = app.run_archive("2021-01-01", True, Server)[0]
        self.assertEqual((result["imported"], result["raw_saved"]), (0, 20))
        with app.connect() as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM messages").fetchone()[0], 20)

    def test_dropped_connection_is_resumed(self):
        Server, state = archive_server({"INBOX": range(1, 121)}, drop_after=45)
        result = app.run_archive("2021-01-01", True, Server)[0]
        self.assertTrue(state["dropped"])
        self.assertGreaterEqual(state["logins"], 2)
        self.assertEqual((result["imported"], result["failed"]), (120, 0))
        with app.connect() as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM messages").fetchone()[0], 120)

    def test_stop_and_continue_later(self):
        Server, state = archive_server({"INBOX": range(1, 101)})
        calls = {"n": 0}
        def stop_soon():
            calls["n"] += 1
            return calls["n"] > 2
        first = app.sync_range("tabal", app.date(2021,1,1), app.date.today(), Server, store_raw=True,
                               backfill_raw=True, should_stop=stop_soon)
        self.assertTrue(first["stopped"])
        self.assertLess(first["imported"], 100)
        rest = app.run_archive("2021-01-01", True, Server)[0]
        self.assertEqual(first["imported"] + rest["imported"], 100)

    def test_cli_without_accounts_explains_what_to_do(self):
        with patch.dict(os.environ, {"TABAL_LOGIN":"", "TABAL_PASSWORD":""}):
            out = io.StringIO()
            with patch("sys.stdout", out):
                self.assertEqual(app.archive_cli("2021-01-01", True), 2)
            self.assertIn("Konfiguracja kont", out.getvalue())


def tb_mail(n, status="0001", status2="00000000", subject=None, sender=None, attachment=True, extra_body=""):
    m = EmailMessage()
    m["From"] = sender or ("Jan Kowalski <jan@budimex.pl>" if n % 2 else "Peter Bauer <pb@bauer.de>")
    m["To"] = "Grzegorz Bartosik <gbartosik@tabal.pl>"
    m["Subject"] = subject or f"Oferta nr {n}"
    m["Message-ID"] = f"<tb-{n}@test>"
    m["Date"] = f"Tue, {1 + n % 27:02d} Feb 2024 10:00:00 +0100"
    m.set_content(f"Dzień dobry,\nprzesyłam ofertę {n} na ogrodzenie.\nFrom my phone{extra_body}\n")
    if attachment and n % 3 == 0:
        m.add_attachment(f"Cennik {n}: panel antracyt".encode(), maintype="text", subtype="plain", filename=f"cennik_{n}.txt")
    raw = m.as_bytes().replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
    raw = raw.replace(b"\r\nFrom my phone", b"\r\n>From my phone")  # Thunderbird escapes body "From " lines
    head = f"From - Tue Feb  6 10:00:00 2024\r\nX-Mozilla-Status: {status}\r\nX-Mozilla-Status2: {status2}\r\nX-Mozilla-Keys:                                                                                 \r\n".encode()
    return head + raw + b"\r\n"


def write_mbox(path, mails, old=True):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"".join(mails))
    (path.parent / (path.name + ".msf")).write_bytes(b"// <!-- <mdb:mork:z v=\"1.4\"/> -->")
    if old:
        os.utime(path, (time.time() - 3600, time.time() - 3600))


class Thunderbird57Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        root = Path(self.temp.name)
        app.DB_PATH = root / "app" / "test.sqlite3"
        app.DB_PATH.parent.mkdir()
        app.connect().close()
        self.env = patch.dict(os.environ,{"TABAL_LOGIN":"","TABAL_PASSWORD":"","SKYFENS_LOGIN":"","SKYFENS_PASSWORD":""})
        self.env.start()
        app.ARCHIVE_JOB.update({"running":False, "stop":False})
        self.profile = root / "Profiles" / "abcd.default-release"
        self.acc = self.profile / "ImapMail" / "tabal.home.pl"
        self.inbox = [tb_mail(n) for n in range(1, 31)]
        self.inbox[4] = tb_mail(5, status="0009")              # deleted, not compacted yet
        self.inbox[6] = tb_mail(7, status2="00200000")         # IMAP "marked as deleted"
        self.inbox[8] = tb_mail(9, status="0401")              # downloaded without body
        write_mbox(self.acc / "INBOX", self.inbox)
        write_mbox(self.acc / "Sent", [tb_mail(n, sender="Grzegorz <gbartosik@tabal.pl>") for n in range(100, 110)])
        write_mbox(self.acc / "Trash", [tb_mail(n) for n in range(200, 205)])
        write_mbox(self.acc / "INBOX.sbd" / "Klienci.sbd" / "Firma ABC", [tb_mail(n) for n in range(300, 305)])
        (self.acc / "INBOX.sbd" / "Klienci").write_bytes(b"")  # empty parent folder file
        (self.acc / "INBOX.sbd" / "Klienci.msf").write_bytes(b"")
        write_mbox(self.profile / "Mail" / "Local Folders" / "Archiwum 2021", [tb_mail(n) for n in range(400, 403)])
    def tearDown(self):
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()
    def count(self):
        with app.connect() as db:
            return db.execute("SELECT COUNT(*) FROM messages").fetchone()[0]

    def test_inspect_finds_accounts_folders_and_guesses_mailbox(self):
        info = app.tb_inspect(str(self.profile))
        names = {a["name"]: a for a in info["accounts"]}
        self.assertEqual(names["tabal.home.pl"]["account"], "tabal")
        self.assertEqual(names["Local Folders"]["account"], "")  # not guessed -> skipped unless assigned
        folders = [f[0] for f in app.tb_folders(self.acc)]
        self.assertEqual(sorted(folders), ["INBOX", "INBOX/Klienci/Firma ABC", "Sent"])  # Trash skipped

    def test_index_search_and_offline_attachment(self):
        result = app.run_thunderbird(str(self.profile), workers=1)
        self.assertEqual(result["imported"], 30 - 2 + 10 + 5)
        self.assertEqual((result["deleted_skipped"], result["partial"], result["failed"]), (2, 1, 0))
        project_id = int(app.get_setting("archive_project_id"))
        self.assertEqual(app.project_data(project_id, include_messages=False)["total_messages"], 43)
        hits = app.search_archive(project_id, "antracyt od:kowalski", date_from="", date_to="")
        self.assertTrue(hits["total"] > 0)
        self.assertEqual(app.search_archive(project_id, '"from my phone"', date_from="", date_to="")["total"], 43)
        with app.connect() as db:
            mid, folder = db.execute("SELECT id, folder FROM messages WHERE subject='Oferta nr 3'").fetchone()
            day = db.execute("SELECT received_day FROM messages WHERE id=?", (mid,)).fetchone()[0]
        self.assertEqual((folder, day), ("INBOX", "2024-02-04"))
        def offline(*a, **k): raise socket.gaierror(-2, "offline")
        name, mime, blob = app.attachment_bytes(mid, 0, offline)
        self.assertEqual((name, blob), ("cennik_3.txt", b"Cennik 3: panel antracyt"))
        # Local Folders can be assigned to a mailbox explicitly.
        mapping = {str(self.acc): "tabal", str(self.profile / "Mail" / "Local Folders"): "tabal"}
        again = app.run_thunderbird(str(self.profile), mapping, workers=1)
        self.assertEqual(again["imported"], 3)

    def test_incremental_flags_compaction_and_still_writing(self):
        app.run_thunderbird(str(self.profile), workers=1)
        base = self.count()
        # Thunderbird appends new mail; the last one is still being written (fresh mtime).
        with open(self.acc / "INBOX", "ab") as f:
            f.write(tb_mail(31) + tb_mail(32))
        seen = {}
        r = app.run_thunderbird(str(self.profile), workers=1, progress=lambda p: seen.update(p))
        self.assertEqual(r["imported"], 1)
        self.assertLess(seen["bytes_total"], 20_000)  # only appended bytes were read
        os.utime(self.acc / "INBOX", (time.time() - 3600, time.time() - 3600))
        self.assertEqual(app.run_thunderbird(str(self.profile), workers=1)["imported"], 1)
        self.assertEqual(self.count(), base + 2)
        # Mail marked as read: Thunderbird rewrites X-Mozilla-Status in place -> no duplicates.
        data = (self.acc / "INBOX").read_bytes().replace(b"X-Mozilla-Status: 0001", b"X-Mozilla-Status: 0003", 1)
        write_mbox(self.acc / "INBOX", [data])
        r = app.run_thunderbird(str(self.profile), workers=1)
        self.assertEqual((r["imported"], self.count()), (0, base + 2))
        # Compaction: deleted mails physically removed, every position shifts.
        compacted = [m for m in self.inbox if b"X-Mozilla-Status: 0009" not in m][3:] + [tb_mail(31), tb_mail(32)]
        write_mbox(self.acc / "INBOX", compacted)
        with app.connect() as db:
            mid = db.execute("SELECT id FROM messages WHERE subject='Oferta nr 12'").fetchone()[0]
        name, _, blob = app.attachment_bytes(mid, 0, None)  # positions repaired automatically
        self.assertEqual(blob, b"Cennik 12: panel antracyt")
        r = app.run_thunderbird(str(self.profile), workers=1)
        self.assertEqual(r["imported"], 0)
        self.assertEqual(self.count(), base + 2)

    def test_maildir_folder(self):
        cur = self.profile / "ImapMail" / "mail.skyfens.pl" / "INBOX" / "cur"
        cur.mkdir(parents=True)
        for n in range(500, 504):
            (cur / f"{n}.eml").write_bytes(tb_mail(n).split(b"\r\n", 1)[1])
        r = app.run_thunderbird(str(self.profile), workers=1)
        with app.connect() as db:
            sky = db.execute("SELECT COUNT(*) FROM messages WHERE account='skyfens'").fetchone()[0]
        self.assertEqual(sky, 4)
        self.assertEqual(r["failed"], 0)

    def test_cli(self):
        out = io.StringIO()
        with patch("sys.stdout", out):
            self.assertEqual(app.thunderbird_cli(str(self.profile)), 0)
        text = out.getvalue()
        self.assertIn("tabal.home.pl", text)
        self.assertIn("POMIJAM", text)  # Local Folders not assigned
        self.assertIn("Gotowe", text)


if __name__ == "__main__":
    unittest.main()
