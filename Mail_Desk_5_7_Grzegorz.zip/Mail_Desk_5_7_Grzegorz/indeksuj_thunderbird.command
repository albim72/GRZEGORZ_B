#!/bin/sh
# Mac: kliknij dwukrotnie (za pierwszym razem: prawy klik -> Otwórz).
cd "$(dirname "$0")" || exit 1
echo "Mail Desk – indeksowanie archiwum Thunderbirda"
if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv || { echo "Brak Pythona 3. Zainstaluj go (python.org) i spróbuj ponownie."; read -r _; exit 1; }
fi
if ! .venv/bin/python -c 'import pypdf' >/dev/null 2>&1; then
  .venv/bin/python -m pip install --disable-pip-version-check -r requirements.txt ||
    echo 'PDF wymaga pypdf. Pozostałe funkcje będą działały.'
fi
.venv/bin/python maildesk.py --thunderbird "$@"
echo
printf "Naciśnij Enter, aby zamknąć okno."
read -r _
