@echo off
cd /d "%~dp0"
echo Mail Desk - indeksowanie archiwum Thunderbirda
if not exist .venv\Scripts\python.exe (
  where py >nul 2>nul
  if %errorlevel%==0 (
    py -3 -m venv .venv
  ) else (
    python -m venv .venv
  )
)
.venv\Scripts\python -c "import pypdf" >nul 2>nul
if errorlevel 1 .venv\Scripts\python -m pip install --disable-pip-version-check -r requirements.txt
.venv\Scripts\python maildesk.py --thunderbird %*
echo.
pause
