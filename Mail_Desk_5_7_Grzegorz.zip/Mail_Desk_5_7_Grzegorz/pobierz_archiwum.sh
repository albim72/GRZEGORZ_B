#!/bin/sh
cd "$(dirname "$0")" || exit 1
echo "Mail Desk – pobieranie archiwum poczty"
if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv || exit 1
fi
if ! .venv/bin/python -c 'import pypdf' >/dev/null 2>&1; then
  .venv/bin/python -m pip install --disable-pip-version-check -r requirements.txt ||
    echo 'PDF wymaga pypdf. Pozostałe funkcje będą działały.'
fi
printf "Od jakiej daty pobrać pocztę? [Enter = 2021-01-01]: "
read OD
[ -z "$OD" ] && OD=2021-01-01
.venv/bin/python maildesk.py --archiwum "$OD"
