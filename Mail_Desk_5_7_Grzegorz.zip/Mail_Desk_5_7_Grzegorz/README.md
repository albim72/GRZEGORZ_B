# Mail Desk 5.7 — TABAL i Skyfens

Lokalna aplikacja dla Grzegorza do pracy z wieloletnią pocztą firmową. Od wersji 5.7 najprostszy sposób na dużą skrzynkę wygląda tak: **Thunderbird pobiera pocztę, a Mail Desk ją przeszukuje.**

## Archiwum z Thunderbirda (nowe w 5.7, zalecane przy dużej poczcie)

Thunderbird pobiera całą pocztę na komputer. Mail Desk **tylko czyta jego pliki**, niczego w nich nie zmienia. Buduje z nich szybki indeks wyszukiwania i otwiera załączniki prosto z plików Thunderbirda, więc nie ma drugiej kopii poczty na dysku. Hasło do skrzynki nie jest Mail Deskowi potrzebne do wyszukiwania, tylko do wysyłania odpowiedzi.

### 1. Thunderbird (raz)

1. Dodaj konto TABAL jako **IMAP** (nie POP3): serwer `tabal.home.pl`, port 993, SSL/TLS. Wychodząca: `tabal.home.pl`, port 465, SSL/TLS. Login to pełny adres e-mail.
2. Prawy klik na konto → **Ustawienia** → **Synchronizacja i miejsce na dysku**:
   - zaznacz **Przechowuj wiadomości z tego konta na tym komputerze**;
   - wybierz synchronizację **wszystkich** wiadomości, bez ograniczenia wieku. Do testów wystarczy np. ostatni miesiąc;
   - **odznacz „Nie pobieraj wiadomości większych niż…”**, inaczej duże maile przyjdą bez załączników. Mail Desk wykrywa takie maile i ostrzega;
   - **Zaawansowane…**: zaznacz wszystkie foldery.
3. **Plik → Pracuj offline → Pobierz/Synchronizuj teraz…** → Wiadomości. Przy dużej poczcie zostaw komputer na noc i wyłącz usypianie.

### 2. Mail Desk

- **W aplikacji:** panel **Archiwum poczty** → **Archiwum z Thunderbirda**. Profil jest wykrywany automatycznie (Mac, Windows, Linux); można też wkleić ścieżkę do folderu. Kliknij **Sprawdź konta i foldery**, przypisz konto do TABAL lub Skyfens (rozpoznaje je po nazwie serwera), potem **Indeksuj archiwum Thunderbirda**.
- **Bez przeglądarki:** Mac: `indeksuj_thunderbird.command`, dwuklik; za pierwszym razem prawy klik → Otwórz. Windows: `indeksuj_thunderbird.bat`. Można też podać ścieżkę: `python3 maildesk.py --thunderbird "/ścieżka/do/profilu"`.
- Potem otwórz projekt **Archiwum poczty (całość)**.

Gdzie jest profil Thunderbirda:
- **Mac:** `~/Library/Thunderbird/Profiles/xxxx.default-release`
- **Windows:** `%APPDATA%\Thunderbird\Profiles\xxxx.default-release`

W Thunderbirdzie znajdziesz go też w menu Pomoc → Więcej informacji dla rozwiązywania problemów → Folder profilu. Poczta jest w podfolderze `ImapMail/<serwer>`: pliki bez rozszerzenia to foldery poczty, a katalogi `.sbd` to podfoldery.

### Jak to działa na co dzień

- **Kolejne indeksowanie czyta tylko to, co Thunderbird dopisał.** Gdy nic się nie zmieniło, trwa ułamek sekundy. Przy starcie aplikacji dzieje się to samo w tle (można wyłączyć).
- **Maile usunięte w Thunderbirdzie są pomijane.** Mail Desk rozpoznaje je po znacznikach Thunderbirda.
- **Oznaczenie maila jako przeczytany nie tworzy duplikatów.**
- **„Kompaktowanie” folderów jest wykrywane.** Thunderbird przepisuje wtedy pliki, a Mail Desk sam poprawia położenie maili, także przy otwieraniu załącznika.
- Ostatni mail, który Thunderbird właśnie zapisuje, zostaje pominięty do następnego indeksowania.
- Indeksowanie korzysta ze wszystkich rdzeni procesora.
- **Pomijane foldery:** Kosz, Spam, Szkice, Szablony i Niewysłane. „Lokalne foldery” (np. archiwa ręcznie przenoszone przez Grzegorza) są dołączane dopiero po przypisaniu ich w panelu do skrzynki.
- Obsługiwany jest standardowy format Thunderbirda (mbox) i opcjonalny Maildir.

**Szybkość** (testowy profil na 2-rdzeniowej maszynie): 15 000 maili w 111 folderach (595 MB) zindeksowane w 62 s na jednym rdzeniu i 44 s na dwóch. Ponowne sprawdzenie bez zmian trwało 0,06 s. Wyszukiwanie w tym archiwum trwa ok. 0,1 s. Najdłużej trwa odczyt tekstu z PDF-ów i Exceli. Na Macu z wieloma rdzeniami będzie szybciej.

## Archiwum pobierane bezpośrednio z serwera (5.6, bez Thunderbirda)

**Pierwsze pobranie** (najlepiej wieczorem, na noc):

1. Uruchom aplikację (`start_windows.bat` albo `start_mac_linux.sh`) i w **Konfiguracja kont i AI** wpisz login i hasło skrzynek. Hasło zostaje tylko na tym komputerze.
2. Wybierz jeden ze sposobów:
   - **w aplikacji:** w panelu **Archiwum poczty** (po lewej) zostaw datę 2021-01-01 i kliknij **Pobierz archiwum**;
   - **bez otwierania przeglądarki:** zamknij aplikację i uruchom `pobierz_archiwum.bat` (Windows) albo `pobierz_archiwum.sh` (Mac). Postęp i szacowany czas do końca widać w oknie.
3. Program sprawdza wszystkie foldery obu skrzynek, najpierw liczy, ile jest do pobrania, a potem pobiera paczkami. W tym czasie nie pozwala komputerowi zasnąć (Windows i Mac).
4. Przerwanie (zamknięcie okna, **Zatrzymaj**, brak Internetu, zerwane połączenie) jest bezpieczne. Następne uruchomienie dokończy od miejsca przerwania, niczego nie pobierając drugi raz. Zerwane połączenie program sam wznawia do 5 razy.

**Potem:**
- W projekcie **Archiwum poczty (całość)** jest cała poczta: wyszukiwarka, Rozmowa i załączniki.
- Nowy projekt od razu wypełnia się mailami z archiwum, bez łączenia z serwerem. Przycisk **Odśwież z archiwum** robi to ponownie.
- Przy każdym starcie aplikacja w tle dociąga nowe maile. Bez Internetu po prostu pracuje na archiwum. Można to wyłączyć w panelu.

**Pełne kopie maili:** domyślnie każdy mail jest zapisywany w całości, z załącznikami, w folderze `archiwum_maili` obok bazy (skompresowane pliki `.eml.gz`). Dzięki temu załączniki otwierają się offline, a archiwum nie zależy od tego, co zostanie na serwerze. Zajmuje to mniej więcej tyle miejsca, ile skrzynka na serwerze. Po odznaczeniu tej opcji zapisywany jest tylko tekst (mała baza), a pliki są pobierane z serwera na żądanie. Kopie można też dopisać później do istniejącego archiwum. Program pobierze wtedy tylko brakujące kopie.

**Pomijane foldery:** Kosz, Spam i Szkice (Wersje robocze).

**Bezpieczeństwo:** baza i folder `archiwum_maili` zawierają całą korespondencję firmy. Włącz szyfrowanie dysku (BitLocker albo FileVault), rób kopię zapasową obu i nie wysyłaj ich mailem. AI dostaje tylko wybrane fragmenty i tylko po kliknięciu „Zapytaj AI” albo „Analizuj przez AI”. Ta funkcja jako jedyna wymaga Internetu.

**Ograniczenia:** skany PDF bez warstwy tekstowej (wymagające OCR) nie są przeszukiwane. Maile ponad 30 MB są pomijane i zapisywane w dzienniku błędów.

## Zmiany w 5.5 (wyszukiwanie i szybkość)

**Szybkość (zmierzone na testowej skrzynce, nie na serwerze home.pl):**

| | 5.4 | 5.5 |
|---|---|---|
| Wyszukiwanie w 20 000 maili | ok. 13 s | ok. 0,2 s |
| Lokalny zapis 20 000 maili | 653 s, coraz wolniej | 23 s, stałe tempo |
| Pobranie 2 000 maili (opóźnienie sieci 30 ms) | 77 s | 7,6 s |

- Maile są pobierane paczkami (do 40 naraz) zamiast pojedynczo, więc jest jedno odwołanie do serwera na paczkę.
- Rozmiar maili jest sprawdzany przed pobraniem, więc maile ponad 30 MB nie są niepotrzebnie ściągane.
- Kopia tego samego maila w innym folderze (np. Wysłane i Archiwum) jest zapamiętywana i nie jest pobierana przy każdej synchronizacji.
- Stary indeks, który przy każdym zapisie przeglądał całą bazę, został usunięty.

**Co teraz jest znajdowane, a wcześniej nie było:**
- Foldery ze spacją w nazwie (np. „Sent Items”, „Elementy wysłane”). Wcześniej serwer odrzucał ich otwarcie i cały folder był pomijany.
- Fraza w cudzysłowie przełamana w mailu do nowej linii.
- Odmiana: „Kowalski” znajduje też „Kowalskiego”, „Kowalskim”, „Kowalska”, a „ogrodzenie” także „ogrodzenia”. Można to wyłączyć.
- Pełna lista odbiorców (wcześniej pole „Do” było obcinane po 500 znakach).
- Maile, w których zwykły tekst był tylko zaślepką, a treść była w HTML.
- Daty: każdy mail ma teraz jedną, poprawną datę, więc działa filtr dat i sortowanie od najnowszych.

**Nowe w wyszukiwarce:** pola „Od daty / Do daty”, szybkie zakresy, szukanie w wybranym polu, wykluczanie, podświetlone fragmenty i informacja, gdzie znaleziono słowo (nadawca, temat, treść, załącznik).

**Rozmowa** rozumie daty w pytaniu: „Co pisał Kowalski w marcu 2024?”, „Ile maili od Bauera w zeszłym roku?”, „15.03.2024”, „od 2023 do 2024”, „w tym roku”, „ostatni miesiąc”.

### Pierwsze uruchomienie z bazą z 5.4 lub starszej

Przy pierwszym starcie 5.5 jednorazowo buduje nowy indeks i porządkuje bazę. Postęp widać w oknie Terminala. Dla 20 000 maili trwało to ok. 17 s. Na dysku potrzeba chwilowo tyle wolnego miejsca, ile zajmuje plik `maildesk.sqlite3`. **Przed pierwszym uruchomieniem zrób kopię pliku `maildesk.sqlite3`.**

## Uruchomienie

### macOS / Linux

1. Rozpakuj ZIP do osobnego folderu.
2. Otwórz Terminal, wpisz `sh ` ze spacją i przeciągnij do Terminala plik `start_mac_linux.sh`.
3. Naciśnij Enter. Przy pierwszym uruchomieniu przygotowanie środowiska może doinstalować `pypdf`.
4. Aplikacja powinna otworzyć `http://127.0.0.1:8765`. Terminal musi pozostać otwarty.
5. Zatrzymanie: `Ctrl+C`.

### Windows

Uruchom `start_windows.bat`. Aplikacja działa pod `http://127.0.0.1:8765`.

## Konfiguracja kont

W **Konfiguracja kont i AI** wpisz pełny login i hasło do skrzynki TABAL i/lub Skyfens. Następnie kliknij odpowiedni przycisk **Sprawdź IMAP**.

Dane logowania oraz klucz API są zapisywane lokalnie w `.env.local`. Tego pliku nie wysyłaj innym osobom i nie dołączaj do kolejnych ZIP-ów.

Do analizy AI potrzebny jest osobny klucz OpenAI API firmy. Bez klucza działa lokalne indeksowanie i wyszukiwanie.

## Wyszukiwanie

1. Utwórz projekt, ustaw daty i skrzynki. **Wstępny filtr projektu** możesz zostawić pusty.
2. Kliknij **Indeksuj / synchronizuj pocztę** i poczekaj na koniec pobierania.
3. W polu **Szukaj w pobranej poczcie** wpisz kryterium i ewentualnie zmień daty:

| Wpisz | Co znajdzie |
|---|---|
| `Kowalski oferta` | oba fragmenty w jednym mailu (imię, nazwisko, firma, adres, numer – dowolny fragment) |
| `"oferta na ogrodzenie"` | dokładną frazę |
| `Leonardo \| Bauer` | jedno albo drugie |
| `-faktura` | pomija maile zawierające „faktura” |
| `od:Kowalski` | tylko w nadawcy |
| `do:@firma.pl` | tylko w odbiorcach i DW |
| `temat:umowa` | tylko w temacie |
| `plik:cennik` | tylko w nazwach załączników |
| `data:2024-03` | tylko marzec 2024 (także `data:2024`, `data:15.03.2024`) |
| `od:2024-01-01 do:2024-06-30` | zakres dat wpisany w zapytaniu |
| puste pole + daty | wszystkie maile z okresu, od najnowszych |

Domyślnie daty wyszukiwania to daty projektu. Przycisk **Cała pobrana poczta** usuwa limit dat. Wtedy przeszukiwane są wszystkie maile tych skrzynek pobrane na komputer, także przez inne projekty.

Wielkość liter i polskie znaki nie mają znaczenia. Fragment słowa wystarczy: `bau` znajdzie `Bauer`. Program nie dopisuje synonimów ani tłumaczeń. Jeśli możliwe jest `Hiszpania`, `Spain` lub `España`, wpisz `Hiszpania | Spain | España`.

Program przeszukuje tylko maile już pobrane na ten komputer. Jeśli czegoś nie ma, sprawdź zakres dat albo zsynchronizuj projekt obejmujący dany okres.

## Szybkość home.pl i zakres wyników

Pierwsze pobranie wieloletniej skrzynki nadal zależy od serwera i łącza, bo trzeba przesłać wszystkie maile z załącznikami. Wersja 5.5 pobiera je paczkami, więc opóźnienie sieci liczy się raz na paczkę, a nie raz na każdy mail. Kolejne synchronizacje pobierają tylko nowe wiadomości. Maile ponad 30 MB są pomijane bez pobierania i zapisywane w dzienniku błędów.

## Załączniki

Przy pierwszym pobraniu nowej wiadomości program zapisuje metadane wszystkich załączników. Tekst jest automatycznie wydobywany z obsługiwanych typów:

- TXT, CSV, MD, JSON, XML, HTML,
- DOCX,
- XLSX,
- tekstowy PDF.

Nie są automatycznie odczytywane skany PDF wymagające OCR, obrazy, stare DOC/XLS i pliki zabezpieczone hasłem. Takie pliki pozostają widoczne w indeksie metadanych po nazwie.

Przycisk **Uzupełnij indeks załączników** służy głównie do starszych wiadomości już zapisanych przez wcześniejsze wersje aplikacji albo do ponowienia odczytu dokumentów.

Limity bezpieczeństwa pozostają: pełna wiadomość 30 MB, pojedynczy załącznik 15 MB.

## Aktualizacja z 5.1–5.5

Jeżeli używasz tych samych skrzynek Grzegorza, możesz skopiować do folderu 5.6:

- `.env.local`
- `maildesk.sqlite3`

Baza zostanie automatycznie rozszerzona o nowe pola i indeks (zob. „Pierwsze uruchomienie z bazą z 5.4”). Potem kliknij **Indeksuj / synchronizuj pocztę**. 5.5 dopobierze foldery, których 5.4 nie mogła otworzyć (np. „Sent Items”).

Jeżeli zmieniasz konto z testowego `martin@...` na właściwe konto Grzegorza, zacznij w czystym folderze i nie kopiuj starej bazy.

## Bezpieczeństwo i wysyłka

- Aplikacja nasłuchuje wyłącznie lokalnie na `127.0.0.1`.
- Wiadomości oraz indeks są przechowywane lokalnie w `maildesk.sqlite3`.
- Treść trafia do OpenAI API dopiero po wybraniu trybu **Zapytaj AI** lub **Analizuj przez AI**.
- AI otrzymuje wybrane trafne źródła, nie całą skrzynkę.
- Wysyłka SMTP nadal wymaga jawnego potwierdzenia odbiorcy i treści.

## Testy

Uruchom:

```bash
python3 -m unittest discover -s tests -v
```

Paczka 5.7 przechodzi 41 testów. Nowe testy działają na plikach w formacie Thunderbirda (CRLF, X-Mozilla-Status, podfoldery `.sbd`, escapowane `>From`) i obejmują:
- wykrywanie kont i folderów;
- pomijanie usuniętych maili i wykrywanie niepełnych;
- wyszukiwanie i załącznik otwierany offline;
- dopisywanie nowych maili oraz pomijanie maila, który Thunderbird właśnie zapisuje;
- zmianę flag bez duplikatów i kompaktowanie folderu;
- format Maildir i tryb wiersza poleceń.

Dodatkowo całość sprawdzono w przeglądarce na profilu ze 111 folderami i 15 000 maili. Nie testowano na prawdziwym profilu Thunderbirda Grzegorza.
