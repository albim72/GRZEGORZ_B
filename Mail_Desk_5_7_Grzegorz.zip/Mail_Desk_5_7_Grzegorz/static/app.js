const state = {projects:[], projectId:null, data:null, accounts:{}, ai:false, tab:'chat', messageId:null, message:null, documents:[], offset:0, showMessages:false, syncTimer:null, syncText:'', docTimer:null, docText:'', searchQuery:'', searchResults:null, searchOffset:0, searchFrom:null, searchTo:null, inflect:true, archive:null, archiveTimer:null};
const $ = selector => document.querySelector(selector);
function el(tag, cls='', value){const e=document.createElement(tag);if(cls)e.className=cls;if(value!==undefined)e.textContent=String(value);return e}
function append(parent,...children){parent.append(...children);return parent}
function button(label,cls,click){const b=el('button',cls,label);b.onclick=click;return b}
function notice(message,error=false){const n=$('#notice');n.textContent=message;n.className=error?'error':'';clearTimeout(notice.timer);notice.timer=setTimeout(()=>n.textContent='',9000)}
async function post(path,data){const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const result=await r.json();if(!r.ok)throw Error(result.error||'Błąd żądania');return result}
async function get(path){const r=await fetch('/api/'+path);const result=await r.json();if(!r.ok)throw Error(result.error||'Błąd pobierania');return result}
async function loadProjects(){const result=await get('projects');state.projects=result.projects;state.accounts=result.accounts;state.ai=result.ai_configured;renderSidebar()}
async function openProject(id){state.projectId=id;state.tab='chat';state.messageId=null;state.message=null;state.offset=0;state.showMessages=false;state.syncText='';state.docText='';state.searchQuery='';state.searchResults=null;state.searchOffset=0;state.searchFrom=null;state.searchTo=null;clearTimeout(state.docTimer);localStorage.setItem('maildesk_project',String(id));await refreshProject();watchSync();watchDocuments()}
async function refreshProject(){if(!state.projectId)return;state.data=await get('project?id='+encodeURIComponent(state.projectId)+'&offset='+state.offset+'&list='+(state.showMessages?'1':'0'));await loadProjects();renderWorkspace()}
async function openMessage(id){const result=await get('message?id='+encodeURIComponent(id));state.messageId=id;state.message=result.message;state.documents=result.documents;state.tab='mail';renderWorkspace()}
function renderSidebar(){const projects=$('#projects'),history=$('#questionHistory');projects.replaceChildren();history.replaceChildren();
  for(const p of state.projects){const b=el('button','project-link'+(p.id===state.projectId?' active':''));append(b,el('strong','',p.name),el('span','',p.message_count+' wiadomości · '+p.date_from+' - '+p.date_to));b.onclick=()=>openProject(p.id).catch(e=>notice(e.message,true));projects.append(b)}
  if(!state.projects.length)projects.append(el('p','empty-list','Utwórz pierwszy projekt.'));
  const entries=state.data?.history||[];
  for(const q of [...entries].reverse()){const row=el('div','history-item');const b=button(q.question,'question-link',()=>{state.tab='chat';renderWorkspace();document.getElementById('question-'+q.id)?.scrollIntoView({behavior:'smooth',block:'center'})});const reuse=button('Użyj ponownie','reuse-link',()=>{state.tab='chat';renderWorkspace();const input=$('.composer textarea');input.value=q.question;input.focus()});row.append(b,reuse);history.append(row)}
  if(!entries.length)history.append(el('p','empty-list','Pytania do projektu pojawią się tutaj.'));
}
function renderWorkspace(){const root=$('#workspace');root.replaceChildren();if(!state.data){root.append(el('div','welcome','Wybierz projekt lub utwórz nowy.'));return}
  const p=state.data.project,top=el('div','project-top'),intro=el('div');append(intro,el('span','eyebrow','Aktywny projekt'),el('h2','',p.name),el('div','criteria',p.date_from+' - '+p.date_to+' · '+(p.sender_query||'wszyscy nadawcy')+' · '+(p.account==='both'?'obie skrzynki':state.accounts[p.account]?.label||p.account)));top.append(intro);
  const actions=el('div','toolbar');actions.append(button('Dodaj przykłady','secondary',async()=>{try{const r=await post('project/demo',{id:p.id});await refreshProject();notice('Dodano przykładowe wiadomości: '+r.added)}catch(e){notice(e.message,true)}}),button('Indeksuj / synchronizuj pocztę','',syncProject),button('Odśwież z archiwum','secondary',async()=>{try{const r=await post('project/relink',{id:p.id});await refreshProject();notice('Z archiwum na komputerze dodano '+r.added+' maili (bez łączenia z serwerem).')}catch(e){notice(e.message,true)}}),button(state.showMessages?'Ukryj listę maili':'Pokaż listę maili','secondary',async()=>{state.showMessages=!state.showMessages;state.offset=0;await refreshProject()}),button('Uzupełnij indeks załączników','secondary',async()=>{try{await post('project/attachments/index',{id:p.id});watchDocuments()}catch(e){notice(e.message,true)}}));top.append(actions);root.append(top);const progress=el('div','sync-progress',state.syncText);progress.id='syncProgress';root.append(progress);const docProgress=el('div','sync-progress',state.docText);docProgress.id='documentProgress';root.append(docProgress);
  const status=el('div','status');for(const [key,a] of Object.entries(state.accounts))status.append(el('span','pill'+(a.configured?' ready':''),(a.configured?'● ':'○ ')+a.label+(a.configured?' · dane wpisane':' · brak hasła')));status.append(el('span','pill'+(state.ai?' ready':''),state.ai?'● Analiza AI · klucz wpisany':'○ Analiza AI · brak klucza'));const st=state.data.stats||{};status.append(el('span','pill ready','✉ '+state.data.total_messages+' wiadomości'));status.append(el('span','pill ready','▣ '+(st.attachments||0)+' załączników'));status.append(el('span','pill ready','⌕ '+(st.indexed_attachments||0)+' załączników w indeksie'));if(st.first_received)status.append(el('span','pill','📅 '+st.first_received+' – '+st.last_received));root.append(status);renderSearch(root);
  const grid=el('div','main-grid'+(state.showMessages?'':' single-grid'));if(state.showMessages){const left=el('section','mail-column'),title=el('div','panel-title');append(title,el('span','','Wiadomości'),el('span','',state.data.total_messages));left.append(title);const list=el('div','mail-list');for(const m of state.data.messages){const card=el('button','mail-card'+(state.messageId===m.id&&state.tab==='mail'?' active':''));append(card,el('span','mini',fmtDate(m)+' · '+m.account_label+' · '+(m.folder_label||m.folder||'INBOX')),el('strong','',m.subject||'(bez tematu)'),el('p','',m.sender+' · '+m.body.slice(0,120)));card.onclick=()=>openMessage(m.id).catch(e=>notice(e.message,true));list.append(card)}if(!state.data.messages.length)list.append(el('div','empty-list','Brak wiadomości pasujących do projektu.'));left.append(list);const pager=el('div','pager');const prev=button('← Poprzednie','secondary',()=>page(-1)),next=button('Następne →','secondary',()=>page(1));prev.disabled=state.offset===0;next.disabled=state.offset+state.data.messages.length>=state.data.total_messages;pager.append(prev,el('span','',state.data.total_messages?`${state.offset+1}–${state.offset+state.data.messages.length} z ${state.data.total_messages}`:'0 wiadomości'),next);left.append(pager);grid.append(left);}
  const right=el('section','right-pane'),tabs=el('div','pane-tabs');tabs.append(button('Rozmowa',state.tab==='chat'?'active':'',()=>{state.tab='chat';renderWorkspace()}),button('Wiadomość',state.tab==='mail'?'active':'',()=>{state.tab='mail';renderWorkspace()}));right.append(tabs);if(state.tab==='mail')renderMail(right);else renderChat(right);grid.append(right);root.append(grid);renderSidebar()}
async function page(direction){state.offset=Math.max(0,state.offset+direction*state.data.page_size);await refreshProject()}
function fmtDate(m){const ts=m.received_ts;if(ts){const d=new Date(ts);if(!isNaN(d))return d.toLocaleString('pl-PL',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'})}return (m.received||'').slice(0,16)}
function renderSearch(root){const box=el('section','archive-search');
  const p=state.data.project,arch=state.data.archive||{};
  if(state.searchFrom===null)state.searchFrom=p.date_from;
  if(state.searchTo===null)state.searchTo=p.date_to;
  const head=el('div','search-head');head.append(el('h3','','Szukaj w pobranej poczcie'));
  if(arch.messages)head.append(el('span','hint',`Na komputerze: ${arch.messages} maili · ${arch.first_day||'?'} – ${arch.last_day||'?'}`));
  box.append(head);
  const form=el('form','archive-search-form'),input=el('input');
  input.type='search';input.placeholder='np. Kowalski oferta · "umowa ramowa" · od:@firma.pl · Leonardo | Bauer';input.maxLength=500;input.value=state.searchQuery;
  const submit=button('Szukaj','',()=>{});submit.type='submit';
  form.append(input,submit);
  const filters=el('div','search-filters');
  const from=el('input'),to=el('input');from.type=to.type='date';from.value=state.searchFrom||'';to.value=state.searchTo||'';
  const lf=el('label','', 'Od daty'),lt=el('label','','Do daty');lf.append(from);lt.append(to);
  const inf=el('label','check'),cb=el('input');cb.type='checkbox';cb.checked=state.inflect;inf.append(cb,el('span','','Uwzględniaj odmianę (Kowalski → Kowalskiego)'));
  const presets=el('div','date-presets');
  const setRange=(a,b)=>{from.value=a;to.value=b};
  const iso=d=>[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');
  const today=new Date();
  presets.append(
    button('Zakres projektu','link',e=>{e.preventDefault();setRange(p.date_from,p.date_to)}),
    button('Cała pobrana poczta','link',e=>{e.preventDefault();setRange('','')}),
    button('Ten rok','link',e=>{e.preventDefault();setRange(today.getFullYear()+'-01-01',iso(today))}),
    button('Ostatnie 30 dni','link',e=>{e.preventDefault();const a=new Date(today);a.setDate(a.getDate()-30);setRange(iso(a),iso(today))}));
  for(const b of presets.children)b.type='button';
  filters.append(lf,lt,inf);
  form.append(filters,presets);
  form.onsubmit=async event=>{event.preventDefault();
    state.searchQuery=input.value.trim();state.searchFrom=from.value;state.searchTo=to.value;state.inflect=cb.checked;state.searchOffset=0;
    submit.disabled=true;submit.textContent='Szukam…';await runSearch();};
  box.append(form);
  const help=el('details','search-help');help.append(el('summary','','Jak szukać?'));
  const rows=[['Kowalski oferta','oba fragmenty w jednym mailu (nazwisko, imię, firma, numer – dowolny fragment)'],
    ['"oferta na ogrodzenie"','dokładna fraza, także przełamana do nowej linii'],
    ['Leonardo | Bauer','jedno albo drugie'],['-faktura','pomiń maile zawierające „faktura”'],
    ['od:Kowalski','tylko nadawca  ·  do:@firma.pl – tylko odbiorcy i DW'],
    ['temat:umowa','tylko temat  ·  plik:cennik – tylko nazwy załączników'],
    ['data:2024-03','tylko marzec 2024  ·  od:2024-01-01 do:2024-06-30  ·  data:15.03.2024'],
    ['(puste pole + daty)','wszystkie maile z wybranego okresu']];
  const table=el('div','help-grid');for(const [a,b] of rows){table.append(el('code','',a),el('span','',b))}
  help.append(table);box.append(help);
  if(state.searchResults){const r=state.searchResults;
    const range=(r.date_from||r.date_to)?` · ${r.date_from||'…'} – ${r.date_to||'…'}`:' · bez limitu dat';
    const info=el('p','search-info');
    info.append(el('strong','',`${r.total} trafień`),document.createTextNode(` z ${r.scanned} maili${range} · ${(r.elapsed_ms/1000).toFixed(2)} s`));
    if(r.terms&&r.terms.length)info.append(el('span','terms','Szukano: '+r.terms.join('  lub  ')));
    box.append(info);
    const list=el('div','search-results');
    for(const m of r.messages){const card=button('','mail-card hit',()=>openMessage(m.id).catch(e=>notice(e.message,true)));
      append(card,el('span','mini',fmtDate(m)+' · '+(m.account_label||m.account)+' · '+(m.folder||'INBOX')+(m.attachments&&m.attachments.length?' · 📎 '+m.attachments.length:'')),
        el('strong','',m.subject||'(bez tematu)'),el('p','sender',m.sender));
      if(m.snippet){const s=el('p','snippet');for(const seg of m.snippet.segments||[])s.append(seg.m?el('mark','',seg.t):document.createTextNode(seg.t));card.append(s)}
      if(m.found_in&&m.found_in.length){const tags=el('span','found-in');for(const f of m.found_in)tags.append(el('span','tag',f));card.append(tags)}
      list.append(card)}
    if(!r.total){const empty=el('div','hint empty-search');empty.append(el('p','','Brak trafień.'));
      const tips=el('ul');for(const t of ['Sprawdź zakres dat – kliknij „Cała pobrana poczta”.','Wpisz krótszy fragment, np. „kowals” zamiast „Kowalskiemu”.','Jeśli mail jest nowszy niż ostatnia synchronizacja, kliknij „Indeksuj / synchronizuj pocztę”.','Maile spoza zakresu dat pobranych projektów nie są jeszcze na komputerze – utwórz projekt z szerszym zakresem i zsynchronizuj.'])tips.append(el('li','',t));
      empty.append(tips);list.append(empty)}
    box.append(list);
    if(r.total>r.page_size){const pager=el('div','pager'),prev=button('← Poprzednie','secondary',async()=>{state.searchOffset=Math.max(0,state.searchOffset-r.page_size);await runSearch()}),next=button('Następne →','secondary',async()=>{state.searchOffset+=r.page_size;await runSearch()});
      prev.disabled=!state.searchOffset;next.disabled=state.searchOffset+r.messages.length>=r.total;
      pager.append(prev,el('span','',`${state.searchOffset+1}–${state.searchOffset+r.messages.length} z ${r.total}`),next);box.append(pager)}}
  root.append(box)}
async function runSearch(){const projectId=state.projectId;
  try{const result=await post('project/search',{id:projectId,query:state.searchQuery,offset:state.searchOffset,date_from:state.searchFrom||'',date_to:state.searchTo||'',inflect:state.inflect});
    if(projectId!==state.projectId)return;state.searchResults=result;renderWorkspace()}catch(e){notice(e.message,true);renderWorkspace()}}
async function syncProject(){try{await post('project/sync',{id:state.projectId});notice('Indeksowanie trwa w tle. Możesz zostać w zakładce Rozmowa.');watchSync()}catch(e){notice(e.message,true)}}
async function watchSync(){clearTimeout(state.syncTimer);const projectId=state.projectId;try{const job=await get('project/sync-status?id='+projectId);if(projectId!==state.projectId)return;const parts=Object.values(job.progress||{}).map(p=>`${p.account} · ${p.folder||'INBOX'} (folder ${p.folder_no||1}/${p.folders||1}): ${p.folder_checked||0}/${p.folder_available||0} sprawdzonych, nowych do pobrania w folderze ${p.folder_new||0}, pobrano łącznie ${p.imported||0}, załączniki ${p.attachment_indexed||0}, błędy ${p.failed}`);state.syncText=job.running?'Indeksowanie trwa · '+(parts.join('; ')||'łączę z serwerem…'):job.results.length?'Indeksowanie zakończone · '+job.results.map(r=>r.error?`${r.account}: ${r.error}`:`${r.account}: ${r.imported} nowych w archiwum, ${r.added} w projekcie, ${r.attachment_indexed||0} załączników odczytanych, ${r.failed} błędów`).join('; '):'';const progress=$('#syncProgress');if(progress)progress.textContent=state.syncText;if(job.running){state.syncTimer=setTimeout(watchSync,1500)}else if(job.results.length){await refreshProject()}}catch(e){notice(e.message,true)}}
async function watchDocuments(){clearTimeout(state.docTimer);const projectId=state.projectId;try{const job=await get('project/attachment-status?id='+projectId);if(projectId!==state.projectId)return;state.docText=job.running?`Załączniki: ${job.checked}/${job.total}, wczytano ${job.indexed}, błędy ${job.failed}`:job.total?`Załączniki gotowe: ${job.indexed}, błędy ${job.failed}. Szczegóły w dzienniku.`:'';const progress=$('#documentProgress');if(progress)progress.textContent=state.docText;if(job.running)state.docTimer=setTimeout(watchDocuments,1500)}catch(e){notice(e.message,true)}}
function renderChat(right){const conversation=el('div','conversation');conversation.id='conversation';const history=state.data.history;
  if(!history.length)conversation.append(el('div','chat-empty','Zapytaj o korespondencję w tym projekcie, np. „Co pisał Kowalski w marcu 2024?”, „Ile maili od Bauera w zeszłym roku?” lub „Czego dotyczyła oferta na ogrodzenie?”. Daty w pytaniu (miesiąc i rok, 2024, 15.03.2024, „w tym roku”, „ostatni miesiąc”) zawężają wyszukiwanie. Tryb lokalny pokazuje znalezione fragmenty.'));
  for(const entry of history){const turn=el('div','turn');turn.id='question-'+entry.id;append(turn,el('div','question',entry.question),el('div','answer',entry.answer));const sources=el('div','sources');sources.append(el('span','',entry.mode==='ai'?'AI · źródła: ':'Wyszukiwanie lokalne · źródła: '));for(const id of entry.sources){sources.append(button('Wiadomość '+id,'source-button',()=>openMessage(id).catch(e=>notice(e.message,true))))}turn.append(sources);conversation.append(turn)}right.append(conversation);
  const composer=el('div','composer'),input=el('textarea');input.placeholder='Wpisz pytanie, np. Co ustalono z Kowalskim w marcu 2024?';input.maxLength=1000;composer.append(input);const actions=el('div','composer-actions');actions.append(el('span','','Przeszukiwana jest cała pobrana poczta projektu oraz tekst wczytanych załączników. AI otrzymuje wybrane źródła.'));const choices=el('div');const local=button('Szukaj lokalnie','secondary',()=>ask('local'));const ai=button('Zapytaj AI','',()=>ask('ai'));ai.disabled=!state.ai;choices.append(local,ai);actions.append(choices);composer.append(actions);right.append(composer);
  async function ask(mode){const question=input.value.trim();if(!question)return notice('Wpisz pytanie.',true);local.disabled=ai.disabled=true;try{await post('project/ask',{id:state.projectId,question,mode});await refreshProject();$('#conversation').scrollTop=$('#conversation').scrollHeight}catch(e){notice(e.message,true);local.disabled=false;ai.disabled=!state.ai}}
}
function renderMail(right){const m=state.message;const pane=el('div','mail-detail');right.append(pane);if(!m){pane.append(el('p','hint','Otwórz źródło z odpowiedzi albo użyj przycisku „Pokaż listę maili”.'));return}
  append(pane,el('span','eyebrow',m.account_label+' · '+(m.folder_label||m.folder||'INBOX')),el('h3','',m.subject||'(bez tematu)'),el('div','meta','Od: '+m.sender+'\nDo: '+m.recipient+(m.cc?'\nCC: '+m.cc:'')+'\nData: '+m.received+'\nZałączniki: '+(m.attachments.join(', ')||'brak')),el('div','mail-body',m.body||'(brak treści tekstowej)'));
  if(m.attachments.length){const box=el('div','attachment-box');box.append(el('h3','','Załączniki'));m.attachments.forEach((name,index)=>{const row=el('div','attachment-row'),stored=state.documents.find(d=>d.part_index===index);row.append(el('span','',name+(stored?' · tekst w indeksie ('+stored.length+' znaków)':'')));row.append(button('Wczytaj do analizy','secondary',async()=>{try{const result=await post('attachment/index',{id:m.id,index});const updated=await get('message?id='+m.id);state.documents=updated.documents;renderWorkspace();notice('Wczytano tekst: '+result.filename)}catch(e){notice(e.message,true)}}));if(stored)row.append(button('Czytaj tekst','secondary',async()=>{try{const result=await get('attachment/text?id='+m.id+'&index='+index);const preview=el('pre','attachment-preview',result.text);row.after(preview)}catch(e){notice(e.message,true)}}));row.append(button('Pobierz plik','secondary',()=>{window.location.href='/api/attachment?id='+m.id+'&index='+index}));box.append(row)});pane.append(box)}
  if(m.status!=='wysłane'){const actions=el('div','mail-actions');actions.append(button('Analizuj lokalnie (reguły)','secondary',()=>analyze('demo')),button('Analizuj przez AI','',()=>analyze('ai')));actions.lastChild.disabled=!state.ai;pane.append(actions)}
  if(m.status==='szkic'||m.status==='wysłane'){const a=el('div','analysis');append(a,el('small','','Kategoria · '+m.category+' | Priorytet · '+m.priority+' | Termin · '+(m.due||'nie wskazano')),el('div','','Streszczenie: '+m.summary+'\nDziałanie: '+m.action));pane.append(a);const reply=el('div','mail-reply');reply.append(el('h3','',m.status==='wysłane'?'Wysłana odpowiedź':'Szkic odpowiedzi'));const to=el('input');to.value=(m.sender.match(/<([^<>]+)>/)||[])[1]||m.sender;const draft=el('textarea');draft.value=m.draft;if(m.status==='wysłane'){to.readOnly=draft.readOnly=true}append(reply,el('label','','Odbiorca'),to,el('label','','Treść'),draft);if(m.status==='szkic'){const row=el('label','confirm-row'),check=el('input');check.type='checkbox';append(row,check,el('span','','Sprawdziłem odbiorcę i treść'));reply.append(row);const send=button('Wyślij przez '+m.account_label,'',async()=>{if(!window.confirm('Wysłać z konta '+m.account_label+' do '+to.value+'?'))return;try{await post('send',{id:m.id,to:to.value,draft:draft.value,confirm:true});state.message=(await get('message?id='+m.id)).message;await refreshProject();notice('Wiadomość wysłana.')}catch(e){notice(e.message,true)}});send.disabled=true;check.onchange=()=>send.disabled=!check.checked;reply.append(send);if(m.uid.startsWith('demo-'))reply.append(el('p','hint','Przykładowe wiadomości nie mogą zostać wysłane.'))}pane.append(reply)}
  async function analyze(mode){try{await post('analyze',{id:m.id,mode});const updated=await get('message?id='+m.id);state.message=updated.message;await refreshProject();notice('Analiza gotowa.')}catch(e){notice(e.message,true)}}
}
/* 5.6 — Archiwum poczty */
function fmtBytes(n){n=Number(n||0);const u=['B','KB','MB','GB','TB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++}return (i<2?Math.round(n):n.toFixed(1).replace('.',','))+' '+u[i]}
function fmtEta(s){if(s===null||s===undefined)return 'liczę…';if(s<90)return 'mniej niż 2 min';const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return 'ok. '+(h?h+' h ':'')+m+' min'}
function fmtNum(n){return Number(n||0).toLocaleString('pl-PL')}
async function loadArchive(){clearTimeout(state.archiveTimer);
  try{if(!state.tbProfiles){try{state.tbProfiles=(await get('thunderbird/profiles')).profiles}catch(e){state.tbProfiles=[]}}const was=state.archive?.job?.running;state.archive=await get('archive/status');renderArchive();
    if(state.archive.job.running)state.archiveTimer=setTimeout(loadArchive,2000);
    else if(was){await loadProjects();if(state.projectId)await refreshProject()}}catch(e){}}
function archiveProgressText(job){const parts=[];
  for(const [acc,p] of Object.entries(job.progress||{})){if(acc==='thunderbird'){parts.push(p.phase==='done'?'Thunderbird: zakończono':`Thunderbird: przeczytano ${fmtBytes(p.bytes_done)} z ${fmtBytes(p.bytes_total)} · pliki ${p.files_done}/${p.files} · nowych maili ${fmtNum(p.imported)} · folder ${p.folder} · zostało ${fmtEta(p.eta_seconds)}`);continue}const name=(state.accounts[acc]?.label||acc).split(' ')[0];
    if(p.phase==='scan')parts.push(`${name}: sprawdzam foldery ${p.folder_no}/${p.folders} · do pobrania ${fmtNum(p.total_new)} maili`);
    else if(p.phase==='download')parts.push(`${name}: ${fmtNum(p.done_new)} / ${fmtNum(p.total_new)} maili · ${fmtBytes(p.bytes_done)} z ${fmtBytes(p.bytes_total)} · folder ${p.folder} · zostało ${fmtEta(p.eta_seconds)}`);
    else parts.push(`${name}: zakończono`)}
  return parts.join('\n')||'Łączę z serwerem…'}
function renderThunderbird(box){const a=state.archive,tb=a.thunderbird||{},profiles=state.tbProfiles||[];
  const d=el('details','archive-form tb-form');d.open=state.tbOpen??(!tb.source&&!a.settings.date_from);d.ontoggle=()=>{state.tbOpen=d.open};
  d.append(el('summary','',tb.source?'Thunderbird: indeksuj / ustawienia':'Archiwum z Thunderbirda (zalecane)'));
  d.append(el('p','hint','Thunderbird pobiera pocztę, a Mail Desk tylko czyta jego pliki (niczego w nich nie zmienia) i buduje szybki indeks. Załączniki otwierają się z plików Thunderbirda – bez drugiej kopii na dysku.'));
  const path=el('input');path.placeholder='Folder profilu Thunderbirda';path.value=state.tbPath??(tb.source||profiles[0]?.path||'');path.oninput=()=>{state.tbPath=path.value;state.tbInspect=null};
  if(profiles.length){const sel=el('select');for(const p of profiles){const o=el('option','',p.name+' ('+p.accounts.join(', ')+')');o.value=p.path;sel.append(o)}
    const other=el('option','','inny folder…');other.value='';sel.append(other);sel.value=profiles.some(p=>p.path===path.value)?path.value:'';
    sel.onchange=()=>{if(sel.value){state.tbPath=sel.value;state.tbInspect=null;renderArchive()}else{path.focus()}};
    const ls=el('label','','Znaleziony profil');ls.append(sel);d.append(ls)}
  else d.append(el('p','hint','Nie znalazłem Thunderbirda automatycznie. Wklej ścieżkę do folderu profilu (Thunderbird: Pomoc → Więcej informacji dla rozwiązywania problemów → Folder profilu).'));
  const lp=el('label','','Folder');lp.append(path);d.append(lp);
  d.append(button('Sprawdź konta i foldery','secondary',async()=>{try{state.tbPath=path.value.trim();state.tbInspect=await post('thunderbird/inspect',{path:state.tbPath});state.tbOpen=true;renderArchive()}catch(e){notice(e.message,true)}}));
  if(state.tbInspect){state.tbMapping=state.tbMapping||{};
    for(const acc of state.tbInspect.accounts){const row=el('div','tb-account');const sel=el('select');
      for(const [v,t] of [['tabal','TABAL'],['skyfens','Skyfens'],['','pomiń']]){const o=el('option','',t);o.value=v;sel.append(o)}
      sel.value=state.tbMapping[acc.dir]??acc.account;state.tbMapping[acc.dir]=sel.value;sel.onchange=()=>{state.tbMapping[acc.dir]=sel.value};
      const info=el('div');info.append(el('strong','',acc.name),el('span','',` ${acc.folders} folderów · ${fmtBytes(acc.bytes)}`));
      row.append(info,sel);d.append(row)}
    if(!state.tbInspect.accounts.length)d.append(el('p','hint','W tym folderze nie ma poczty Thunderbirda.'))}
  const auto=el('label','check'),ab=el('input');ab.type='checkbox';ab.checked=tb.auto_update!==false;auto.append(ab,el('span','','Przy starcie aplikacji dociągaj to, co Thunderbird pobrał'));d.append(auto);
  d.append(button(tb.source?'Indeksuj ponownie (tylko nowe)':'Indeksuj archiwum Thunderbirda','',async()=>{
    try{await post('thunderbird/index',{path:(state.tbPath??path.value).trim(),mapping:state.tbInspect?state.tbMapping:null,auto_update:ab.checked});
      notice('Indeksowanie trwa w tle. Pierwszy raz przy dużej poczcie może potrwać – kolejne tylko chwilę.');loadArchive()}catch(e){notice(e.message,true)}}));
  box.append(d)}
function renderArchive(){const box=$('#archiveBox');if(!box||!state.archive)return;box.replaceChildren();
  const a=state.archive,st=a.settings,job=a.job,total=a.accounts.reduce((s,x)=>s+x.messages,0),copies=a.accounts.reduce((s,x)=>s+x.with_copy,0),copyBytes=a.accounts.reduce((s,x)=>s+x.copy_bytes,0);
  const first=a.accounts.map(x=>x.first_day).filter(Boolean).sort()[0]||'',last=a.accounts.map(x=>x.last_day).filter(Boolean).sort().pop()||'';
  if(st.date_from){
    const info=el('div','archive-info');
    info.append(el('strong','',fmtNum(total)+' maili'),el('span','',first&&last?first+' – '+last:''),
      el('span','',a.thunderbird&&a.thunderbird.source?`źródło: Thunderbird · ${fmtNum(a.thunderbird.messages)} maili w jego plikach`:st.store_raw?`pełne kopie: ${fmtNum(copies)} (${fmtBytes(copyBytes)})`:'tylko tekst (bez kopii plików)'),
      el('span','',`baza ${fmtBytes(a.db_bytes)} · wolne ${fmtBytes(a.free_bytes)}`),
      el('span','',st.last_update?'aktualizacja: '+new Date(st.last_update).toLocaleString('pl-PL',{dateStyle:'short',timeStyle:'short'}):'nie ukończono pobierania'));
    box.append(info);
    if(st.project_id)box.append(button('Otwórz archiwum','',()=>openProject(st.project_id).catch(e=>notice(e.message,true))));
  }else{box.append(el('p','hint','Pobierz całą pocztę na ten komputer. Potem wyszukiwanie, rozmowa i załączniki działają bez Internetu.'))}
  if(job.running){
    box.append(el('div','archive-progress',({'aktualizacja':'Sprawdzam nowe maile…\n','thunderbird':'Indeksuję archiwum Thunderbirda…\n','aktualizacja Thunderbirda':'Sprawdzam, co Thunderbird pobrał…\n'}[job.mode]||'Pobieranie archiwum…\n')+archiveProgressText(job)));
    box.append(button(job.stop?'Zatrzymuję…':'Zatrzymaj (dokończę później)','secondary',async()=>{await post('archive/stop',{});loadArchive()}));
    return}
  if(job.results&&job.results.length){const msg=job.results.map(r=>r.account==='thunderbird'?(r.error?'Thunderbird: '+r.error:`Thunderbird: nowych ${fmtNum(r.imported)}, pominiętych usuniętych ${fmtNum(r.deleted_skipped)}${r.partial?', niepełnych '+fmtNum(r.partial):''}${r.failed?', błędów '+r.failed:''}${r.stopped?' (zatrzymano)':''}`):r.error?`${(state.accounts[r.account]?.label||r.account||'').split(' ')[0]}: ${r.error}`:`${(state.accounts[r.account]?.label||r.account).split(' ')[0]}: nowych ${fmtNum(r.imported)}${r.raw_saved?', kopii '+fmtNum(r.raw_saved):''}${r.failed?', błędów '+r.failed:''}${r.stopped?' (zatrzymano)':''}`).join('\n');
    box.append(el('div','archive-progress done',msg))}
  if(a.thunderbird&&a.thunderbird.partial)box.append(el('div','archive-progress warn',`Uwaga: ${fmtNum(a.thunderbird.partial)} maili Thunderbird pobrał bez pełnej treści. W Thunderbirdzie odznacz „Nie pobieraj wiadomości większych niż…” i zsynchronizuj ponownie.`));
  renderThunderbird(box);
  const form=el('details','archive-form');
  form.append(el('summary','','Pobierz bezpośrednio z serwera (bez Thunderbirda)'));
  const from=el('input');from.type='date';from.value=st.date_from||'2021-01-01';
  const lf=el('label','','Od daty');lf.append(from);
  const raw=el('label','check'),cb=el('input');cb.type='checkbox';cb.checked=st.store_raw!==false;raw.append(cb,el('span','','Zapisuj pełne maile z załącznikami (pliki dostępne offline)'));
  const auto=el('label','check'),ab=el('input');ab.type='checkbox';ab.checked=st.auto_update!==false;auto.append(ab,el('span','','Dociągaj nowe maile przy starcie aplikacji'));
  const go=button(st.date_from?'Uzupełnij teraz':'Pobierz archiwum','',async()=>{
    const accounts=Object.values(state.accounts).filter(x=>x.configured);
    if(!accounts.length)return notice('Najpierw wpisz login i hasło skrzynki w „Konfiguracja kont i AI”.',true);
    try{await post('archive/start',{date_from:from.value,store_raw:cb.checked,auto_update:ab.checked});notice('Pobieranie trwa w tle. Możesz pracować dalej; komputer nie powinien zasypiać.');loadArchive()}catch(e){notice(e.message,true)}});
  form.append(lf,raw,auto,go,el('p','hint','Pierwsze pobieranie kilku lat poczty może trwać kilka godzin – najlepiej zostawić na noc. Przerwanie jest bezpieczne: kolejne uruchomienie dokończy od miejsca przerwania.'));
  box.append(form);
  if(total){const folders=el('details','archive-folders');folders.append(el('summary','',`Foldery (${a.accounts.reduce((s,x)=>s+x.folders.length,0)})`));
    for(const acc of a.accounts){if(!acc.folders.length)continue;folders.append(el('div','folder-head',acc.label));
      for(const f of acc.folders){const row=el('div','folder-row');row.append(el('span','',f.folder),el('span','',fmtNum(f.n)));folders.append(row)}}
    box.append(folders)}}
$('#projectForm').onsubmit=async event=>{event.preventDefault();try{const p=await post('project/create',{name:$('#name').value,date_from:$('#dateFrom').value,date_to:$('#dateTo').value,sender_query:$('#senderQuery').value,account:$('#account').value});$('#createBox').open=false;$('#projectForm').reset();await openProject(p.id);notice(p.local_messages?'Projekt zapisany. Z archiwum na komputerze dodano '+p.local_messages+' maili.':'Projekt zapisany. Możesz pobrać maile lub dodać przykłady.')}catch(e){notice(e.message,true)}};
$('#errorsButton').onclick=async()=>{try{const rows=(await get('mail-errors')).errors;const root=$('#workspace');root.replaceChildren(el('h2','','Dziennik błędów IMAP/SMTP'));root.append(button('Wróć do projektu','secondary',()=>state.projectId&&openProject(state.projectId)),button('Pobierz pełny log','secondary',()=>{window.location.href='/api/mail-errors/export'}));if(!rows.length)root.append(el('p','hint','Brak błędów poczty.'));for(const row of rows){const e=el('div','log-entry');append(e,el('small','',row.created_at+' · '+row.account+' · '+row.operation),el('div','',row.detail));root.append(e)}}catch(e){notice(e.message,true)}};
for(const [account,id,label] of [['tabal','checkTabal','TABAL'],['skyfens','checkSkyfens','Skyfens']]){$('#'+id).onclick=async()=>{const target=$('#checkResults');target.className='check-results';target.textContent='Sprawdzam '+label+'…';try{const result=await post('imap/check',{account});target.className='check-results '+(result.ok?'passed':'failed');target.textContent=label+': '+result.message}catch(e){target.className='check-results failed';target.textContent=label+': '+e.message}}}
for(const account of ['tabal','skyfens']){$('#'+account+'Form').onsubmit=async event=>{event.preventDefault();const form=event.currentTarget,submit=form.querySelector('button'),login=$('#'+account+'Login'),password=$('#'+account+'Password');submit.disabled=true;try{await post('account/config',{account,login:login.value,password:password.value});password.value='';await loadProjects();$('#'+(account==='tabal'?'checkTabal':'checkSkyfens')).click()}catch(e){notice(e.message,true)}finally{submit.disabled=false}}}
$('#aiForm').onsubmit=async event=>{event.preventDefault();const input=$('#aiKey'),submit=$('#aiForm button');submit.disabled=true;try{await post('ai/config',{key:input.value});input.value='';await loadProjects();$('#checkAI').click()}catch(e){notice(e.message,true)}finally{submit.disabled=false}};
$('#checkAI').onclick=async()=>{const target=$('#aiCheckResults'),button=$('#checkAI');button.disabled=true;target.className='check-results';target.textContent='Sprawdzam model…';try{const r=await post('ai/check',{});target.className='check-results '+(r.ok?'passed':'failed');target.textContent=r.model+': '+r.message}catch(e){target.className='check-results failed';target.textContent=e.message}finally{button.disabled=false}};
const today=new Date(),monthAgo=new Date(today);monthAgo.setDate(today.getDate()-30);const dateText=d=>[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');$('#dateTo').value=dateText(today);$('#dateFrom').value=dateText(monthAgo);
loadProjects().then(()=>{loadArchive();for(const account of ['tabal','skyfens'])$('#'+account+'Login').value=state.accounts[account]?.login||'';const saved=Number(localStorage.getItem('maildesk_project'));if(saved&&state.projects.some(p=>p.id===saved))return openProject(saved)}).catch(e=>notice(e.message,true));
