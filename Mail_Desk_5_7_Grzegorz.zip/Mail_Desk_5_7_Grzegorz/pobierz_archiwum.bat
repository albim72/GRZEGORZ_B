@echo off
cd /d "%~dp0"
echo Mail Desk - pobieranie archiwum poczty
echo.
if not exist .venv\Scripts\python.exe (
  where py >nul 2>nul
  if %errorlevel%==0 (
    py -3 -m venv .venv
  ) else (
    python -m venv .venv
  )
)
.venv\Scripts\python -c "import pypdf" >nul 2>nul
if errorlevel 1 .venv\Scripts\python -m pip install --disable-pip-version-check -r requirements.txt
set /p OD=Od jakiej daty pobrac poczte? [Enter = 2021-01-01]: 
if "%OD%"=="" set OD=2021-01-01
.venv\Scripts\python maildesk.py --archiwum %OD%
echo.
pause
