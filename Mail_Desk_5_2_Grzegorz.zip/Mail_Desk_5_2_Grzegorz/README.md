# Mail Desk 5.2 — TABAL i Skyfens

Lokalna aplikacja dla Grzegorza do pracy z wieloletnią pocztą firmową. Wersja 5.2 jest nastawiona na **indeksowanie i wyszukiwanie**, a nie na wyświetlanie tysięcy wiadomości.

## Co zmieniło się w 5.2

- Brak limitu 100 wiadomości. Zakres projektu może obejmować wiele lat.
- Program skanuje wszystkie dostępne foldery IMAP z wyjątkiem Kosza, Spamu/Junk i Szkiców. Dzięki temu obejmuje również pocztę wysłaną i archiwalną, jeśli serwer ją udostępnia.
- Każda nowa wiadomość jest pobierana w całości tylko raz i trafia do lokalnego archiwum SQLite. Kolejne synchronizacje rozpoznają już zapisane UID i nie pobierają ponownie pełnej treści.
- Wyszukiwanie projektu obejmuje: nadawcę, odbiorców, CC, nazwę osoby, adres e-mail, domenę, prawdopodobną nazwę firmy z domeny, temat, treść i nazwy załączników.
- Tworzony jest lokalny indeks pełnotekstowy SQLite FTS5. Pytania nie muszą skanować w Pythonie całej skrzynki przy każdym użyciu.
- Załączniki mają osobny indeks metadanych. Obsługiwane dokumenty są automatycznie odczytywane podczas pierwszego pobrania wiadomości i ich tekst trafia do wyszukiwarki.
- Lista wiadomości jest **domyślnie ukryta**. Interfejs pokazuje liczbę wiadomości i załączników oraz rozmowę z wyszukiwarką. Listę można włączyć przyciskiem **Pokaż listę maili** tylko wtedy, gdy jest potrzebna.
- Źródła odpowiedzi nadal można otworzyć pojedynczo, bez renderowania całego archiwum.
- Pojedynczy uszkodzony mail lub załącznik nie zatrzymuje całej synchronizacji. Błąd trafia do dziennika.

## Uruchomienie

### macOS / Linux

1. Rozpakuj ZIP do osobnego folderu.
2. Otwórz Terminal, wpisz `sh ` ze spacją i przeciągnij do Terminala plik `start_mac_linux.sh`.
3. Naciśnij Enter. Przy pierwszym uruchomieniu przygotowanie środowiska może doinstalować `pypdf`.
4. Aplikacja powinna otworzyć `http://127.0.0.1:8765`. Terminal musi pozostać otwarty.
5. Zatrzymanie: `Ctrl+C`.

### Windows

Uruchom `start_windows.bat`. Aplikacja działa pod `http://127.0.0.1:8765`.

## Konfiguracja kont

W **Konfiguracja kont i AI** wpisz pełny login i hasło do skrzynki TABAL i/lub Skyfens. Następnie kliknij odpowiedni przycisk **Sprawdź IMAP**.

Dane logowania oraz klucz API są zapisywane lokalnie w `.env.local`. Tego pliku nie wysyłaj innym osobom i nie dołączaj do kolejnych ZIP-ów.

Do analizy AI potrzebny jest osobny klucz OpenAI API firmy. Bez klucza działa lokalne indeksowanie i wyszukiwanie.

## Jak pracować z dużą skrzynką

1. Utwórz projekt, np. `Agnieszka Kafel 2018-2026`.
2. Ustaw szeroki zakres dat.
3. W polu **Osoba / firma / e-mail / domena** możesz wpisać np.:
   - `Agnieszka Kafel`
   - `comarch`
   - `@comarch.pl`
   - `bauer`
   - fragment adresu e-mail
   - nazwę występującą w temacie, treści lub nazwie załącznika.
4. Kliknij **Indeksuj / synchronizuj pocztę**.
5. Program przejdzie po folderach skrzynki, zapisze nowe wiadomości i utworzy indeks. Wiadomości nie muszą być wyświetlane na ekranie.
6. W zakładce **Rozmowa** zadawaj pytania do całego projektu.

Przykłady:

- `Ile wiadomości pasuje do tego projektu?`
- `Znajdź maile od Agnieszki dotyczące szkoleń.`
- `W których wiadomościach występuje domena comarch.pl?`
- `Znajdź załącznik dotyczący cen z 2021 roku.`
- `Co było ustalane w sprawie CRISP-DM?`

## Załączniki

Przy pierwszym pobraniu nowej wiadomości program zapisuje metadane wszystkich załączników. Tekst jest automatycznie wydobywany z obsługiwanych typów:

- TXT, CSV, MD, JSON, XML, HTML,
- DOCX,
- XLSX,
- tekstowy PDF.

Nie są automatycznie odczytywane skany PDF wymagające OCR, obrazy, stare DOC/XLS i pliki zabezpieczone hasłem. Takie pliki pozostają widoczne w indeksie metadanych po nazwie.

Przycisk **Uzupełnij indeks załączników** służy głównie do starszych wiadomości już zapisanych przez wcześniejsze wersje aplikacji albo do ponowienia odczytu dokumentów.

Limity bezpieczeństwa pozostają: pełna wiadomość 30 MB, pojedynczy załącznik 15 MB.

## Aktualizacja z 5.1

Jeżeli używasz tych samych skrzynek Grzegorza, możesz skopiować do folderu 5.2:

- `.env.local`
- `maildesk.sqlite3`

Baza zostanie automatycznie rozszerzona o nowe pola i indeksy. Po uruchomieniu kliknij **Indeksuj / synchronizuj pocztę**, aby 5.2 uzupełniła foldery i dane, których 5.1 wcześniej nie indeksowała.

Jeżeli zmieniasz konto z testowego `martin@...` na właściwe konto Grzegorza, zacznij w czystym folderze i nie kopiuj starej bazy.

## Bezpieczeństwo i wysyłka

- Aplikacja nasłuchuje wyłącznie lokalnie na `127.0.0.1`.
- Wiadomości oraz indeks są przechowywane lokalnie w `maildesk.sqlite3`.
- Treść trafia do OpenAI API dopiero po wybraniu trybu **Zapytaj AI** lub **Analizuj przez AI**.
- AI otrzymuje wybrane trafne źródła, nie całą skrzynkę.
- Wysyłka SMTP nadal wymaga jawnego potwierdzenia odbiorcy i treści.

## Testy

Uruchom:

```bash
python3 -m unittest discover -s tests -v
```

Paczka 5.2 została sprawdzona zestawem 17 testów obejmujących m.in. duży zakres wiadomości, wiele folderów IMAP, filtrowanie osób/firm, CC, indeks FTS, załączniki, duplikaty, błędy pojedynczych UID i bezpieczeństwo wysyłki.
