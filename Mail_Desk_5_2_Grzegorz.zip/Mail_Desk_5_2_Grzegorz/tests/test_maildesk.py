import io
import imaplib
import json
import os
import socket
import sys
import tempfile
import time
import unittest
import urllib.error
import zipfile
from datetime import datetime, timezone
from email.message import EmailMessage
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import maildesk as app


class FakeIMAP:
    fetch_calls = 0
    def __init__(self, host, port):
        self.host, self.port = host, port
    def login(self, user, password):
        assert user == "martin@tabal.pl"
    def select(self, mailbox, readonly=False):
        assert readonly is True
        return "OK", [b"1"]
    def uid(self, action, *args):
        if action == "search":
            return "OK", [b"101"]
        assert args[-1] in ("(BODY.PEEK[])", "(BODY.PEEK[HEADER] INTERNALDATE)")
        if args[-1] == "(BODY.PEEK[])":
            FakeIMAP.fetch_calls += 1
        msg = EmailMessage()
        msg["From"] = "Klient <klient@example.org>"
        msg["To"] = "martin@tabal.pl"
        msg["Subject"] = "Oferta tablic"
        msg["Message-ID"] = "<mail-101@example.org>"
        msg["Date"] = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
        msg.set_content("Proszę o ofertę do piątku")
        return "OK", [(b"1 (BODY[] {100}", msg.as_bytes())]
    def logout(self):
        pass


class FakeSMTP:
    sent = []
    def __init__(self, host, port, timeout):
        assert (host,port) == ("smtp.example.org",587)
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def starttls(self,context): pass
    def login(self,user,password):
        assert user == "martin@tabal.pl"
    def send_message(self,msg):
        self.sent.append(msg)


class FakeResponse:
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def read(self,*args): return self.blob


class MailDeskTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ,{
            "TABAL_LOGIN":"martin@tabal.pl","TABAL_PASSWORD":"fake-test-password",
            "TABAL_IMAP_HOST":"imap.example.org","TABAL_SMTP_HOST":"smtp.example.org",
            "TABAL_SMTP_PORT":"587","TABAL_SMTP_SECURITY":"starttls",
            "OPENAI_API_KEY":"fake-test-key"})
        self.env.start()
        FakeIMAP.fetch_calls = 0
        FakeSMTP.sent = []
        app.JOBS.clear()
        app.DOCUMENT_JOBS.clear()
    def tearDown(self):
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()

    def test_full_flow_and_no_duplicate_send(self):
        first = app.sync_account("tabal", FakeIMAP)
        second = app.sync_account("tabal", FakeIMAP)
        self.assertEqual(first["imported"],1)
        self.assertEqual(second["skipped"],1)
        self.assertEqual(FakeIMAP.fetch_calls,1)
        with app.connect() as db:
            row = db.execute("SELECT * FROM messages").fetchone()
            message_id = row["id"]
        app.analyze(message_id,"demo")
        with self.assertRaises(ValueError):
            app.send_mail(message_id,"klient@example.org","Treść",False,FakeSMTP)
        result = app.send_mail(message_id,"klient@example.org","Odpowiedź testowa",True,FakeSMTP)
        self.assertEqual(result["from"],"martin@tabal.pl")
        self.assertEqual(len(FakeSMTP.sent),1)
        self.assertEqual(FakeSMTP.sent[0]["In-Reply-To"],"<mail-101@example.org>")
        with self.assertRaises(ValueError):
            app.send_mail(message_id,"klient@example.org","Ponownie",True,FakeSMTP)

    def test_demo_messages_cannot_send(self):
        app.demo_seed()
        with app.connect() as db:
            row = db.execute("SELECT id FROM messages LIMIT 1").fetchone()
        app.analyze(row["id"],"demo")
        with self.assertRaisesRegex(ValueError,"Przykładowe"):
            app.send_mail(row["id"],"klient@example.org","Szkic",True,FakeSMTP)
        self.assertFalse(FakeSMTP.sent)

    def test_api_analysis_structured_response_and_untrusted_email(self):
        app.sync_account("tabal",FakeIMAP)
        with app.connect() as db:
            row = dict(db.execute("SELECT * FROM messages").fetchone())
        expected = {"category":"Zapytanie","priority":"wysoki","summary":"Prośba o ofertę",
                    "action":"Przygotować ofertę","due":"piątek","draft":"Dzień dobry..."}
        output = {"output":[{"content":[{"type":"output_text","text":json.dumps(expected)}]}]}
        def fake_open(request,timeout):
            self.assertEqual(request.full_url,"https://api.openai.com/v1/responses")
            body = json.loads(request.data)
            self.assertFalse(body["store"])
            self.assertEqual(body["text"]["format"]["type"],"json_schema")
            response = FakeResponse()
            response.blob = json.dumps(output).encode()
            return response
        result = app.ai_analysis(row, fake_open)
        self.assertEqual(result,expected)

    def test_project_date_company_sync_and_question_history(self):
        today = app.date.today().isoformat()
        project = app.create_project("Klient Example",today,today,"example.org","tabal")
        result = app.sync_project_account(project["id"],"tabal",FakeIMAP)
        self.assertEqual((result["checked"],result["added"]),(1,1))
        self.assertEqual(app.sync_project_account(project["id"],"tabal",FakeIMAP)["added"],0)
        answer = app.ask_project(project["id"],"Jaka oferta i termin?","local")
        self.assertIn("Oferta tablic",answer["answer"])
        self.assertEqual(len(answer["sources"]),1)
        saved = app.project_data(project["id"])
        self.assertEqual(saved["history"][0]["question"],"Jaka oferta i termin?")
        self.assertEqual(saved["messages"][0]["account"],"tabal")
        self.assertTrue(app.sender_matches("Firma ABC <zakupy@abc.pl>","ABC"))
        self.assertFalse(app.sender_matches("Firma ABC <zakupy@abc.pl>","Inna"))

    def test_date_filter_and_error_log_redacts_password(self):
        old = (app.date.today()-app.timedelta(days=3)).isoformat()
        project = app.create_project("Stary projekt",old,old,"","tabal")
        result = app.sync_project_account(project["id"],"tabal",FakeIMAP)
        self.assertEqual(result["added"],0)  # server mocked; header date still checked locally
        class BrokenIMAP(FakeIMAP):
            def login(self,user,password):
                raise imaplib.IMAP4.error("LOGIN failed: " + password)
        with self.assertRaises(imaplib.IMAP4.error):
            app.sync_project_account(project["id"],"tabal",BrokenIMAP)
        with app.connect() as db:
            detail = db.execute("SELECT detail FROM mail_errors ORDER BY id DESC LIMIT 1").fetchone()[0]
        self.assertIn("[REDACTED]",detail)
        self.assertNotIn("fake-test-password",detail)
        self.assertIn("odrzucił login lub hasło",app.sync_error_message(
            imaplib.IMAP4.error("[AUTHENTICATIONFAILED] Authentication failed.")))
        self.assertNotIn("fake-test-password",app.sync_error_message(
            RuntimeError("server error: fake-test-password")))

    def test_demo_project_and_both_mail_smtp_config(self):
        today=app.date.today().isoformat()
        project=app.create_project("Pokaz",today,today,"","both")
        self.assertEqual(app.add_demo_to_project(project["id"])["added"],3)
        self.assertEqual(len(app.project_data(project["id"])["messages"]),3)
        with patch.dict(os.environ,{"TABAL_SMTP_PORT":"465","TABAL_SMTP_SECURITY":"ssl"}):
            cfg=app.env_account("tabal")
            self.assertEqual((cfg["smtp_port"],cfg["smtp_security"]),(465,"ssl"))
        sky=app.env_account("skyfens")
        self.assertEqual((sky["imap_host"],sky["smtp_port"],sky["smtp_security"]),
                         ("mail.skyfens.pl",587,"starttls"))

    def test_imap_connection_check_separates_network_and_login(self):
        class GoodIMAP:
            def __init__(self,host,port,timeout):
                self.assertion = (host,port,timeout)
            def login(self,user,password):
                self.user = user
            def logout(self): pass
        good=app.check_imap_account("tabal",GoodIMAP)
        self.assertTrue(good["ok"])
        self.assertEqual(good["stage"],"login")
        class RejectedIMAP(GoodIMAP):
            def login(self,user,password):
                raise imaplib.IMAP4.error("[AUTHENTICATIONFAILED] " + password)
        rejected=app.check_imap_account("tabal",RejectedIMAP)
        self.assertEqual(rejected["stage"],"login")
        self.assertNotIn("fake-test-password",rejected["message"])
        def no_dns(host,port,timeout):
            raise socket.gaierror(-3,"temporary DNS error")
        network=app.check_imap_account("tabal",no_dns)
        self.assertEqual(network["stage"],"connection")
        self.assertIn("DNS",network["message"])
        with app.connect() as db:
            detail=db.execute("SELECT detail FROM mail_errors WHERE operation='IMAP login test'").fetchone()[0]
        self.assertNotIn("fake-test-password",detail)

    def test_ai_check_separates_invalid_key_and_billing(self):
        def error_response(http_status, error_code):
            blob=io.BytesIO(json.dumps({"error":{"code":error_code}}).encode())
            return urllib.error.HTTPError("https://api.openai.com/v1/responses",http_status,"failure",{},blob)
        def invalid(request,timeout):
            self.assertEqual(json.loads(request.data)["model"],"gpt-4.1-mini")
            raise error_response(401,"invalid_api_key")
        failed=app.check_ai(invalid)
        self.assertEqual(failed["stage"],"key")
        self.assertIn("HTTP 401",failed["message"])
        def no_credit(request,timeout):
            raise error_response(429,"credit_balance_exhausted")
        billing=app.check_ai(no_credit)
        self.assertEqual(billing["stage"],"billing")
        self.assertIn("HTTP 429",billing["message"])
        def success(request,timeout):
            response=FakeResponse()
            response.blob=json.dumps({"status":"completed","model":"gpt-4.1-mini",
                "output":[{"content":[{"type":"output_text","text":"OK"}]}]}).encode()
            return response
        self.assertTrue(app.check_ai(success)["ok"])

    def test_project_ai_answer_uses_only_eligible_sources(self):
        today=app.date.today().isoformat()
        project=app.create_project("Źródła",today,today,"","tabal")
        app.sync_project_account(project["id"],"tabal",FakeIMAP)
        m=app.project_data(project["id"])["messages"][0]
        output={"output":[{"content":[{"type":"output_text","text":json.dumps({
            "answer":"Termin to piątek.","source_ids":[m["id"],999999]})}]}]}
        def fake_open(request,timeout):
            body=json.loads(request.data)
            self.assertFalse(body["store"])
            self.assertIn(str(m["id"]),body["input"])
            response=FakeResponse()
            response.blob=json.dumps(output).encode()
            return response
        answer, ids=app.answer_with_ai("Jaki termin?",[m],fake_open)
        self.assertIn("piątek",answer)
        self.assertEqual(ids,[m["id"]])

    def test_setup_saves_company_credentials_and_api_key_locally(self):
        with patch.object(app,"ROOT",Path(self.temp.name)):
            with self.assertRaisesRegex(ValueError,"@tabal.pl"):
                app.save_account_settings("tabal","someone@gmail.com","secret")
            result=app.save_account_settings("tabal","gbartosik@tabal.pl","test=secret")
            self.assertEqual(result,{"saved":True,"account":"tabal"})
            app.save_account_settings("tabal","gbartosik@tabal.pl","")
            api_key="sk-proj-"+"x"*40
            self.assertEqual(app.save_ai_settings(api_key)["model"],"gpt-4.1-mini")
            cfg=Path(self.temp.name)/".env.local"
            contents=cfg.read_text()
            self.assertEqual(contents.count("TABAL_PASSWORD="),1)
            self.assertIn("TABAL_PASSWORD=test=secret",contents)
            self.assertIn("OPENAI_API_KEY="+api_key,contents)
            self.assertEqual(cfg.stat().st_mode & 0o777,0o600)
            self.assertNotIn("test=secret",app.redact_secrets("failed test=secret"))
            self.assertNotIn(api_key,app.redact_secrets("failed "+api_key))
            self.assertEqual(set(app.ACCOUNTS),{"tabal","skyfens"})

    def test_switching_mailbox_login_cannot_mix_cached_messages(self):
        app.sync_account("tabal",FakeIMAP)
        with self.assertRaisesRegex(ValueError,"osobnym folderze"):
            app.save_account_settings("tabal","gbartosik@tabal.pl","different-password")
        self.assertEqual(app.env_account("tabal")["login"],"martin@tabal.pl")

    def test_many_years_partial_sender_failed_uid_and_full_project_search(self):
        class ManyIMAP:
            full_fetches = 0
            def __init__(self,host,port): pass
            def login(self,user,password): pass
            def select(self,name,readonly=False): return "OK",[b"300"]
            def uid(self, action, *args):
                if action == "search": return "OK",[b" ".join(str(i).encode() for i in range(1,301))]
                uid=int(args[0]); spec=args[1]
                if uid == 137 and spec == "(BODY.PEEK[])": return "NO",[]
                msg=EmailMessage()
                msg["From"]=("Peter Bauer" if uid<=260 else "Inny Klient")+" <pb@example.org>"
                msg["To"]="martin@tabal.pl"
                msg["Subject"]="kontrakt archeologiczny" if uid==1 else "Oferta nr "+str(uid)
                msg["Date"]="Mon, 01 Oct 2012 10:00:00 +0000"
                msg.set_content("Szczegóły współpracy " + str(uid))
                if spec=="(BODY.PEEK[])": ManyIMAP.full_fetches+=1
                return "OK",[(b'1 (INTERNALDATE "01-Oct-2012 10:00:00 +0000")',msg.as_bytes())]
            def logout(self): pass
        project=app.create_project("Wiele lat","2012-01-01",app.date.today().isoformat(),"baue","tabal")
        result=app.sync_project_account(project["id"],"tabal",ManyIMAP)
        self.assertEqual((result["available"],result["checked"],result["added"],result["failed"]),(300,300,259,1))
        # 5.2 deliberately indexes every message in the selected date range once,
        # even if the project filter does not match, so later people/company
        # searches can reuse the local archive without another full download.
        self.assertEqual(ManyIMAP.full_fetches,299)
        first=app.project_data(project["id"])
        self.assertEqual((first["total_messages"],len(first["messages"])),(259,50))
        self.assertEqual(len(app.project_data(project["id"],200)["messages"]),50)
        answer=app.ask_project(project["id"],"kontrakt archeologiczny","local")
        self.assertIn("kontrakt archeologiczny",answer["answer"])
        with app.connect() as db:
            errors=db.execute("SELECT operation FROM mail_errors").fetchall()
        self.assertTrue(any("137" in x[0] for x in errors))
        self.assertTrue(app.sender_matches("Piotr Łęcki <sprzedaz@tabal.pl>","lecki"))
        self.assertTrue(app.sender_matches("Peter Bauer <pb@example.org>","pb@exa"))

    def test_all_folders_cc_company_attachment_index_and_hidden_message_list(self):
        today=datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
        class FolderIMAP:
            def __init__(self,host,port): self.folder="INBOX"
            def login(self,user,password): pass
            def list(self):
                return "OK",[b'(\\HasNoChildren) "/" "INBOX"',
                             b'(\\Sent \\HasNoChildren) "/" "Sent"',
                             b'(\\Trash \\HasNoChildren) "/" "Trash"']
            def select(self,name,readonly=False): self.folder=name; return "OK",[b"1"]
            def uid(self,action,*args):
                if action=="search": return "OK",[b"11" if self.folder=="INBOX" else b"22"]
                uid=int(args[0]); spec=args[1]
                msg=EmailMessage()
                if self.folder=="INBOX":
                    msg["From"]="Losowy <x@example.org>"; msg["To"]="martin@tabal.pl"
                    msg["Subject"]="Inny temat"; msg.set_content("Bez związku")
                else:
                    msg["From"]="martin@tabal.pl"
                    msg["To"]="Agnieszka Kafel <agnieszka.kafel@comarch.pl>"
                    msg["Cc"]="Biuro COMARCH <biuro@comarch.pl>"
                    msg["Subject"]="Oferta analityczna"
                    msg.set_content("Ustalenia dotyczące szkolenia")
                    msg.add_attachment(b"sekretny kod: ALFA-2042",maintype="text",subtype="plain",filename="ustalenia.txt")
                msg["Message-ID"]=f"<{self.folder}-{uid}@example.org>"; msg["Date"]=today
                meta=f'1 (INTERNALDATE "{datetime.now(timezone.utc).strftime("%d-%b-%Y %H:%M:%S +0000")}")'.encode()
                return "OK",[(meta,msg.as_bytes())]
            def logout(self): pass
        project=app.create_project("COMARCH",app.date.today().isoformat(),app.date.today().isoformat(),"comarch","tabal")
        result=app.sync_project_account(project["id"],"tabal",FolderIMAP)
        self.assertEqual(result["imported"],2)
        self.assertEqual(result["added"],1)
        self.assertEqual([x["folder"] for x in result["folders"]],["INBOX","Sent"])
        compact=app.project_data(project["id"],include_messages=False)
        self.assertEqual(compact["messages"],[])
        self.assertEqual(compact["total_messages"],1)
        self.assertEqual(compact["stats"]["attachments"],1)
        self.assertEqual(compact["stats"]["indexed_attachments"],1)
        answer=app.ask_project(project["id"],"sekretny kod ALFA-2042","local")
        self.assertTrue(answer["sources"])
        with app.connect() as db:
            entities=[r[0] for r in db.execute("SELECT normalized FROM message_entities WHERE normalized LIKE '%comarch%'")]
        self.assertTrue(entities)

    def test_folder_parser_excludes_trash_junk_and_drafts(self):
        class Listing:
            def list(self): return "OK",[
                b'(\\HasNoChildren) "/" "INBOX"', b'(\\Sent) "/" "Sent Items"',
                b'(\\Trash) "/" "Trash"', b'(\\Junk) "/" "Junk"', b'(\\Drafts) "/" "Drafts"']
        self.assertEqual(app.list_mail_folders(Listing()),["INBOX","Sent Items"])

    def test_attachment_read_index_and_download_source(self):
        doc=io.BytesIO()
        with zipfile.ZipFile(doc,"w") as archive:
            archive.writestr("word/document.xml",'<w:document xmlns:w="x"><w:body><w:p><w:r><w:t>Termin targów 2030</w:t></w:r></w:p></w:body></w:document>')
        msg=EmailMessage()
        msg["From"]="Klient <klient@example.org>"
        msg["To"]="martin@tabal.pl"
        msg["Subject"]="Oferta"
        msg.set_content("Treść główna")
        msg.add_attachment(doc.getvalue(),maintype="application",subtype="vnd.openxmlformats-officedocument.wordprocessingml.document",filename="oferta.docx")
        raw=msg.as_bytes()
        class AttachedIMAP:
            def __init__(self,host,port): pass
            def login(self,user,password): pass
            def select(self,name,readonly=False): return "OK",[b"1"]
            def uid(self,action,*args):
                if action=="search": return "OK",[b"501"]
                return "OK",[(b"data",raw)]
            def logout(self): pass
        project=app.create_project("Załączniki",app.date.today().isoformat(),app.date.today().isoformat(),"klient","tabal")
        app.sync_project_account(project["id"],"tabal",AttachedIMAP)
        m=app.project_data(project["id"])["messages"][0]
        self.assertEqual(m["attachments"],["oferta.docx"])
        name,mime,blob=app.attachment_bytes(m["id"],0,AttachedIMAP)
        self.assertEqual((name,blob),("oferta.docx",doc.getvalue()))
        extracted=app.index_attachment(m["id"],0,AttachedIMAP)
        self.assertIn("Termin targów",extracted["text"])
        self.assertIn("Termin targów",app.attachment_text(m["id"],0)["text"])
        answer=app.ask_project(project["id"],"targów 2030","local")
        self.assertIn("targów",answer["answer"])

    def test_xlsx_shared_strings_and_pdf_text(self):
        sheet=io.BytesIO()
        with zipfile.ZipFile(sheet,"w") as archive:
            archive.writestr("xl/sharedStrings.xml",'<sst xmlns="x"><si><t>Grzegorz oferta</t></si></sst>')
            archive.writestr("xl/worksheets/sheet1.xml",'<worksheet xmlns="x"><sheetData><row><c t="s"><v>0</v></c><c><v>2027</v></c></row></sheetData></worksheet>')
        self.assertIn("Grzegorz oferta",app.extract_document("ceny.xlsx","application/octet-stream",sheet.getvalue()))
        try:
            from reportlab.pdfgen import canvas
            import pypdf
        except ImportError:
            return  # PDF dependency is installed by the launch script; XLSX still tested.
        pdf=io.BytesIO()
        c=canvas.Canvas(pdf)
        c.drawString(50,750,"Termin umowy 2027")
        c.save()
        self.assertIn("Termin umowy 2027",app.extract_document("umowa.pdf","application/pdf",pdf.getvalue()))

    def test_bulk_document_index_is_explicit_and_reports_progress(self):
        today=app.date.today().isoformat()
        project=app.create_project("Z dokumentami",today,today,"","tabal")
        with app.connect() as db:
            cur=db.execute("""INSERT INTO messages(account,uid,message_id,sender,recipient,subject,received,body,attachments)
                VALUES (?,?,?,?,?,?,?,?,?)""",("tabal","600","<600>","A <a@example.org>","martin@tabal.pl","Test",today,"Opis",'["plik.txt"]'))
            message_id=cur.lastrowid
            db.execute("INSERT INTO project_messages(project_id,message_id) VALUES (?,?)",(project["id"],message_id))
        with patch.object(app,"index_attachment",return_value={"indexed":True}) as mocked:
            app.start_document_index(project["id"])
            for _ in range(100):
                if not app.DOCUMENT_JOBS[project["id"]]["running"]: break
                time.sleep(.01)
            job=app.DOCUMENT_JOBS[project["id"]]
            self.assertFalse(job["running"])
            self.assertEqual((job["checked"],job["indexed"],job["total"]),(1,1,1))
            mocked.assert_called_once_with(message_id,0)


if __name__ == "__main__":
    unittest.main()
