const state = {projects:[], projectId:null, data:null, accounts:{}, ai:false, tab:'chat', messageId:null, message:null, documents:[], offset:0, showMessages:false, syncTimer:null, syncText:'', docTimer:null, docText:'', searchQuery:'', searchResults:null, searchOffset:0, inflect:true, archive:null, archiveTimer:null, analysisJob:null, analysisTimer:null, analysisView:null, analysisList:null, analysisEstimate:null, analysisScope:null, pendingQuestion:null, chatDraft:'', focus:[], meta:{}, latest:null, latestUnanswered:false, replies:[], replyId:null, replyEdits:{}, replyEditing:{}, replyDirty:false, thread:[], refresh:null, refreshSeq:null, unseen:0, askJob:null, chatFilter:'', chatRename:null, projectEdit:false};
const $ = selector => document.querySelector(selector);
function el(tag, cls='', value){const e=document.createElement(tag);if(cls)e.className=cls;if(value!==undefined)e.textContent=String(value);return e}
function append(parent,...children){parent.append(...children);return parent}
function button(label,cls,click){const b=el('button',cls,label);b.onclick=click;return b}
function notice(message,error=false){const n=$('#notice');n.textContent=message;n.className=error?'error':'';clearTimeout(notice.timer);notice.timer=setTimeout(()=>n.textContent='',9000)}
async function post(path,data){const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const result=await r.json();if(!r.ok)throw Error(result.error||'Błąd żądania');return result}
async function get(path){const r=await fetch('/api/'+path);const result=await r.json();if(!r.ok)throw Error(result.error||'Błąd pobierania');return result}
async function loadProjects(){const result=await get('projects');state.projects=result.projects;state.accounts=result.accounts;state.ai=result.ai_configured;state.chatModel=result.chat_model;state.effort=result.reasoning_effort;state.extractModel=result.extract_model;state.archiveProjectId=result.archive_project_id;renderSidebar()}
async function openProject(id){state.projectId=id;state.tab='chat';state.messageId=null;state.message=null;state.offset=0;state.showMessages=false;state.syncText='';state.docText='';state.searchQuery='';state.searchResults=null;state.searchOffset=0;state.focus=[];state.latest=null;state.stale=false;state.replyEdits={};state.replyDirty=false;state.projectEdit=false;state.chatFilter='';state.chatRename=null;clearTimeout(state.docTimer);try{localStorage.setItem('maildesk_project',String(id))}catch(e){}await refreshProject();watchDocuments();loadLatest(true)}
async function refreshProject(){if(!state.projectId)return;state.data=await get('project?id='+encodeURIComponent(state.projectId)+'&offset='+state.offset+'&list='+(state.showMessages?'1':'0'));
  state.meta=Object.assign(state.meta||{},state.data.meta||{});state.stale=false;await loadProjects();renderWorkspace()}
/* 5.14: projects have no dates – a project is a mailbox plus an optional filter, always up to date */
function accountText(a){return a==='both'?'obie skrzynki':(state.accounts[a]?.label||a)}
function projectCriteria(p){return accountText(p.account)+' · '+(p.sender_query?'filtr: '+p.sender_query:'cała poczta')+' · nowe maile dopisywane na bieżąco'}
function renderSidebar(){const projects=$('#projects');projects.replaceChildren();
  for(const p of state.projects){const b=el('button','project-link'+(p.id===state.projectId?' active':''));append(b,el('strong','',p.name),el('span','',fmtNum(p.message_count)+' wiadomości · '+accountText(p.account)+(p.sender_query?' · '+p.sender_query:'')));b.onclick=()=>openProject(p.id).catch(e=>notice(e.message,true));projects.append(b)}
  if(!state.projects.length)projects.append(el('p','empty-list','Utwórz pierwszy projekt.'));
}
function renderWorkspace(){const root=$('#workspace');root.replaceChildren();if(!state.data){root.append(el('div','welcome','Wybierz projekt lub utwórz nowy.'));return}
  const p=state.data.project,top=el('div','project-top'),intro=el('div');append(intro,el('span','eyebrow','Aktywny projekt'),el('h2','',p.name),el('div','criteria',projectCriteria(p)));top.append(intro);
  const isArchive=p.id===state.archiveProjectId;
  const actions=el('div','toolbar');actions.append(button('⟳ Sprawdź nową pocztę','',syncProject),button(state.showMessages?'Ukryj listę maili':'Pokaż listę maili','secondary',async()=>{state.showMessages=!state.showMessages;state.offset=0;await refreshProject()}),button('Uzupełnij indeks załączników','secondary',async()=>{try{await post('project/attachments/index',{id:p.id});watchDocuments()}catch(e){notice(e.message,true)}}));
  if(!isArchive)actions.append(button(state.projectEdit?'Zamknij edycję':'✎ Edytuj projekt','secondary',()=>{state.projectEdit=!state.projectEdit;renderWorkspace()}));
  top.append(actions);root.append(top);if(state.projectEdit&&!isArchive)root.append(projectEditor(p));const docProgress=el('div','sync-progress',state.docText);docProgress.id='documentProgress';root.append(docProgress);
  const status=el('div','status');for(const [key,a] of Object.entries(state.accounts))status.append(el('span','pill'+(a.configured?' ready':''),(a.configured?'● ':'○ ')+a.label+(a.configured?' · dane wpisane':' · brak hasła')));status.append(el('span','pill'+(state.ai?' ready':''),state.ai?'● Analiza AI · klucz wpisany':'○ Analiza AI · brak klucza'));const st=state.data.stats||{};status.append(el('span','pill ready','✉ '+fmtNum(state.data.total_messages)+' wiadomości'));status.append(el('span','pill ready','▣ '+fmtNum(st.attachments||0)+' załączników'));status.append(el('span','pill ready','⌕ '+fmtNum(st.indexed_attachments||0)+' załączników w indeksie'));if(st.last_received)status.append(el('span','pill','najnowszy mail: '+st.last_received));root.append(status);renderLatest(root);renderSearch(root);
  const grid=el('div','main-grid'+(state.showMessages?'':' single-grid'));if(state.showMessages){const left=el('section','mail-column'),title=el('div','panel-title');append(title,el('span','','Wiadomości'),el('span','',state.data.total_messages));left.append(title);const list=el('div','mail-list');for(const m of state.data.messages){const card=el('button','mail-card'+(state.messageId===m.id&&state.tab==='mail'?' active':''));append(card,el('span','mini',fmtDate(m)+' · '+m.account_label+' · '+(m.folder_label||m.folder||'INBOX')),el('strong','',m.subject||'(bez tematu)'),el('p','',m.sender+' · '+m.body.slice(0,120)));card.onclick=()=>openMessage(m.id).catch(e=>notice(e.message,true));list.append(card)}if(!state.data.messages.length)list.append(el('div','empty-list','Brak wiadomości pasujących do projektu.'));left.append(list);const pager=el('div','pager');const prev=button('← Poprzednie','secondary',()=>page(-1)),next=button('Następne →','secondary',()=>page(1));prev.disabled=state.offset===0;next.disabled=state.offset+state.data.messages.length>=state.data.total_messages;pager.append(prev,el('span','',state.data.total_messages?`${state.offset+1}–${state.offset+state.data.messages.length} z ${state.data.total_messages}`:'0 wiadomości'),next);left.append(pager);grid.append(left);}
  const right=el('section','right-pane'),tabs=el('div','pane-tabs');tabs.append(button('Rozmowa',state.tab==='chat'?'active':'',()=>{state.tab='chat';renderWorkspace()}),button('Wiadomość',state.tab==='mail'?'active':'',()=>{state.tab='mail';renderWorkspace()}),button('Analiza zbiorcza',state.tab==='analysis'?'active':'',async()=>{state.tab='analysis';await loadAnalyses();renderWorkspace()}));right.append(tabs);if(state.tab==='mail')renderMail(right);else if(state.tab==='analysis')renderAnalysis(right);else renderChat(right);grid.append(right);root.append(grid);renderSidebar()}
async function page(direction){state.offset=Math.max(0,state.offset+direction*state.data.page_size);await refreshProject()}
function fmtDate(m){const ts=m.received_ts;if(ts){const d=new Date(ts);if(!isNaN(d))return d.toLocaleString('pl-PL',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'})}return (m.received||'').slice(0,16)}
function renderSearch(root){const box=el('section','archive-search');
  const arch=state.data.archive||{};
  const head=el('div','search-head');head.append(el('h3','','Szukaj w poczcie'));
  if(arch.messages)head.append(el('span','hint',`Na komputerze: ${fmtNum(arch.messages)} maili · ${arch.first_day||'?'} – ${arch.last_day||'?'}`));
  box.append(head);
  const form=el('form','archive-search-form'),input=el('input');
  input.type='search';input.placeholder='np. Kowalski oferta · "umowa ramowa" · od:@firma.pl · Leonardo | Bauer · data:2024-03';input.maxLength=500;input.value=state.searchQuery;
  const submit=button('Szukaj','',()=>{});submit.type='submit';
  form.append(input,submit);
  const filters=el('div','search-filters');
  const inf=el('label','check'),cb=el('input');cb.type='checkbox';cb.checked=state.inflect;inf.append(cb,el('span','','Uwzględniaj odmianę (Kowalski → Kowalskiego)'));
  filters.append(inf);
  if(state.searchResults){filters.append(button('Wyczyść wyniki','linkish',e=>{e.preventDefault();state.searchQuery='';state.searchResults=null;state.searchOffset=0;renderWorkspace()}))}
  form.append(filters);
  form.onsubmit=async event=>{event.preventDefault();
    state.searchQuery=input.value.trim();state.inflect=cb.checked;state.searchOffset=0;
    submit.disabled=true;submit.textContent='Szukam…';await runSearch();};
  box.append(form);
  const help=el('details','search-help');help.append(el('summary','','Jak szukać?'));
  const rows=[['Kowalski oferta','oba fragmenty w jednym mailu (nazwisko, imię, firma, numer – dowolny fragment)'],
    ['"oferta na ogrodzenie"','dokładna fraza, także przełamana do nowej linii'],
    ['Leonardo | Bauer','jedno albo drugie'],['-faktura','pomiń maile zawierające „faktura”'],
    ['od:Kowalski','tylko nadawca  ·  do:@firma.pl – tylko odbiorcy i DW'],
    ['temat:umowa','tylko temat  ·  plik:cennik – tylko nazwy załączników'],
    ['data:2024-03','tylko marzec 2024  ·  data:2024  ·  data:15.03.2024'],
    ['od:2024-01-01 do:2024-06-30','zakres dat (bez dat: cała poczta, także dzisiejsza)'],
    ['data:2026-10 (samo)','wszystkie maile z okresu, od najnowszych']];
  const table=el('div','help-grid');for(const [a,b] of rows){table.append(el('code','',a),el('span','',b))}
  help.append(table);box.append(help);
  if(state.searchResults){const r=state.searchResults;
    const range=(r.date_from||r.date_to)?` · daty z zapytania: ${r.date_from||'…'} – ${r.date_to||'…'}`:' · cała poczta';
    const info=el('p','search-info');
    info.append(el('strong','',`${r.total} trafień`),document.createTextNode(` z ${r.scanned} maili${range} · ${(r.elapsed_ms/1000).toFixed(2)} s`));
    if(r.terms&&r.terms.length)info.append(el('span','terms','Szukano: '+r.terms.join('  lub  ')));
    box.append(info);
    const list=el('div','search-results');
    for(const m of r.messages){const card=button('','mail-card hit',()=>openMessage(m.id).catch(e=>notice(e.message,true)));
      append(card,el('span','mini',fmtDate(m)+' · '+(m.account_label||m.account)+' · '+(m.folder||'INBOX')+(m.attachments&&m.attachments.length?' · 📎 '+m.attachments.length:'')),
        el('strong','',m.subject||'(bez tematu)'),el('p','sender',m.sender));
      if(m.snippet){const s=el('p','snippet');for(const seg of m.snippet.segments||[])s.append(seg.m?el('mark','',seg.t):document.createTextNode(seg.t));card.append(s)}
      if(m.found_in&&m.found_in.length){const tags=el('span','found-in');for(const f of m.found_in)tags.append(el('span','tag',f));card.append(tags)}
      list.append(card)}
    if(!r.total){const empty=el('div','hint empty-search');empty.append(el('p','','Brak trafień.'));
      const tips=el('ul');for(const t of ['Wpisz krótszy fragment, np. „kowals” zamiast „Kowalskiemu”.','Jeśli w zapytaniu jest data (data:, od:, do:), usuń ją.','Jeśli mail właśnie przyszedł, kliknij „⟳ Sprawdź nową pocztę” – Thunderbird musi go najpierw pobrać.','Projekt szuka tylko w swojej skrzynce (TABAL / Skyfens) – sprawdź Archiwum poczty (całość).'])tips.append(el('li','',t));
      empty.append(tips);list.append(empty)}
    box.append(list);
    if(r.total>r.page_size){const pager=el('div','pager'),prev=button('← Poprzednie','secondary',async()=>{state.searchOffset=Math.max(0,state.searchOffset-r.page_size);await runSearch()}),next=button('Następne →','secondary',async()=>{state.searchOffset+=r.page_size;await runSearch()});
      prev.disabled=!state.searchOffset;next.disabled=state.searchOffset+r.messages.length>=r.total;
      pager.append(prev,el('span','',`${state.searchOffset+1}–${state.searchOffset+r.messages.length} z ${r.total}`),next);box.append(pager)}}
  root.append(box)}
async function runSearch(){const projectId=state.projectId;
  try{const result=await post('project/search',{id:projectId,query:state.searchQuery,offset:state.searchOffset,inflect:state.inflect});
    if(projectId!==state.projectId)return;state.searchResults=result;renderWorkspace()}catch(e){notice(e.message,true);renderWorkspace()}}
async function syncProject(){try{state.refresh=await post('project/sync',{id:state.projectId});state.refresh.running=true;renderRefreshInfo();notice('Sprawdzam nową pocztę… Nowe maile pojawią się same.');setTimeout(pollRefresh,1500)}catch(e){notice(e.message,true)}}
function projectEditor(p){const box=el('form','project-edit');const name=el('input'),filter=el('input'),acc=el('select');name.value=p.name;name.maxLength=120;filter.value=p.sender_query||'';filter.maxLength=200;filter.placeholder='pusty = cała poczta, np. aliplast | budimex';
  for(const [v,t] of [['both','Obie skrzynki'],['tabal','TABAL'],['skyfens','Skyfens']]){const o=el('option','',t);o.value=v;acc.append(o)}acc.value=p.account;
  const l1=el('label','','Nazwa'),l2=el('label','','Filtr projektu'),l3=el('label','','Skrzynka');l1.append(name);l2.append(filter);l3.append(acc);
  const save=button('Zapisz','',()=>{});save.type='submit';
  const del=button('Usuń projekt','linkish danger-text',async e=>{e.preventDefault();if(!confirm('Usunąć projekt „'+p.name+'” razem z jego rozmowami? Maile zostają w archiwum.'))return;try{await post('project/delete',{id:p.id,confirm:true});state.projectId=null;state.data=null;try{localStorage.removeItem('maildesk_project')}catch(x){}await loadProjects();renderWorkspace();notice('Projekt usunięty.')}catch(x){notice(x.message,true)}});
  box.append(l1,l2,l3,el('div','project-edit-actions'));box.lastChild.append(save,del);
  box.append(el('p','hint','Filtr działa jak wyszukiwarka (fragmenty nazw, | = albo, od:@firma.pl). Daty w filtrze (np. od:2024-01-01) ograniczają projekt do okresu.'));
  box.onsubmit=async e=>{e.preventDefault();try{const r=await post('project/update',{id:p.id,name:name.value,sender_query:filter.value,account:acc.value});state.projectEdit=false;await refreshProject();loadLatest(true);notice('Projekt zapisany: '+fmtNum(r.added)+' maili.')}catch(x){notice(x.message,true)}};
  return box}
async function watchDocuments(){clearTimeout(state.docTimer);const projectId=state.projectId;try{const job=await get('project/attachment-status?id='+projectId);if(projectId!==state.projectId)return;state.docText=job.running?`Załączniki: ${job.checked}/${job.total}, wczytano ${job.indexed}, błędy ${job.failed}`:job.total?`Załączniki gotowe: ${job.indexed}, błędy ${job.failed}. Szczegóły w dzienniku.`:'';const progress=$('#documentProgress');if(progress)progress.textContent=state.docText;if(job.running)state.docTimer=setTimeout(watchDocuments,1500)}catch(e){notice(e.message,true)}}
/* 5.13 — czat z pocztą: kontekst maili, szybkie pytania, źródła, szkice odpowiedzi, Stop */
const QUICK_PROMPTS=[
  ['Co nowego od wczoraj?','Co nowego przyszło od wczoraj? Pogrupuj według spraw i wskaż, co jest pilne.'],
  ['Na co nie odpowiedziałem?','Na które maile z ostatnich 7 dni jeszcze nie odpowiedziałem? Posortuj od najpilniejszych.'],
  ['Podsumuj tydzień','Podsumuj korespondencję z ostatniego tygodnia: najważniejsze sprawy, kwoty, terminy, otwarte tematy.'],
  ['Terminy i zobowiązania','Jakie terminy i zobowiązania (moje i klientów) pojawiły się w mailach z ostatnich 14 dni?']];
function metaText(id){const m=(state.meta||{})[String(id)];return m?`${m.d||''} · ${m.f||''} · ${m.s||''}`:'Mail '+id}
function plainAnswer(text){return String(text||'').replace(/\s*\[\d+(?:\s*[,;]\s*\d+)*\]/g,'').replace(/\*\*([^*]+)\*\*/g,'$1').replace(/^#{1,4}\s+/gm,'').trim()}
function pinMail(id,label){id=Number(id);state.focus=state.focus||[];if(state.focus.some(f=>f.id===id))return;if(state.focus.length>=8)return notice('Można przypiąć najwyżej 8 maili.',true);state.focus.push({id,label:label||metaText(id)})}
function askAbout(id,label){pinMail(id,label);state.tab='chat';renderWorkspace();setTimeout(()=>$('.composer textarea')?.focus(),0)}
function statusChip(status){const map={'szkic':'szkic','zatwierdzony':'zatwierdzony – czeka na wysłanie','wysłany':'wysłany','błąd':'błąd wysyłki','wysyłanie':'wysyłam…'};return el('span','chip st-'+(status||'').replace('ł','l').replace('ą','a'),map[status]||status)}
/* 5.14 — wiele rozmów: lista po lewej, nowa rozmowa, powrót do starych, zmiana nazwy, usuwanie */
async function startNewChat(){try{await post('chat/new',{id:state.projectId});state.focus=[];state.chatDraft='';state.chatRename=null;await refreshProject();setTimeout(()=>$('.composer textarea')?.focus(),0)}catch(e){notice(e.message,true)}}
async function switchChat(id){if(id===state.data.chat_id)return;try{await post('chat/open',{id:state.projectId,chat:id});state.focus=[];state.chatRename=null;await refreshProject()}catch(e){notice(e.message,true)}}
function renderChatList(){const box=el('aside','chat-list');const chats=state.data.chats||[];const current=state.data.chat_id||0;const busy=!!state.pendingQuestion;
  const nb=button('+ Nowa rozmowa','new-chat',startNewChat);nb.disabled=busy||!current;nb.title=current?'Zacznij nowy temat – ta rozmowa zostanie na liście':'Jesteś już w nowej rozmowie – zadaj pytanie';box.append(nb);
  if(chats.length>8){const f=el('input','chat-filter');f.type='search';f.placeholder='Szukaj rozmowy…';f.value=state.chatFilter||'';f.oninput=()=>{state.chatFilter=f.value;fillItems()};box.append(f)}
  const list=el('div','chat-items');box.append(list);
  function fillItems(){list.replaceChildren();const q=(state.chatFilter||'').toLowerCase();
    if(!current&&!q){const n=el('div','chat-item active fresh-chat');n.append(el('span','chat-title','Nowa rozmowa'),el('span','chat-meta','zapisze się po pierwszym pytaniu'));list.append(n)}
    for(const c of chats.filter(c=>!q||c.title.toLowerCase().includes(q))){const b=button('','chat-item'+(c.id===current?' active':''),()=>switchChat(c.id));b.disabled=busy&&c.id!==current;
      b.append(el('span','chat-title',c.title),el('span','chat-meta',fmtStamp(c.updated_at)+' · '+c.questions+(c.questions===1?' pytanie':' pytań')));b.title=c.title;list.append(b)}
    if(!chats.length)list.append(el('p','hint','Tu pojawią się Twoje rozmowy. Do każdej możesz wrócić.'))}
  fillItems();return box}
function renderChatHead(right){const cur=(state.data.chats||[]).find(c=>c.id===state.data.chat_id);const bar=el('div','chat-bar');
  if(cur&&state.chatRename===cur.id){const f=el('form','chat-rename');const i=el('input');i.value=cur.title;i.maxLength=80;const ok=button('Zapisz','',()=>{});ok.type='submit';
    f.append(i,ok,button('Anuluj','secondary',e=>{e.preventDefault();state.chatRename=null;renderWorkspace()}));
    f.onsubmit=async e=>{e.preventDefault();try{await post('chat/rename',{chat:cur.id,title:i.value});state.chatRename=null;await refreshProject()}catch(x){notice(x.message,true)}};
    bar.append(f);right.append(bar);setTimeout(()=>{i.focus();i.select()},0);return}
  const t=el('div','chat-head');t.append(el('strong','',cur?cur.title:'Nowa rozmowa'),el('span','',state.ai?`model ${state.data.chat_model||''} · pamięta tę rozmowę`:'czat AI wymaga klucza OpenAI'));bar.append(t);
  if(cur){const tools=el('div','chat-head-tools');
    const rn=button('✎ Zmień nazwę','linkish',()=>{state.chatRename=cur.id;renderWorkspace()});
    const del=button('Usuń rozmowę','linkish danger-text',async()=>{if(!confirm('Usunąć rozmowę „'+cur.title+'”? Pytań i odpowiedzi nie da się przywrócić. Szkice odpowiedzi zostają.'))return;try{await post('chat/delete',{chat:cur.id});await refreshProject();notice('Rozmowa usunięta.')}catch(e){notice(e.message,true)}});
    rn.disabled=del.disabled=!!state.pendingQuestion;tools.append(rn,del);bar.append(tools)}
  right.append(bar)}
function renderChat(pane){const layout=el('div','chat-layout');pane.append(layout);layout.append(renderChatList());const right=el('div','chat-main');layout.append(right);
  const conversation=el('div','conversation');conversation.id='conversation';const history=state.data.history;
  renderChatHead(right);
  if(!history.length&&!state.pendingQuestion){const empty=el('div','chat-empty');empty.append(el('p','','Zapytaj swoją pocztę jak w czacie. Asystent sam przeszukuje pocztę, czyta maile i przy każdym fakcie podaje numer maila – kliknij go, aby sprawdzić. Każda rozmowa zapisuje się po lewej, możesz do niej wrócić.'),
      el('p','','Możesz też przypiąć konkretny mail („Zapytaj AI o ten mail”) albo poprosić: „przygotuj odpowiedź do Kowalskiego, że montaż w listopadzie” – szkic trafi do zatwierdzenia, nic nie wyjdzie bez Twojej zgody.'));conversation.append(empty)}
  for(const entry of history){const turn=el('div','turn');turn.id='question-'+entry.id;
    const q=el('div','question',entry.question);if((entry.focus||[]).length){const pins=el('div','q-pins');for(const id of entry.focus)pins.append(button('📌 '+id,'pin-mini',()=>openMessage(id).catch(e=>notice(e.message,true))));pins.querySelectorAll('button').forEach((b,i)=>b.title=metaText(entry.focus[i]));q.append(pins)}
    turn.append(q);
    const ans=el('div','answer'+(entry.mode==='ai'?' ai':''));if(entry.mode==='ai')ans.append(renderMarkdown(entry.answer));else ans.textContent=entry.answer;turn.append(ans);
    for(const did of entry.drafts||[]){const d=(state.data.draft_info||{})[String(did)];if(!d)continue;const card=el('div','draft-card');
      const info=el('div');info.append(el('strong','',d.status==='wysłany'?'✉ Odpowiedź':'✉ Szkic odpowiedzi'),statusChip(d.status),el('span','',' do '+(d.to_addr||'?')+' · '+(d.subject||'')));
      card.append(info,button(d.status==='wysłany'?'Pokaż':'Otwórz, sprawdź i wyślij','',()=>openMessage(d.message_id,{replyId:d.id}).catch(e=>notice(e.message,true))));turn.append(card)}
    const tools=el('div','answer-tools');
    tools.append(button('Kopiuj','linkish',async()=>{try{await navigator.clipboard.writeText(plainAnswer(entry.answer));notice('Skopiowano odpowiedź.')}catch(e){notice('Nie udało się skopiować – zaznacz tekst ręcznie.',true)}}),
      button('Zapytaj ponownie','linkish',()=>{const input=$('.composer textarea');input.value=entry.question;state.chatDraft=entry.question;input.focus()}));
    if(entry.mode==='ai'&&entry.sources.length)tools.append(button('Użyj jako odpowiedź na mail…','linkish',()=>chooseReplyTarget(tools,entry)));
    turn.append(tools);
    const meta=el('div','sources');
    if(entry.mode==='ai'){const tr=entry.trace||[];if(tr.length){const d=el('details','trace');d.append(el('summary','',`Co sprawdził asystent (${tr.length})`));for(const t of tr)d.append(el('div','',t));meta.append(d)}
      meta.append(el('span','',`${entry.model||''}${entry.cost_usd?` · ok. ${Number(entry.cost_usd).toFixed(3)} USD`:''}`))}
    else meta.append(el('span','','Wyszukiwanie lokalne'));
    if(entry.sources.length){const src=el('details','source-list');src.append(el('summary','',`Źródła (${entry.sources.length})`));
      for(const id of entry.sources){const row=button('','source-row',()=>openMessage(id).catch(e=>notice(e.message,true)));const m=(state.meta||{})[String(id)]||{};
        row.append(el('span','cite-num',id),el('span','src-date',m.d||''),el('span','src-from',m.f||''),el('span','src-subj',m.s||''));src.append(row)}
      meta.append(src)}
    turn.append(meta);conversation.append(turn)}
  if(state.pendingQuestion){const turn=el('div','turn');const box=el('div','answer pending');box.id='pendingSteps';renderSteps(box);turn.append(el('div','question',state.pendingQuestion),box);conversation.append(turn)}
  right.append(conversation);
  const composer=el('div','composer');
  if((state.focus||[]).length){const pins=el('div','pins');pins.append(el('span','pins-label','Kontekst:'));
    for(const f of state.focus){const chip=el('span','pin');chip.append(button('📌 '+f.label,'pin-open',()=>openMessage(f.id).catch(e=>notice(e.message,true))),button('✕','pin-x',()=>{state.focus=state.focus.filter(x=>x.id!==f.id);renderWorkspace()}));chip.title='Asystent przeczyta ten mail przed odpowiedzią';pins.append(chip)}
    composer.append(pins)}
  const quick=el('div','quick');for(const [label,text] of QUICK_PROMPTS)quick.append(button(label,'quick-chip',()=>{const input=$('.composer textarea');input.value=text;state.chatDraft=text;input.focus()}));composer.append(quick);
  const input=el('textarea');input.placeholder=(state.focus||[]).length?'Zapytaj o przypięte maile, np. „przygotuj odpowiedź”, „co klient konkretnie zamawia?”':'Zapytaj swoją pocztę… (Enter – wyślij do AI, Shift+Enter – nowa linia)';input.maxLength=2000;input.value=state.chatDraft||'';input.oninput=()=>{state.chatDraft=input.value;input.style.height='auto';input.style.height=Math.min(260,input.scrollHeight)+'px'};composer.append(input);
  const actions=el('div','composer-actions');actions.append(el('span','',state.pendingQuestion?'Asystent pracuje – możesz go zatrzymać.':'AI przeszukuje pocztę tego projektu i czyta wybrane maile. „Szukaj lokalnie” działa bez AI i bez Internetu.'));
  const choices=el('div');
  if(state.pendingQuestion&&state.askJob){choices.append(button('■ Zatrzymaj','danger',async()=>{try{await post('project/ask-stop',{job:state.askJob})}catch(e){}}))}
  else{const local=button('Szukaj lokalnie','secondary',()=>ask('local'));const ai=button('Zapytaj AI','',()=>ask('ai'));ai.disabled=!state.ai||!!state.pendingQuestion;local.disabled=!!state.pendingQuestion;choices.append(local,ai)}
  actions.append(choices);composer.append(actions);right.append(composer);
  input.onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey&&state.ai&&!state.pendingQuestion){e.preventDefault();ask('ai')}};
  setTimeout(()=>{conversation.scrollTop=conversation.scrollHeight},0);
  async function ask(mode){const question=input.value.trim();if(!question)return notice('Wpisz pytanie.',true);state.pendingQuestion=question;state.pendingSteps=[];state.pendingElapsed=0;state.chatDraft='';state.askJob=null;renderWorkspace();
    const chat=state.data.chat_id||0;
    try{if(mode==='ai'){const {job}=await post('project/ask-start',{id:state.projectId,question,mode,chat,focus:(state.focus||[]).map(f=>f.id)});state.askJob=job;renderWorkspace();
        for(;;){await new Promise(r=>setTimeout(r,900));const st=await get('project/ask-status?job='+job);state.pendingSteps=st.steps;state.pendingElapsed=st.elapsed;
          const box=document.getElementById('pendingSteps');if(box)renderSteps(box);
          if(!st.running){if(st.error){if(st.stopped){state.chatDraft=question;notice(st.error)}else throw Error(st.error)}break}}}
      else await post('project/ask',{id:state.projectId,question,mode,chat})}catch(e){notice(e.message,true);state.chatDraft=question}
    state.pendingQuestion=null;state.pendingSteps=[];state.askJob=null;await refreshProject();loadPendingReplies()}
}
function chooseReplyTarget(holder,entry){holder.querySelector('.reply-target')?.remove();const box=el('div','reply-target');const sel=el('select');
  for(const id of entry.sources){const o=el('option','',`${id} · ${metaText(id)}`);o.value=id;sel.append(o)}
  box.append(el('span','','Odpowiedź na mail:'),sel,button('Utwórz szkic','',async()=>{try{const r=await post('reply/create',{message_id:Number(sel.value),body:plainAnswer(entry.answer),source:'czat'});await openMessage(r.message_id,{replyId:r.id});notice('Szkic gotowy – sprawdź odbiorcę i treść, potem zatwierdź.')}catch(e){notice(e.message,true)}}),button('Anuluj','secondary',()=>box.remove()));
  holder.append(box)}
function renderSteps(box){box.replaceChildren();const steps=state.pendingSteps||[];
  box.append(el('div','pending-head',`Pracuję… ${state.pendingElapsed?Math.round(state.pendingElapsed)+' s':''}`));
  for(const [i,s] of steps.entries()){box.append(el('div','step'+(i===steps.length-1?' current':''),s))}
  if(!steps.length)box.append(el('div','step current',(state.focus||[]).length?'Czytam przypięte maile…':'Szukam w poczcie…'))}

/* 5.13 — wiadomość: wątek, odpowiedzi (szkic → zatwierdzenie → wysyłka) */
function renderMail(right){const m=state.message;const pane=el('div','mail-detail');right.append(pane);if(!m){pane.append(el('p','hint','Otwórz mail z panelu „Najnowsza poczta”, z wyników wyszukiwania albo kliknij numer źródła w odpowiedzi.'));return}
  const head=el('div','mail-head');const title=el('div');append(title,el('span','eyebrow',m.account_label+' · '+(m.folder_label||m.folder||'INBOX')),el('h3','',m.subject||'(bez tematu)'));
  if(state.messageAnswered===true)title.append(el('span','chip st-wyslany','✓ odpowiedziano'));else if(state.messageAnswered===false)title.append(el('span','chip st-wait','czeka na odpowiedź'));
  head.append(title);pane.append(head);
  pane.append(el('div','meta','Od: '+m.sender+'\nDo: '+m.recipient+(m.cc?'\nDW: '+m.cc:'')+'\nData: '+m.received+'\nZałączniki: '+(m.attachments.join(', ')||'brak')));
  const bar=el('div','mail-actions');
  bar.append(button('↩ Odpowiedz','',()=>newReply(false)),button('↩ Odpowiedz wszystkim','secondary',()=>newReply(true)),
    button('✨ Przygotuj odpowiedź z AI','secondary',()=>{state.replyAiOpen=true;newReply(false,true)}),
    button('💬 Zapytaj AI o ten mail','secondary',()=>askAbout(m.id,(m.subject||'(bez tematu)').slice(0,60))));
  bar.querySelectorAll('button')[2].disabled=!state.ai;pane.append(bar);
  pane.append(el('div','mail-body',m.body||'(brak treści tekstowej)'));
  if(m.attachments.length){const box=el('div','attachment-box');box.append(el('h3','','Załączniki'));m.attachments.forEach((name,index)=>{const row=el('div','attachment-row'),stored=state.documents.find(d=>d.part_index===index);row.append(el('span','',name+(stored?' · tekst w indeksie ('+stored.length+' znaków)':'')));row.append(button('Wczytaj do analizy','secondary',async()=>{try{const result=await post('attachment/index',{id:m.id,index});const updated=await get('message?id='+m.id);state.documents=updated.documents;renderWorkspace();notice('Wczytano tekst: '+result.filename)}catch(e){notice(e.message,true)}}));if(stored)row.append(button('Czytaj tekst','secondary',async()=>{try{const result=await get('attachment/text?id='+m.id+'&index='+index);const preview=el('pre','attachment-preview',result.text);row.after(preview)}catch(e){notice(e.message,true)}}));row.append(button('Pobierz plik','secondary',()=>{window.location.href='/api/attachment?id='+m.id+'&index='+index}));box.append(row)});pane.append(box)}
  const thread=state.thread||[];if(thread.length){const d=el('details','thread-box');d.append(el('summary','',`Wątek – inne maile tej rozmowy (${thread.length})`));
    for(const t of thread){const row=button('','thread-row',()=>openMessage(t.id).catch(e=>notice(e.message,true)));row.append(el('span','src-date',t.day||''),el('span','src-from',(t.outgoing?'→ ':'')+t.sender),el('span','src-subj',t.subject||''));d.append(row)}pane.append(d)}
  if(m.status==='szkic'&&m.draft){const a=el('div','analysis');append(a,el('small','','Analiza · '+m.category+' | Priorytet · '+m.priority+' | Termin · '+(m.due||'nie wskazano')),el('div','','Streszczenie: '+m.summary+'\nDziałanie: '+m.action));
    a.append(button('Użyj szkicu z analizy jako odpowiedzi','secondary',async()=>{try{const r=await post('reply/create',{message_id:m.id,body:m.draft,source:'analiza'});await openMessage(m.id,{replyId:r.id})}catch(e){notice(e.message,true)}}));pane.append(a)}
  const tools=el('div','mail-actions subtle-row');tools.append(button('Analizuj lokalnie (reguły)','linkish',()=>analyze('demo')),button('Analizuj przez AI (streszczenie, priorytet)','linkish',()=>analyze('ai')));tools.lastChild.disabled=!state.ai;pane.append(tools);
  renderReplies(pane,m);
  async function analyze(mode){try{await post('analyze',{id:m.id,mode});await openMessage(m.id,{keepReply:true});notice('Analiza gotowa.')}catch(e){notice(e.message,true)}}
  async function newReply(all,ai){const open=(state.replies||[]).find(r=>r.editable&&r.status!=='błąd');if(open&&!ai){state.replyId=open.id;renderWorkspace();notice('Ten mail ma już otwarty szkic – kontynuuj go albo usuń.');return}
    if(ai&&open){state.replyId=open.id;state.replyAiOpen=true;renderWorkspace();return}
    try{const r=await post('reply/create',{message_id:m.id,reply_all:all,body:ai?'':'Dzień dobry,\n\n\n\nPozdrawiam,'});await openMessage(m.id,{replyId:r.id});if(ai){state.replyAiOpen=true;renderWorkspace()}}catch(e){notice(e.message,true)}}
}
function replyValues(r){return state.replyEdits[r.id]||{to:r.to_addr,cc:r.cc_addr,subject:r.subject,body:r.body,quote:!!r.quote}}
function renderReplies(pane,m){const list=state.replies||[];if(!list.length)return;
  const box=el('section','reply-section');box.id='replySection';box.append(el('h3','','Odpowiedzi'));
  if(list.length>1){const tabs=el('div','reply-tabs');for(const r of list){const b=button('','reply-tab'+(r.id===state.replyId?' active':''),()=>{state.replyId=r.id;renderWorkspace()});b.append(el('span','',`#${r.id} · ${(r.created_at||'').slice(0,10)}`),statusChip(r.status));tabs.append(b)}box.append(tabs)}
  const r=list.find(x=>x.id===state.replyId)||list[0];state.replyId=r.id;
  const steps=el('ol','reply-steps');const stage={'szkic':0,'błąd':0,'zatwierdzony':1,'wysyłanie':2,'wysłany':2}[r.status]??0;
  ['Szkic – sprawdź i popraw','Zatwierdzony – sprawdź ostatni raz','Wysłany'].forEach((t,i)=>steps.append(el('li',i<stage?'done':i===stage?'current':'',t)));box.append(steps);
  if(r.status==='wysłany'){const card=el('div','sent-card');card.append(el('strong','',`Wysłano ${fmtStamp(r.sent_at)} z ${r.from_addr} do ${r.to_addr}${r.cc_addr?' · DW: '+r.cc_addr:''}`),
      el('span','',r.saved_to_sent?`Kopia jest w folderze „${r.saved_to_sent}” na serwerze (Thunderbird też ją pokaże).`:'Kopii nie udało się zapisać w folderze Wysłane na serwerze – szczegóły w dzienniku błędów poczty. Mail został wysłany.'),
      el('div','reply-preview-subject','Temat: '+r.subject),el('pre','reply-preview',r.body));box.append(card);pane.append(box);return}
  if(r.status==='wysyłanie'){box.append(el('div','archive-progress','Wysyłam…'));pane.append(box);return}
  if(r.error)box.append(el('div','archive-progress warn',r.error));
  if(r.status==='zatwierdzony'&&!state.replyEditing[r.id]){renderApproved(box,r);pane.append(box);return}
  const v=replyValues(r);const dirty=()=>{state.replyEdits[r.id]=v;state.replyDirty=true};
  const form=el('div','reply-form');
  const field=(label,value,key,attrs={})=>{const l=el('label','',label);const i=el(attrs.tag||'input');Object.assign(i,attrs.props||{});i.value=value??'';i.oninput=()=>{v[key]=i.value;dirty()};l.append(i);form.append(l);return i};
  const from=el('label','','Od');const fi=el('input');fi.value=r.from_addr||'(brak loginu skrzynki – wpisz w Konfiguracji kont)';fi.readOnly=true;from.append(fi);form.append(from);
  field('Do',v.to,'to',{props:{placeholder:'adres@firma.pl, Imię Nazwisko <adres@firma.pl>'}});
  const ccInput=field('DW (kopia)',v.cc,'cc',{props:{placeholder:'opcjonalnie'}});
  const allCc=(state.defaults&&state.defaults.reply_all&&state.defaults.reply_all.cc)||'';
  if(allCc&&allCc!==(v.cc||'')){const add=button('+ dodaj do DW pozostałych uczestników maila ('+allCc.split(',').length+')','linkish',()=>{const have=(v.cc||'').trim();v.cc=have?have+', '+allCc:allCc;ccInput.value=v.cc;dirty();add.remove()});add.title=allCc;ccInput.parentElement.append(add)}
  field('Temat',v.subject,'subject');
  const ai=el('details','reply-ai');ai.open=!!state.replyAiOpen;ai.ontoggle=()=>{state.replyAiOpen=ai.open};
  ai.append(el('summary','',(v.body||'').trim().length>40?'✨ Popraw z AI':'✨ Napisz z AI'));
  const instr=el('textarea');instr.placeholder='Co ma być w odpowiedzi? np. „podziękuj, montaż możliwy od 15.11, cenę potwierdzę jutro”, „odmów grzecznie”, „poproś o wymiary bramy”';instr.value=state.replyInstr||'';instr.oninput=()=>{state.replyInstr=instr.value};
  const opts=el('div','reply-ai-opts');
  const mk=(label,id,options,val)=>{const l=el('label','',label),s=el('select');for(const [k,t] of options){const o=el('option','',t);o.value=k;s.append(o)}s.value=state['reply_'+id]||val;s.onchange=()=>{state['reply_'+id]=s.value};l.append(s);opts.append(l);return s};
  const tone=mk('Ton','tone',[['uprzejmy','uprzejmy'],['rzeczowy','rzeczowy'],['cieply','ciepły'],['stanowczy','stanowczy']],'uprzejmy');
  const lang=mk('Język','lang',[['auto','jak w mailu'],['pl','polski'],['en','angielski'],['de','niemiecki'],['es','hiszpański'],['it','włoski'],['fr','francuski'],['cs','czeski'],['uk','ukraiński']],'auto');
  const len=mk('Długość','len',[['krotka','krótka'],['normalna','normalna'],['szczegolowa','szczegółowa']],'normalna');
  const gen=button((v.body||'').trim().length>40?'✨ Popraw szkic':'✨ Napisz szkic','',async()=>{gen.disabled=true;gen.textContent='Piszę…';
    try{if(state.replyDirty)await saveReply(r,v,true);
      const res=await post('reply/draft-ai',{message_id:r.message_id,reply_id:r.id,instructions:instr.value,tone:tone.value,language:lang.value,length:len.value});
      delete state.replyEdits[r.id];state.replyDirty=false;await openMessage(r.message_id,{replyId:res.id});
      notice((res.missing&&res.missing.length?'Szkic gotowy. Uzupełnij: '+res.missing.join(', ')+'.':'Szkic gotowy – sprawdź go.')+(res.cost_usd?` (ok. ${Number(res.cost_usd).toFixed(3)} USD)`:''))}
    catch(e){notice(e.message,true);gen.disabled=false;gen.textContent='✨ Spróbuj ponownie'}});
  gen.disabled=!state.ai;
  ai.append(instr,opts,gen,el('p','hint','AI czyta ten mail, jego wątek i załączniki. Nie wymyśla cen ani terminów – brakujące dane oznacza [[tak]]. Nic nie zostanie wysłane bez Twojego zatwierdzenia.'));
  form.append(ai);
  const body=field('Treść',v.body,'body',{tag:'textarea'});body.className='reply-body';
  setTimeout(()=>{body.style.height=Math.max(220,Math.min(560,body.scrollHeight+4))+'px'},0);
  const q=el('label','check'),qc=el('input');qc.type='checkbox';qc.checked=!!v.quote;qc.onchange=()=>{v.quote=qc.checked;dirty()};q.append(qc,el('span','','Dołącz cytat oryginalnego maila pod odpowiedzią'));form.append(q);
  if(r.quote_preview){const d=el('details','quote-preview');d.append(el('summary','','Podgląd cytatu'),el('pre','',r.quote_preview));form.append(d)}
  const sig=el('details','signature-box');sig.append(el('summary','','Podpis dla skrzynki '+r.account_label));const st=el('textarea');st.value=state.signature||'';st.placeholder='np.\nGrzegorz Bartosik\nTABAL Sp. z o.o.\ntel. …';
  sig.append(st,button('Zapisz podpis','secondary',async()=>{try{await post('reply/signature',{account:r.account,signature:st.value});state.signature=st.value;notice('Podpis zapisany – będzie dodawany do nowych szkiców.')}catch(e){notice(e.message,true)}}),el('p','hint','Podpis dopisuje się automatycznie do nowych szkiców (także tych z AI i z czatu).'));form.append(sig);
  const warns=(r.warnings||[]).filter(w=>w.code!=='no_to'||!(v.to||'').trim());
  let ack=null;if(warns.length){const w=el('div','reply-warnings');for(const x of warns){w.append(el('div','warn-line','⚠ '+x.text));if(x.code==='outside'){const l=el('label','check');ack=el('input');ack.type='checkbox';l.append(ack,el('span','','Tak, ten mail ma trafić także do tych adresów'));w.append(l)}}form.append(w)}
  const buttons=el('div','reply-buttons');
  buttons.append(button('Zapisz szkic','secondary',()=>saveReply(r,v)),
    button('Zatwierdź treść →','',async()=>{try{await saveReply(r,v,true);const a=await post('reply/approve',{id:r.id,to:v.to,cc:v.cc,subject:v.subject,body:v.body,quote:v.quote,acknowledge:!!(ack&&ack.checked)});delete state.replyEdits[r.id];state.replyDirty=false;state.replyEditing[r.id]=false;await openMessage(r.message_id,{replyId:a.id});document.getElementById('replySection')?.scrollIntoView({behavior:'smooth'})}catch(e){notice(e.message,true);await openMessage(r.message_id,{replyId:r.id,keepEdits:true})}}),
    button('Usuń szkic','linkish danger-text',async()=>{if(!confirm('Usunąć ten szkic odpowiedzi?'))return;try{await post('reply/delete',{id:r.id});delete state.replyEdits[r.id];state.replyDirty=false;await openMessage(r.message_id);loadPendingReplies()}catch(e){notice(e.message,true)}}));
  form.append(buttons);
  form.append(el('p','hint',`Źródło szkicu: ${({'ai':'AI','czat':'czat','analiza':'analiza AI','szablon':'szablon','ręcznie':'ręcznie'})[r.source]||r.source||'ręcznie'}${r.model?' · '+r.model:''}${r.cost_usd?` · ok. ${Number(r.cost_usd).toFixed(3)} USD`:''} · ostatnia zmiana ${fmtStamp(r.updated_at)}`));
  box.append(form);pane.append(box)}
function renderApproved(box,r){const card=el('div','approved-card');card.append(el('div','approved-head','Sprawdź ostatni raz – tak dokładnie wyjdzie ten mail:'));
  const grid=el('div','approved-grid');for(const [k,val] of [['Od',r.from_addr||'(brak loginu)'],['Do',r.to_addr],['DW',r.cc_addr||'—'],['Temat',r.subject]]){grid.append(el('span','k',k),el('span','v',val))}card.append(grid);
  card.append(el('pre','reply-preview',r.body+(r.quote?'\n\n'+r.quote_preview+(r.quote_preview.length>=1500?'\n…':''):'')));
  for(const w of (r.warnings||[]).filter(w=>w.code==='smtp'||w.code==='outside'))card.append(el('div','warn-line','⚠ '+w.text));
  const row=el('div','reply-buttons');
  const send=button('✉ Wyślij teraz','send-button',async()=>{if(!confirm(`Wysłać teraz z ${r.from_addr} do ${r.to_addr}${r.cc_addr?' (DW: '+r.cc_addr+')':''}?\n\nTemat: ${r.subject}`))return;send.disabled=true;send.textContent='Wysyłam…';
    try{const s=await post('reply/send',{id:r.id,approved_hash:r.approved_hash,confirm:true});await openMessage(r.message_id,{replyId:r.id});loadPendingReplies();loadLatest();notice('Wysłano do '+s.to_addr+(s.saved_to_sent?' · kopia w „'+s.saved_to_sent+'”':''))}
    catch(e){notice(e.message,true);await openMessage(r.message_id,{replyId:r.id})}});
  row.append(send,button('← Wróć do edycji','secondary',()=>{state.replyEditing[r.id]=true;renderWorkspace()}));card.append(row);
  card.append(el('p','hint','Zatwierdzenie dotyczy dokładnie tej treści i tych adresów. Każda zmiana cofa odpowiedź do szkicu.'));box.append(card)}
async function saveReply(r,v,quiet){try{await post('reply/save',{id:r.id,to:v.to,cc:v.cc,subject:v.subject,body:v.body,quote:v.quote});delete state.replyEdits[r.id];state.replyDirty=false;if(!quiet){await openMessage(r.message_id,{replyId:r.id});notice('Szkic zapisany.')}loadPendingReplies()}catch(e){if(quiet)throw e;notice(e.message,true)}}
function fmtStamp(iso){if(!iso)return '';const d=new Date(iso);return isNaN(d)?iso:d.toLocaleString('pl-PL',{dateStyle:'short',timeStyle:'short'})}
async function openMessage(id,opts={}){const result=await get('message?id='+encodeURIComponent(id));
  if(state.messageId!==Number(id)){state.replyEditing={};state.replyInstr='';if(!opts.keepEdits){state.replyEdits={};state.replyDirty=false}}
  state.messageId=Number(id);state.message=result.message;state.documents=result.documents;state.thread=result.thread||[];state.replies=result.replies||[];state.messageAnswered=result.answered;state.signature=result.signature||'';state.defaults=result.defaults||null;
  const editable=state.replies.find(r=>r.editable);state.replyId=opts.replyId||(opts.keepReply&&state.replyId)||(editable&&editable.id)||(state.replies[0]&&state.replies[0].id)||null;
  state.tab='mail';renderWorkspace();if(opts.replyId)setTimeout(()=>document.getElementById('replySection')?.scrollIntoView({behavior:'smooth',block:'start'}),50)}

/* 5.13 — nowa poczta co kilka minut */
function safeToRerender(){if(state.pendingQuestion||state.replyDirty)return false;const a=document.activeElement;return !(a&&a!==document.body&&/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)&&a.closest('#workspace'))}
async function pollRefresh(){clearTimeout(state.refreshTimer);let r=null;
  try{r=await get('refresh/status');const first=state.refreshSeq===null||state.refreshSeq===undefined;const changed=!first&&r.seq!==state.refreshSeq;state.refreshSeq=r.seq;state.refresh=r;renderRefreshInfo();if(first)renderArchive();if(changed)await onNewMail(r)}catch(e){}
  state.refreshTimer=setTimeout(pollRefresh,(r&&(r.running||r.archive_running))?3000:15000)}
async function onNewMail(r){state.unseen=(state.unseen||0)+(r.last_imported||0);updateTitle();
  notice(`📬 Nowa poczta: ${r.last_imported} ${r.last_imported===1?'mail':'maili'}.`);
  try{await loadProjects();if(!state.projectId)return;await loadLatest(true);
    if(safeToRerender()){await refreshProject();if(state.searchResults)await runSearch()}else{state.stale=true;const b=$('#staleBanner');if(b)b.hidden=false}}catch(e){}
  loadArchive()}
function updateTitle(){document.title=(state.unseen?`(${state.unseen}) `:'')+'Mail Desk 5.14 · TABAL i Skyfens'}
window.addEventListener('focus',()=>{if(state.unseen){state.unseen=0;updateTitle()}});
function renderRefreshInfo(){const box=$('#refreshInfo');if(!box)return;const r=state.refresh;box.replaceChildren();if(!r)return;
  const text=el('span','refresh-text');
  if(!r.source)text.textContent='Nowa poczta: brak źródła – zindeksuj Thunderbirda (panel Archiwum)';
  else if(r.running||r.archive_running)text.textContent='⟳ Sprawdzam nową pocztę…';
  else text.textContent=(r.minutes?`⟳ Nowa poczta co ${r.minutes} min`:'⟳ Auto-sprawdzanie wyłączone')+(r.last_ok?` · sprawdzono ${fmtStamp(r.last_ok).split(', ').pop()}`:'')+(r.last_imported?` · ostatnio +${r.last_imported}`:'');
  const tips=[];if(r.source==='thunderbird')tips.push('Źródło: pliki Thunderbirda. Thunderbird musi być uruchomiony i pobierać pocztę.');if(r.source==='imap')tips.push('Źródło: serwer IMAP (bez Thunderbirda).');
  if(r.tb_last_change)tips.push('Thunderbird ostatnio zapisał pocztę: '+fmtStamp(r.tb_last_change));if(r.next_in!=null&&r.minutes)tips.push('Następne sprawdzenie za ok. '+Math.max(1,Math.round(r.next_in/60))+' min');if(r.last_error)tips.push('Uwaga: '+r.last_error);
  box.title=tips.join('\n');if(r.last_error)text.classList.add('warn');
  box.append(text);if(r.source)box.append(button('Sprawdź teraz','refresh-now',async()=>{try{state.refresh=await post('refresh/now',{});state.refresh.running=true;renderRefreshInfo();setTimeout(pollRefresh,1500)}catch(e){notice(e.message,true)}}))}
async function loadLatest(silent){if(!state.projectId)return;const pid=state.projectId;
  try{const r=await get(`project/latest?id=${pid}&limit=12${state.latestUnanswered?'&unanswered=1&days=14':''}`);if(pid!==state.projectId)return;state.latest=r;const box=$('#latestBox');if(box)fillLatest(box)}catch(e){if(!silent)notice(e.message,true)}}
function renderLatest(root){const d=el('details','latest-box');d.id='latestBox';d.open=state.latestOpen!==false;d.ontoggle=()=>{state.latestOpen=d.open};root.append(d);
  const banner=el('div','stale-banner');banner.id='staleBanner';banner.hidden=!state.stale;banner.append(el('span','','Przyszła nowa poczta.'),button('Odśwież widok','',async()=>{state.stale=false;await refreshProject();loadLatest(true)}));root.append(banner);
  fillLatest(d)}
function fillLatest(d){d.replaceChildren();const r=state.latest;const fresh=(r?.messages||[]).filter(m=>m.fresh).length;
  const sum=el('summary','');sum.append(el('span','',state.latestUnanswered?'Czekają na odpowiedź (14 dni)':'Najnowsza poczta'));if(fresh&&!state.latestUnanswered)sum.append(el('span','chip st-new',fresh+' nowe'));d.append(sum);
  const tools=el('div','latest-tools');const l=el('label','check'),cb=el('input');cb.type='checkbox';cb.checked=!!state.latestUnanswered;cb.onchange=()=>{state.latestUnanswered=cb.checked;loadLatest()};l.append(cb,el('span','','tylko bez odpowiedzi'));tools.append(l,button('↻','linkish',()=>loadLatest()));d.append(tools);
  if(!r){d.append(el('p','hint','Wczytuję…'));return}
  if(!r.messages.length){d.append(el('p','hint',state.latestUnanswered?'Brak maili czekających na odpowiedź (albo nie znam Twojego adresu – wpisz login skrzynki w Konfiguracji kont).':'Brak maili w projekcie.'));return}
  const list=el('div','latest-list');
  for(const m of r.messages){const row=el('div','latest-row'+(m.fresh?' fresh':''));const main=button('','latest-main',()=>openMessage(m.id).catch(e=>notice(e.message,true)));
    const top=el('span','latest-top');top.append(el('span','src-date',fmtDate(m)),el('span','latest-from',(m.outgoing?'→ ':'')+m.sender));
    if(m.fresh)top.append(el('span','chip st-new','nowy'));
    if(m.outgoing)top.append(el('span','chip','wysłany'));else if(m.answered===true)top.append(el('span','chip st-wyslany','✓ odpowiedziano'));else if(m.answered===false)top.append(el('span','chip st-wait','czeka'));
    if(m.drafts)top.append(el('span','chip st-szkic','szkic'));if(m.attachments)top.append(el('span','att','📎 '+m.attachments));
    main.append(top,el('strong','',m.subject||'(bez tematu)'),el('span','latest-snippet',m.snippet||''));
    const act=el('div','latest-actions');if(!m.outgoing)act.append(button('Odpowiedz','secondary',async()=>{try{await openMessage(m.id);const open=(state.replies||[]).find(x=>x.editable);if(open)return;const rr=await post('reply/create',{message_id:m.id,body:'Dzień dobry,\n\n\n\nPozdrawiam,'});await openMessage(m.id,{replyId:rr.id})}catch(e){notice(e.message,true)}}));
    const ask=button('💬 Zapytaj','secondary',()=>askAbout(m.id,(m.subject||'(bez tematu)').slice(0,60)));ask.title='Przypnij ten mail w czacie i zapytaj o niego AI';act.append(ask);row.append(main,act);list.append(row)}
  d.append(list)}
async function loadPendingReplies(){try{const r=await get('replies/pending');state.pendingReplies=r.replies;const nav=$('#pendingReplies');if(!nav)return;nav.replaceChildren();
  for(const x of r.replies.slice(0,12)){const b=button('','pending-link',()=>openMessage(x.message_id,{replyId:x.id}).catch(e=>notice(e.message,true)));b.append(el('strong','',x.subject||'(bez tematu)'),el('span','',(x.to_addr||'').slice(0,60)),statusChip(x.status));nav.append(b)}
  if(!r.replies.length)nav.append(el('p','empty-list','Brak szkiców. Odpowiedź przygotujesz w mailu („↩ Odpowiedz”) albo w czacie.'))}catch(e){}}
function renderRefreshSettings(box){const r=state.refresh;if(!r)return;const row=el('div','refresh-settings');const l=el('label','','Sprawdzaj nową pocztę');const s=el('select');
  for(const [v,t] of [[1,'co 1 min'],[2,'co 2 min'],[5,'co 5 min'],[10,'co 10 min'],[15,'co 15 min'],[30,'co 30 min'],[60,'co godzinę'],[0,'wyłączone']]){const o=el('option','',t);o.value=v;s.append(o)}
  s.value=String(r.minutes);s.onchange=async()=>{try{state.refresh=await post('refresh/settings',{minutes:Number(s.value)});renderRefreshInfo();notice(Number(s.value)?'Nowa poczta będzie sprawdzana co '+s.value+' min.':'Automatyczne sprawdzanie wyłączone.')}catch(e){notice(e.message,true)}};l.append(s);row.append(l);
  if(r.source==='thunderbird'){const hint=el('p','hint',(r.tb_last_change?'Thunderbird ostatnio zapisał pocztę: '+fmtStamp(r.tb_last_change)+'. ':'')+'Mail Desk widzi tylko to, co Thunderbird już pobrał – Thunderbird musi być otwarty. W Thunderbirdzie: Ustawienia konta → Ustawienia serwera → „Sprawdzaj nowe wiadomości co 5 minut”.');row.append(hint)}
  if(r.last_error)row.append(el('div','archive-progress warn',r.last_error));box.append(row)}
/* 5.6 — Archiwum poczty */
function fmtBytes(n){n=Number(n||0);const u=['B','KB','MB','GB','TB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++}return (i<2?Math.round(n):n.toFixed(1).replace('.',','))+' '+u[i]}
function fmtEta(s){if(s===null||s===undefined)return 'liczę…';if(s<90)return 'mniej niż 2 min';const h=Math.floor(s/3600),m=Math.floor(s%3600/60);return 'ok. '+(h?h+' h ':'')+m+' min'}
function fmtNum(n){return Number(n||0).toLocaleString('pl-PL')}
async function loadArchive(){clearTimeout(state.archiveTimer);
  try{if(!state.tbProfiles){try{state.tbProfiles=(await get('thunderbird/profiles')).profiles}catch(e){state.tbProfiles=[]}}const was=state.archive?.job?.running;state.archive=await get('archive/status');renderArchive();
    if(state.archive.job.running)state.archiveTimer=setTimeout(loadArchive,2000);
    else if(was){await loadProjects();if(state.projectId)await refreshProject()}}catch(e){}}
function archiveProgressText(job){const parts=[];
  for(const [acc,p] of Object.entries(job.progress||{})){if(acc==='thunderbird'){parts.push(p.phase==='done'?'Thunderbird: zakończono':p.phase==='fts'?'Thunderbird: buduję szybki indeks wyszukiwania (jednorazowo, może potrwać kilkanaście minut)…':`Thunderbird: przeczytano ${fmtBytes(p.bytes_done)} z ${fmtBytes(p.bytes_total)} · pliki ${p.files_done}/${p.files} · nowych maili ${fmtNum(p.imported)} · folder ${p.folder} · zostało ${fmtEta(p.eta_seconds)}`);continue}const name=(state.accounts[acc]?.label||acc).split(' ')[0];
    if(p.phase==='scan')parts.push(`${name}: sprawdzam foldery ${p.folder_no}/${p.folders} · do pobrania ${fmtNum(p.total_new)} maili`);
    else if(p.phase==='download')parts.push(`${name}: ${fmtNum(p.done_new)} / ${fmtNum(p.total_new)} maili · ${fmtBytes(p.bytes_done)} z ${fmtBytes(p.bytes_total)} · folder ${p.folder} · zostało ${fmtEta(p.eta_seconds)}`);
    else parts.push(`${name}: zakończono`)}
  return parts.join('\n')||'Łączę z serwerem…'}
function renderThunderbird(box){const a=state.archive,tb=a.thunderbird||{},profiles=state.tbProfiles||[];
  const d=el('details','archive-form tb-form');d.open=state.tbOpen??(!tb.source&&!a.settings.date_from);d.ontoggle=()=>{state.tbOpen=d.open};
  d.append(el('summary','',tb.source?'Thunderbird: indeksuj / ustawienia':'Archiwum z Thunderbirda (zalecane)'));
  d.append(el('p','hint','Thunderbird pobiera pocztę, a Mail Desk tylko czyta jego pliki (niczego w nich nie zmienia) i buduje szybki indeks. Załączniki otwierają się z plików Thunderbirda – bez drugiej kopii na dysku.'));
  const path=el('input');path.placeholder='Folder profilu Thunderbirda';path.value=state.tbPath??(tb.source||profiles[0]?.path||'');path.oninput=()=>{state.tbPath=path.value;state.tbInspect=null};
  if(profiles.length){const sel=el('select');for(const p of profiles){const o=el('option','',p.name+' ('+p.accounts.join(', ')+')');o.value=p.path;sel.append(o)}
    const other=el('option','','inny folder…');other.value='';sel.append(other);sel.value=profiles.some(p=>p.path===path.value)?path.value:'';
    sel.onchange=()=>{if(sel.value){state.tbPath=sel.value;state.tbInspect=null;renderArchive()}else{path.focus()}};
    const ls=el('label','','Znaleziony profil');ls.append(sel);d.append(ls)}
  else d.append(el('p','hint','Nie znalazłem Thunderbirda automatycznie. Wklej ścieżkę do folderu profilu (Thunderbird: Pomoc → Więcej informacji dla rozwiązywania problemów → Folder profilu).'));
  const lp=el('label','','Folder');lp.append(path);d.append(lp);
  d.append(button('Sprawdź konta i foldery','secondary',async()=>{try{state.tbPath=path.value.trim();state.tbInspect=await post('thunderbird/inspect',{path:state.tbPath});state.tbOpen=true;renderArchive()}catch(e){notice(e.message,true)}}));
  if(state.tbInspect){state.tbMapping=state.tbMapping||{};
    for(const acc of state.tbInspect.accounts){const row=el('div','tb-account');const sel=el('select');
      for(const [v,t] of [['tabal','TABAL'],['skyfens','Skyfens'],['','pomiń']]){const o=el('option','',t);o.value=v;sel.append(o)}
      sel.value=state.tbMapping[acc.dir]??acc.account;state.tbMapping[acc.dir]=sel.value;sel.onchange=()=>{state.tbMapping[acc.dir]=sel.value};
      const info=el('div');info.append(el('strong','',acc.name),el('span','',` ${acc.folders} folderów · ${fmtBytes(acc.bytes)}`));
      row.append(info,sel);d.append(row)}
    if(!state.tbInspect.accounts.length)d.append(el('p','hint','W tym folderze nie ma poczty Thunderbirda.'))}
  const auto=el('label','check'),ab=el('input');ab.type='checkbox';ab.checked=tb.auto_update!==false;auto.append(ab,el('span','','Automatycznie dociągaj to, co Thunderbird pobrał (przy starcie i co kilka minut)'));d.append(auto);
  d.append(button(tb.source?'Indeksuj ponownie (tylko nowe)':'Indeksuj archiwum Thunderbirda','',async()=>{
    try{await post('thunderbird/index',{path:(state.tbPath??path.value).trim(),mapping:state.tbInspect?state.tbMapping:null,auto_update:ab.checked});
      notice('Indeksowanie trwa w tle. Pierwszy raz przy dużej poczcie może potrwać – kolejne tylko chwilę.');loadArchive()}catch(e){notice(e.message,true)}}));
  box.append(d)}
function renderArchive(){const box=$('#archiveBox');if(!box||!state.archive)return;box.replaceChildren();
  const a=state.archive,st=a.settings,job=a.job,total=a.accounts.reduce((s,x)=>s+x.messages,0),copies=a.accounts.reduce((s,x)=>s+x.with_copy,0),copyBytes=a.accounts.reduce((s,x)=>s+x.copy_bytes,0);
  const first=a.accounts.map(x=>x.first_day).filter(Boolean).sort()[0]||'',last=a.accounts.map(x=>x.last_day).filter(Boolean).sort().pop()||'';
  if(st.date_from){
    const info=el('div','archive-info');
    info.append(el('strong','',fmtNum(total)+' maili'),el('span','',first&&last?first+' – '+last:''),
      el('span','',a.thunderbird&&a.thunderbird.source?`źródło: Thunderbird · ${fmtNum(a.thunderbird.messages)} maili w jego plikach`:st.store_raw?`pełne kopie: ${fmtNum(copies)} (${fmtBytes(copyBytes)})`:'tylko tekst (bez kopii plików)'),
      el('span','',`baza ${fmtBytes(a.db_bytes)} · wolne ${fmtBytes(a.free_bytes)}`),
      el('span','',st.last_update?'aktualizacja: '+new Date(st.last_update).toLocaleString('pl-PL',{dateStyle:'short',timeStyle:'short'}):'nie ukończono pobierania'));
    box.append(info);
    if(st.project_id)box.append(button('Otwórz archiwum','',()=>openProject(st.project_id).catch(e=>notice(e.message,true))));
    renderRefreshSettings(box);
  }else{box.append(el('p','hint','Pobierz całą pocztę na ten komputer. Potem wyszukiwanie, rozmowa i załączniki działają bez Internetu.'))}
  if(job.running){
    box.append(el('div','archive-progress',({'aktualizacja':'Sprawdzam nowe maile…\n','thunderbird':'Indeksuję archiwum Thunderbirda…\n','aktualizacja Thunderbirda':'Sprawdzam, co Thunderbird pobrał…\n'}[job.mode]||'Pobieranie archiwum…\n')+archiveProgressText(job)));
    box.append(button(job.stop?'Zatrzymuję…':'Zatrzymaj (dokończę później)','secondary',async()=>{await post('archive/stop',{});loadArchive()}));
    return}
  if(job.results&&job.results.length){const msg=job.results.map(r=>r.account==='thunderbird'?(r.error?'Thunderbird: '+r.error:`Thunderbird: nowych ${fmtNum(r.imported)}, pominiętych usuniętych ${fmtNum(r.deleted_skipped)}${r.partial?', niepełnych '+fmtNum(r.partial):''}${r.failed?', błędów '+r.failed:''}${r.stopped?' (zatrzymano)':''}`):r.error?`${(state.accounts[r.account]?.label||r.account||'').split(' ')[0]}: ${r.error}`:`${(state.accounts[r.account]?.label||r.account).split(' ')[0]}: nowych ${fmtNum(r.imported)}${r.raw_saved?', kopii '+fmtNum(r.raw_saved):''}${r.failed?', błędów '+r.failed:''}${r.stopped?' (zatrzymano)':''}`).join('\n');
    box.append(el('div','archive-progress done',msg))}
  if(a.thunderbird&&a.thunderbird.partial)box.append(el('div','archive-progress warn',`Uwaga: ${fmtNum(a.thunderbird.partial)} maili Thunderbird pobrał bez pełnej treści. W Thunderbirdzie odznacz „Nie pobieraj wiadomości większych niż…” i zsynchronizuj ponownie.`));
  renderThunderbird(box);
  const form=el('details','archive-form');
  form.append(el('summary','','Pobierz bezpośrednio z serwera (bez Thunderbirda)'));
  const from=el('input');from.type='date';from.value=st.date_from||'2021-01-01';
  const lf=el('label','','Od daty');lf.append(from);
  const raw=el('label','check'),cb=el('input');cb.type='checkbox';cb.checked=st.store_raw!==false;raw.append(cb,el('span','','Zapisuj pełne maile z załącznikami (pliki dostępne offline)'));
  const auto=el('label','check'),ab=el('input');ab.type='checkbox';ab.checked=st.auto_update!==false;auto.append(ab,el('span','','Dociągaj nowe maile automatycznie (przy starcie i co kilka minut)'));
  const go=button(st.date_from?'Uzupełnij teraz':'Pobierz archiwum','',async()=>{
    const accounts=Object.values(state.accounts).filter(x=>x.configured);
    if(!accounts.length)return notice('Najpierw wpisz login i hasło skrzynki w „Konfiguracja kont i AI”.',true);
    try{await post('archive/start',{date_from:from.value,store_raw:cb.checked,auto_update:ab.checked});notice('Pobieranie trwa w tle. Możesz pracować dalej; komputer nie powinien zasypiać.');loadArchive()}catch(e){notice(e.message,true)}});
  form.append(lf,raw,auto,go,el('p','hint','Pierwsze pobieranie kilku lat poczty może trwać kilka godzin – najlepiej zostawić na noc. Przerwanie jest bezpieczne: kolejne uruchomienie dokończy od miejsca przerwania.'));
  box.append(form);
  if(total){const folders=el('details','archive-folders');folders.append(el('summary','',`Foldery (${a.accounts.reduce((s,x)=>s+x.folders.length,0)})`));
    for(const acc of a.accounts){if(!acc.folders.length)continue;folders.append(el('div','folder-head',acc.label));
      for(const f of acc.folders){const row=el('div','folder-row');row.append(el('span','',f.folder),el('span','',fmtNum(f.n)));folders.append(row)}}
    box.append(folders)}}
/* 5.8 — Analiza zbiorcza */
function inlineNodes(text){const out=[];const parts=String(text).split(/(\*\*[^*]+\*\*|\[\d+(?:\s*[,;]\s*\d+)*\])/);
  for(const part of parts){if(!part)continue;
    if(/^\*\*[^*]+\*\*$/.test(part)){out.push(el('strong','',part.slice(2,-2)))}
    else if(/^\[\d/.test(part)){const ids=part.match(/\d+/g);const span=el('span','cites');
      ids.forEach(id=>{const b=button(id,'cite',()=>openMessage(Number(id)).catch(e=>notice(e.message,true)));b.title=metaText(id);span.append(b)});out.push(span)}
    else out.push(document.createTextNode(part))}
  return out}
function renderMarkdown(md){const box=el('div','report');const lines=String(md||'').split('\n');let list=null,table=null;
  const flush=()=>{list=null;table=null};
  for(const raw of lines){const line=raw.trimEnd();
    if(/^\s*\|/.test(line)){const cells=line.trim().replace(/^\||\|$/g,'').split('|').map(c=>c.trim());
      if(cells.every(c=>/^:?-+:?$/.test(c)))continue;
      if(!table){table=el('table','report-table');box.append(table);const tr=el('tr');cells.forEach(c=>{const th=el('th');th.append(...inlineNodes(c));tr.append(th)});table.append(tr);continue}
      const tr=el('tr');cells.forEach(c=>{const td=el('td');td.append(...inlineNodes(c));tr.append(td)});table.append(tr);continue}
    const h=line.match(/^(#{1,4})\s+(.*)$/);
    if(h){flush();const e=el('h'+Math.min(6,h[1].length+2));e.append(...inlineNodes(h[2]));box.append(e);continue}
    const li=line.match(/^\s*(?:[-*•]|\d+[.)])\s+(.*)$/);
    if(li){table=null;if(!list){list=el('ul');box.append(list)}const item=el('li');item.append(...inlineNodes(li[1]));list.append(item);continue}
    if(!line.trim()){flush();continue}
    flush();const p=el('p');p.append(...inlineNodes(line));box.append(p)}
  return box}
async function loadAnalyses(){if(!state.projectId)return;try{state.analysisList=(await get('analyses?project='+state.projectId)).analyses}catch(e){state.analysisList=[]}}
async function watchAnalysis(){clearTimeout(state.analysisTimer);
  try{const job=await get('analysis/status');const was=state.analysisJob?.running;state.analysisJob=job;
    if(job.running)state.analysisTimer=setTimeout(watchAnalysis,2000);
    else if(was){await loadAnalyses();if(job.result?.id){state.analysisView=await get('analysis?id='+job.result.id)};state.analysisEstimate=null}
    if(state.tab==='analysis')renderWorkspace()}catch(e){}}
function analysisParams(scope){return {id:state.projectId,scope,query:state.searchQuery||'',inflect:state.inflect}}
function renderAnalysis(right){const pane=el('div','analysis-pane');right.append(pane);
  const job=state.analysisJob||{};
  if(job.running){const p=job.progress||{};const box=el('div','analysis-run');
    const phase={'wyciągi':'Czytam maile i robię wyciągi','streszczenia':'Streszczam kolejne okresy','raport':'Piszę raport'}[p.phase]||'Przygotowuję…';
    box.append(el('h3','',phase),el('p','',`${fmtNum(p.done||0)} / ${fmtNum(p.total||0)}${p.phase==='wyciągi'?' maili':''} · koszt dotąd ok. ${(p.cost_usd||0).toFixed(2)} USD`));
    const bar=el('div','bar'),fill=el('div','fill');fill.style.width=(p.total?Math.round(100*(p.done||0)/p.total):3)+'%';bar.append(fill);box.append(bar);
    box.append(button(job.stop?'Zatrzymuję…':'Zatrzymaj (gotowe wyciągi zostaną)','secondary',async()=>{await post('analysis/stop',{});watchAnalysis()}));
    pane.append(box);return}
  if(state.analysisView){const a=state.analysisView;const head=el('div','analysis-head');
    head.append(button('← Nowa analiza','secondary',()=>{state.analysisView=null;renderWorkspace()}),
      el('span','meta',`${fmtNum(a.message_count)} maili · ${a.created_at.slice(0,16).replace('T',' ')} · koszt ok. ${Number(a.cost_usd).toFixed(2)} USD · ${a.status}`));
    pane.append(head,el('h3','',a.goal));
    if(a.error)pane.append(el('div','archive-progress warn',a.error));
    if(a.report){pane.append(renderMarkdown(a.report));
      const dl=el('div','analysis-actions');
      dl.append(button('Pobierz raport (.md)','secondary',()=>{location.href='/api/analysis/report.md?id='+a.id}),
        button('Tabela faktów (.csv)','secondary',()=>{const q=new URLSearchParams({project:state.projectId,scope:a.scope,query:a.query||''});if(a.date_from)q.set('date_from',a.date_from);if(a.date_to)q.set('date_to',a.date_to);location.href='/api/analysis/facts.csv?'+q}));
      pane.append(dl,el('p','hint','Liczby w nawiasach to maile, na których oparto zdanie – kliknij, aby je otworzyć i sprawdzić.'))}
    return}
  pane.append(el('p','hint','Analiza zbiorcza czyta wiele maili (także z wielu lat), robi z każdego krótki wyciąg (kwoty, terminy, ustalenia, problemy), a potem składa raport z odnośnikami do źródeł. Wyciągi zapisują się na komputerze – każda kolejna analiza tych samych maili jest szybka i tania.'));
  const goal=el('textarea');goal.placeholder='Cel analizy, np. „Przebieg współpracy z Aliplast 2021–2025: ceny, terminy dostaw, reklamacje, otwarte sprawy”';goal.value=state.analysisGoal||'';goal.maxLength=2000;goal.oninput=()=>{state.analysisGoal=goal.value};
  const lg=el('label','','Cel analizy');lg.append(goal);pane.append(lg);
  const scopes=el('div','scope-list');const hasSearch=!!(state.searchResults);
  if(!state.analysisScope)state.analysisScope=hasSearch?'search':'project';
  const opt=(value,label,desc,disabled)=>{const l=el('label','scope'+(disabled?' disabled':''));const r=el('input');r.type='radio';r.name='scope';r.value=value;r.checked=state.analysisScope===value;r.disabled=!!disabled;r.onchange=()=>{state.analysisScope=value;state.analysisEstimate=null;renderWorkspace()};l.append(r,el('span','',label));if(desc)l.append(el('small','',desc));scopes.append(l)};
  const sr=state.searchResults;
  opt('search','Wyniki wyszukiwania',hasSearch?`„${sr.query||'(bez frazy)'}” · ${sr.date_from||'…'} – ${sr.date_to||'…'} · ${fmtNum(sr.total)} maili`:'najpierw wyszukaj (np. nazwę firmy) w polu powyżej',!hasSearch);
  opt('project','Cały projekt',`${fmtNum(state.data.total_messages)} maili`);
  opt('archive','Całe archiwum tych skrzynek','wszystkie pobrane maile – sensowne zwłaszcza do „Przygotuj wyciągi”');
  const ls=el('label','','Zakres');ls.append(scopes);pane.append(ls);
  const budget=el('input');budget.type='number';budget.min='0.1';budget.step='0.5';budget.value=state.analysisBudget||'5';budget.oninput=()=>{state.analysisBudget=budget.value};
  const lb=el('label','budget','Limit kosztu (USD) – po jego osiągnięciu analiza się zatrzyma');lb.append(budget);pane.append(lb);
  const actions=el('div','analysis-actions');
  actions.append(button('Oszacuj koszt','',async()=>{try{state.analysisEstimate=await post('analysis/estimate',analysisParams(state.analysisScope));state.analysisConsent=false;renderWorkspace()}catch(e){notice(e.message,true)}}));
  pane.append(actions);
  const est=state.analysisEstimate;
  if(est){const box=el('div','estimate');
    box.append(el('strong','',`${fmtNum(est.messages)} maili`),el('span','',`gotowe wyciągi: ${fmtNum(est.ready)} · do przygotowania: ${fmtNum(est.to_extract)}`),
      el('span','',`Szacowany koszt: ok. ${est.cost_usd.toFixed(2)} USD (wyciągi ${est.cost_extract_usd.toFixed(2)} + raport ${est.cost_report_usd.toFixed(2)}) · wyciągi: ${est.model}, raport: ${est.report_model} · ok. ${est.minutes} min`),
      el('small','',`Szacunek wg cen ${est.price_in}/${est.price_out} USD za 1 mln tokenów (wejście/wyjście) – sprawdź aktualny cennik OpenAI.`));
    const ok=el('label','check'),cb=el('input');cb.type='checkbox';cb.checked=!!state.analysisConsent;cb.onchange=()=>{state.analysisConsent=cb.checked};ok.append(cb,el('span','',`Rozumiem, że treść ${fmtNum(est.to_extract)} maili (bez cytowanej historii) i tekst ich załączników zostaną wysłane do OpenAI.`));
    box.append(ok);
    const run=(prepare)=>async()=>{if(!prepare&&!goal.value.trim())return notice('Opisz cel analizy.',true);if(est.to_extract&&!cb.checked)return notice('Zaznacz zgodę na wysłanie maili do OpenAI.',true);
      try{await post('analysis/start',{...analysisParams(state.analysisScope),goal:goal.value,budget_usd:Number(budget.value||5),prepare_only:prepare,confirm:true});state.analysisEstimate=null;watchAnalysis()}catch(e){notice(e.message,true)}};
    const go=el('div','analysis-actions');go.append(button('Uruchom analizę','',run(false)),button('Tylko przygotuj wyciągi','secondary',run(true)));
    if(!state.ai){go.querySelectorAll('button').forEach(b=>b.disabled=true);box.append(el('p','hint','Wpisz klucz OpenAI w „Konfiguracja kont i AI”.'))}
    box.append(go);pane.append(box)}
  const list=state.analysisList||[];
  if(list.length){pane.append(el('h3','','Wcześniejsze analizy'));const ul=el('div','analysis-list');
    for(const a of list){const b=button('','analysis-item',async()=>{try{state.analysisView=await get('analysis?id='+a.id);renderWorkspace()}catch(e){notice(e.message,true)}});
      b.append(el('strong','',a.goal),el('span','',`${a.created_at.slice(0,10)} · ${fmtNum(a.message_count)} maili · ${a.status} · ${Number(a.cost_usd).toFixed(2)} USD`));ul.append(b)}
    pane.append(ul)}}
$('#projectForm').onsubmit=async event=>{event.preventDefault();try{const p=await post('project/create',{name:$('#name').value,sender_query:$('#senderQuery').value,account:$('#account').value});$('#createBox').open=false;$('#projectForm').reset();await openProject(p.id);notice(p.local_messages?'Projekt zapisany: '+fmtNum(p.local_messages)+' maili z poczty na komputerze. Nowe maile będą dopisywane same.':'Projekt zapisany. Nie ma jeszcze pasujących maili – podłącz Thunderbirda w panelu Archiwum poczty.')}catch(e){notice(e.message,true)}};
$('#errorsButton').onclick=async()=>{try{const rows=(await get('mail-errors')).errors;const root=$('#workspace');root.replaceChildren(el('h2','','Dziennik błędów IMAP/SMTP'));root.append(button('Wróć do projektu','secondary',()=>state.projectId&&openProject(state.projectId)),button('Pobierz pełny log','secondary',()=>{window.location.href='/api/mail-errors/export'}));if(!rows.length)root.append(el('p','hint','Brak błędów poczty.'));for(const row of rows){const e=el('div','log-entry');append(e,el('small','',row.created_at+' · '+row.account+' · '+row.operation),el('div','',row.detail));root.append(e)}}catch(e){notice(e.message,true)}};
for(const [account,id,label] of [['tabal','checkTabal','TABAL'],['skyfens','checkSkyfens','Skyfens']]){$('#'+id).onclick=async()=>{const target=$('#checkResults');target.className='check-results';target.textContent='Sprawdzam '+label+'…';try{const result=await post('imap/check',{account});target.className='check-results '+(result.ok?'passed':'failed');target.textContent=label+': '+result.message}catch(e){target.className='check-results failed';target.textContent=label+': '+e.message}}}
for(const account of ['tabal','skyfens']){$('#'+account+'Form').onsubmit=async event=>{event.preventDefault();const form=event.currentTarget,submit=form.querySelector('button'),login=$('#'+account+'Login'),password=$('#'+account+'Password');submit.disabled=true;try{await post('account/config',{account,login:login.value,password:password.value});password.value='';await loadProjects();$('#'+(account==='tabal'?'checkTabal':'checkSkyfens')).click()}catch(e){notice(e.message,true)}finally{submit.disabled=false}}}
$('#aiForm').onsubmit=async event=>{event.preventDefault();const input=$('#aiKey'),submit=$('#aiForm button');submit.disabled=true;try{await post('ai/config',{key:input.value});input.value='';await loadProjects();$('#checkAI').click()}catch(e){notice(e.message,true)}finally{submit.disabled=false}};
async function saveChatModel(){const sel=$('#chatModel'),eff=$('#chatEffort'),out=$('#chatModelResult');let model=sel.value;
  if(model==='inny'){model=(prompt('Nazwa modelu OpenAI (np. gpt-5.6-sol):')||'').trim();if(!model){sel.value=state.chatModel||'gpt-5.6-terra';return}
    if(![...sel.options].some(o=>o.value===model)){const o=document.createElement('option');o.value=o.textContent=model;sel.insertBefore(o,sel.lastElementChild)}sel.value=model}
  $('#effortLabel').style.display=/^(gpt-5|o\d)/.test(model)?'':'none';
  out.className='check-results';out.textContent='Zapisuję i sprawdzam dostęp do '+model+'…';
  try{const r=await post('ai/chat-model',{model,effort:eff.value});out.className='check-results '+(r.check.ok?'passed':'failed');
    out.textContent=r.check.ok?`${model}: działa (staranność: ${r.reasoning?eff.selectedOptions[0].textContent.split(' –')[0]:'nie dotyczy'}).`:`${model}: ${r.check.message}`;
    await loadProjects();if(state.projectId)await refreshProject()}catch(e){out.className='check-results failed';out.textContent=e.message}}
$('#chatModel').onchange=saveChatModel;$('#chatEffort').onchange=saveChatModel;
$('#extractModel').onchange=async()=>{const sel=$('#extractModel'),out=$('#extractModelResult');out.className='check-results';out.textContent='Zapisuję i sprawdzam dostęp do '+sel.value+'…';
  try{const r=await post('ai/extract-model',{model:sel.value});state.extractModel=r.model;out.className='check-results '+(r.check.ok?'passed':'failed');out.textContent=r.check.ok?`${r.model}: działa.`:`${r.model}: ${r.check.message}`}catch(e){out.className='check-results failed';out.textContent=e.message}};
$('#checkAI').onclick=async()=>{const target=$('#aiCheckResults'),button=$('#checkAI');button.disabled=true;target.className='check-results';target.textContent='Sprawdzam model…';try{const r=await post('ai/check',{});target.className='check-results '+(r.ok?'passed':'failed');target.textContent=r.model+': '+r.message}catch(e){target.className='check-results failed';target.textContent=e.message}finally{button.disabled=false}};
loadProjects().then(()=>{loadArchive();watchAnalysis();pollRefresh();loadPendingReplies();{const xs=$('#extractModel'),xm=state.extractModel||'gpt-5.6-luna';if(![...xs.options].some(o=>o.value===xm)){const o=document.createElement('option');o.value=o.textContent=xm;xs.append(o)}xs.value=xm}{const sel=$('#chatModel'),m=state.chatModel||'gpt-5.6-terra';if(![...sel.options].some(o=>o.value===m)){const o=document.createElement('option');o.value=o.textContent=m;sel.insertBefore(o,sel.lastElementChild)}sel.value=m;$('#chatEffort').value=state.effort||'medium';$('#effortLabel').style.display=/^(gpt-5|o\d)/.test(m)?'':'none'}for(const account of ['tabal','skyfens'])$('#'+account+'Login').value=state.accounts[account]?.login||'';let saved=0;try{saved=Number(localStorage.getItem('maildesk_project'))}catch(e){}if(saved&&state.projects.some(p=>p.id===saved))return openProject(saved)}).catch(e=>notice(e.message,true));
