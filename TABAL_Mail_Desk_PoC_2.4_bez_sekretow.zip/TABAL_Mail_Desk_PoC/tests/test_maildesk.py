import io
import imaplib
import json
import os
import socket
import sys
import tempfile
import unittest
from email.message import EmailMessage
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import maildesk as app


class FakeIMAP:
    fetch_calls = 0
    def __init__(self, host, port):
        self.host, self.port = host, port
    def login(self, user, password):
        assert user == "martin@tabal.pl"
    def select(self, mailbox, readonly=False):
        assert readonly is True
        return "OK", [b"1"]
    def uid(self, action, *args):
        if action == "search":
            return "OK", [b"101"]
        assert args[-1] == "(BODY.PEEK[])"
        FakeIMAP.fetch_calls += 1
        msg = EmailMessage()
        msg["From"] = "Klient <klient@example.org>"
        msg["To"] = "martin@tabal.pl"
        msg["Subject"] = "Oferta tablic"
        msg["Message-ID"] = "<mail-101@example.org>"
        msg.set_content("Proszę o ofertę do piątku")
        return "OK", [(b"1 (BODY[] {100}", msg.as_bytes())]
    def logout(self):
        pass


class FakeSMTP:
    sent = []
    def __init__(self, host, port, timeout):
        assert (host,port) == ("smtp.example.org",587)
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def starttls(self,context): pass
    def login(self,user,password):
        assert user == "martin@tabal.pl"
    def send_message(self,msg):
        self.sent.append(msg)


class FakeResponse:
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def read(self,*args): return self.blob


class MailDeskTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ,{
            "TABAL_LOGIN":"martin@tabal.pl","TABAL_PASSWORD":"fake-test-password",
            "TABAL_IMAP_HOST":"imap.example.org","TABAL_SMTP_HOST":"smtp.example.org",
            "TABAL_SMTP_PORT":"587","TABAL_SMTP_SECURITY":"starttls",
            "OPENAI_API_KEY":"fake-test-key"})
        self.env.start()
        FakeIMAP.fetch_calls = 0
        FakeSMTP.sent = []
    def tearDown(self):
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()

    def test_full_flow_and_no_duplicate_send(self):
        first = app.sync_account("tabal", FakeIMAP)
        second = app.sync_account("tabal", FakeIMAP)
        self.assertEqual(first["imported"],1)
        self.assertEqual(second["skipped"],1)
        self.assertEqual(FakeIMAP.fetch_calls,1)
        with app.connect() as db:
            row = db.execute("SELECT * FROM messages").fetchone()
            message_id = row["id"]
        app.analyze(message_id,"demo")
        with self.assertRaises(ValueError):
            app.send_mail(message_id,"klient@example.org","Treść",False,FakeSMTP)
        result = app.send_mail(message_id,"klient@example.org","Odpowiedź testowa",True,FakeSMTP)
        self.assertEqual(result["from"],"martin@tabal.pl")
        self.assertEqual(len(FakeSMTP.sent),1)
        self.assertEqual(FakeSMTP.sent[0]["In-Reply-To"],"<mail-101@example.org>")
        with self.assertRaises(ValueError):
            app.send_mail(message_id,"klient@example.org","Ponownie",True,FakeSMTP)

    def test_demo_messages_cannot_send(self):
        app.demo_seed()
        with app.connect() as db:
            row = db.execute("SELECT id FROM messages LIMIT 1").fetchone()
        app.analyze(row["id"],"demo")
        with self.assertRaisesRegex(ValueError,"Przykładowe"):
            app.send_mail(row["id"],"klient@example.org","Szkic",True,FakeSMTP)
        self.assertFalse(FakeSMTP.sent)

    def test_api_analysis_structured_response_and_untrusted_email(self):
        app.sync_account("tabal",FakeIMAP)
        with app.connect() as db:
            row = dict(db.execute("SELECT * FROM messages").fetchone())
        expected = {"category":"Zapytanie","priority":"wysoki","summary":"Prośba o ofertę",
                    "action":"Przygotować ofertę","due":"piątek","draft":"Dzień dobry..."}
        output = {"output":[{"content":[{"type":"output_text","text":json.dumps(expected)}]}]}
        def fake_open(request,timeout):
            self.assertEqual(request.full_url,"https://api.openai.com/v1/responses")
            body = json.loads(request.data)
            self.assertFalse(body["store"])
            self.assertEqual(body["text"]["format"]["type"],"json_schema")
            response = FakeResponse()
            response.blob = json.dumps(output).encode()
            return response
        result = app.ai_analysis(row, fake_open)
        self.assertEqual(result,expected)

    def test_project_date_company_sync_and_question_history(self):
        today = app.date.today().isoformat()
        project = app.create_project("Klient Example",today,today,"example.org","tabal")
        result = app.sync_project_account(project["id"],"tabal",FakeIMAP)
        self.assertEqual((result["checked"],result["added"]),(1,1))
        self.assertEqual(app.sync_project_account(project["id"],"tabal",FakeIMAP)["added"],0)
        answer = app.ask_project(project["id"],"Jaka oferta i termin?","local")
        self.assertIn("Oferta tablic",answer["answer"])
        self.assertEqual(len(answer["sources"]),1)
        saved = app.project_data(project["id"])
        self.assertEqual(saved["history"][0]["question"],"Jaka oferta i termin?")
        self.assertEqual(saved["messages"][0]["account"],"tabal")
        self.assertTrue(app.sender_matches("Firma ABC <zakupy@abc.pl>","ABC"))
        self.assertFalse(app.sender_matches("Firma ABC <zakupy@abc.pl>","Inna"))

    def test_date_filter_and_error_log_redacts_password(self):
        old = (app.date.today()-app.timedelta(days=3)).isoformat()
        project = app.create_project("Stary projekt",old,old,"","tabal")
        result = app.sync_project_account(project["id"],"tabal",FakeIMAP)
        self.assertEqual(result["added"],0)  # server mocked; header date still checked locally
        class BrokenIMAP(FakeIMAP):
            def login(self,user,password):
                raise imaplib.IMAP4.error("LOGIN failed: " + password)
        with self.assertRaises(imaplib.IMAP4.error):
            app.sync_project_account(project["id"],"tabal",BrokenIMAP)
        with app.connect() as db:
            detail = db.execute("SELECT detail FROM mail_errors ORDER BY id DESC LIMIT 1").fetchone()[0]
        self.assertIn("[REDACTED]",detail)
        self.assertNotIn("fake-test-password",detail)
        self.assertIn("odrzucił login lub hasło",app.sync_error_message(
            imaplib.IMAP4.error("[AUTHENTICATIONFAILED] Authentication failed.")))
        self.assertNotIn("fake-test-password",app.sync_error_message(
            RuntimeError("server error: fake-test-password")))

    def test_demo_project_and_both_mail_smtp_config(self):
        today=app.date.today().isoformat()
        project=app.create_project("Pokaz",today,today,"","both")
        self.assertEqual(app.add_demo_to_project(project["id"])["added"],3)
        self.assertEqual(len(app.project_data(project["id"])["messages"]),3)
        with patch.dict(os.environ,{"TABAL_SMTP_PORT":"465","TABAL_SMTP_SECURITY":"ssl"}):
            cfg=app.env_account("tabal")
            self.assertEqual((cfg["smtp_port"],cfg["smtp_security"]),(465,"ssl"))
        sky=app.env_account("skyfens")
        self.assertEqual((sky["imap_host"],sky["smtp_port"],sky["smtp_security"]),
                         ("mail.skyfens.pl",587,"starttls"))

    def test_imap_connection_check_separates_network_and_login(self):
        class GoodIMAP:
            def __init__(self,host,port,timeout):
                self.assertion = (host,port,timeout)
            def login(self,user,password):
                self.user = user
            def logout(self): pass
        good=app.check_imap_account("tabal",GoodIMAP)
        self.assertTrue(good["ok"])
        self.assertEqual(good["stage"],"login")
        class RejectedIMAP(GoodIMAP):
            def login(self,user,password):
                raise imaplib.IMAP4.error("[AUTHENTICATIONFAILED] " + password)
        rejected=app.check_imap_account("tabal",RejectedIMAP)
        self.assertEqual(rejected["stage"],"login")
        self.assertNotIn("fake-test-password",rejected["message"])
        def no_dns(host,port,timeout):
            raise socket.gaierror(-3,"temporary DNS error")
        network=app.check_imap_account("tabal",no_dns)
        self.assertEqual(network["stage"],"connection")
        self.assertIn("DNS",network["message"])
        with app.connect() as db:
            detail=db.execute("SELECT detail FROM mail_errors WHERE operation='IMAP login test'").fetchone()[0]
        self.assertNotIn("fake-test-password",detail)

    def test_project_ai_answer_uses_only_eligible_sources(self):
        today=app.date.today().isoformat()
        project=app.create_project("Źródła",today,today,"","tabal")
        app.sync_project_account(project["id"],"tabal",FakeIMAP)
        m=app.project_data(project["id"])["messages"][0]
        output={"output":[{"content":[{"type":"output_text","text":json.dumps({
            "answer":"Termin to piątek.","source_ids":[m["id"],999999]})}]}]}
        def fake_open(request,timeout):
            body=json.loads(request.data)
            self.assertFalse(body["store"])
            self.assertIn(str(m["id"]),body["input"])
            response=FakeResponse()
            response.blob=json.dumps(output).encode()
            return response
        answer, ids=app.answer_with_ai("Jaki termin?",[m],fake_open)
        self.assertIn("piątek",answer)
        self.assertEqual(ids,[m["id"]])


if __name__ == "__main__":
    unittest.main()
