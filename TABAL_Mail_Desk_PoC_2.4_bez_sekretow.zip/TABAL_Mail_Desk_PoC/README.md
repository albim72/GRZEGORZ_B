# TABAL Mail Desk - projekty i poczta (PoC v2.4)

Lokalny prototyp dla Grzegorza. Uruchomienie wymaga Pythona 3.10 lub nowszego; aplikacja nie wymaga instalacji bibliotek. Działa pod adresem http://127.0.0.1:8765 i zapisuje projekty oraz historię pytań w lokalnej bazie `maildesk.sqlite3`.

## Szybki test na Macu

1. Rozpakuj ZIP. W Terminalu wpisz `sh ` (ze spacją), przeciągnij plik `start_mac_linux.sh` do Terminala i naciśnij Enter. Na Windows użyj `start_windows.bat`.
2. Ręcznie wpisz w przeglądarce `http://127.0.0.1:8765`. Terminal pozostaw otwarty.
3. Utwórz projekt: wpisz nazwę, daty obejmujące dzisiejszy dzień, pozostaw puste pole nadawcy i wybierz obie skrzynki.
4. Kliknij **Dodaj przykłady**. Zobacz listę trzech wiadomości w projekcie.
5. W polu po prawej wpisz np. „Jaki termin padł w mailu o tablicach?” i kliknij **Szukaj lokalnie**. Odpowiedź zawiera znalezione fragmenty i odnośniki do wiadomości. Kliknij źródło, by otworzyć mail.
6. Wybierz **Rozmowa**, aby wrócić do pytań. Zamknij stronę, otwórz ją ponownie: projekt i historia powinny pozostać na liście po lewej.
7. W widoku wiadomości można uruchomić analizę demonstracyjną i edytować szkic. Przykładowe maile nie są wysyłane. Zakończ pracę przez `Ctrl+C` w Terminalu.

## Konfiguracja kont martin@

Skopiuj `.env.example` jako `.env.local` w folderze programu i wpisz hasła do skrzynek. Hosty i porty zostały już wpisane według wiadomości Darka z 2 października 2026:

| Konto | IMAP | SMTP |
| --- | --- | --- |
| martin@tabal.pl | tabal.home.pl:993 SSL/TLS | tabal.home.pl:465 SSL/TLS |
| martin@skyfens.pl | mail.skyfens.pl:993 SSL/TLS | mail.skyfens.pl:587 STARTTLS |

SMTP korzysta z loginu i hasła danej skrzynki. Po zmianie `.env.local` uruchom aplikację ponownie. Hasła i klucz API nigdy nie powinny trafiać do ZIP ani wiadomości e-mail.

**Aktualizacja istniejącej instalacji:** zatrzymaj program, rozpakuj nowy ZIP na dotychczasowy folder, a następnie uruchom go ponownie. Nowy ZIP nie zawiera `.env.local` ani `maildesk.sqlite3`, więc lokalne hasła, projekty i historia zostają na komputerze. Przy rozpakowaniu do nowego folderu skopiuj tam swój `.env.local` ze starego folderu; bazę `maildesk.sqlite3` skopiuj tylko, jeśli chcesz zachować projekty. Nie kopiuj starego `.env.example`, jeżeli wpisałeś tam sekrety.

W panelu po lewej wybierz **Sprawdź IMAP TABAL** i **Sprawdź IMAP Skyfens**. Test sprawdza TLS i logowanie, bez pobierania wiadomości. Wynik rozróżnia brak konfiguracji, błąd sieci/DNS, TLS i odrzucony login. Pełna odpowiedź serwera jest zapisywana w **Dzienniku błędów poczty**, po usunięciu znanych haseł i klucza. Jeśli oba konta odrzucają logowanie, potwierdź u administratora poprawność haseł i możliwość korzystania z IMAP. Sam klucz OpenAI nie ma wpływu na IMAP.

Etykieta **dane wpisane** oznacza tylko, że login i hasło są w konfiguracji; nie potwierdza logowania. Jeśli przy pobieraniu Skyfens pojawi się komunikat o odrzuconym loginie lub haśle, sprawdź `SKYFENS_LOGIN=martin@skyfens.pl` i `SKYFENS_PASSWORD` w `.env.local`, zapisz plik, zatrzymaj program (`Ctrl+C`) i uruchom go ponownie. Szczegóły odpowiedzi serwera są w **Dzienniku błędów poczty**. Nie wysyłaj nikomu hasła ani tego pliku.

W projekcie wybierz datę **od** i **do** (obie włącznie), adres nadawcy lub nazwę firmy i jedną albo obie skrzynki. **Pobierz z poczty** wykonuje jedną ręczną synchronizację. Serwer IMAP filtruje daty, a aplikacja sprawdza nazwę w polu nadawcy lub w domenie e-mail. Nie posiada jeszcze książki kontaktów wiążącej każdą nazwę prawną firmy z jej adresem. Dla bezpieczeństwa pobieranych jest najwyżej 100 najnowszych wiadomości z wybranego zakresu na konto, o rozmiarze do 2 MB każda. Duże projekty trzeba podzielić na węższe zakresy dat.

IMAP otwierany jest tylko do odczytu (`BODY.PEEK[]`); powtórny import nie tworzy duplikatów. Błędy serwerów są dostępne pod **Dziennik błędów poczty** z komunikatami serwera i datą; aplikacja usuwa z zapisanych komunikatów znane hasła i klucz API. Nie ma automatycznej wysyłki. Rzeczywisty mail można wysłać dopiero po edycji szkicu, zaznaczeniu potwierdzenia i dodatkowym kliknięciu w oknie potwierdzenia. Konto nadawcze odpowiada skrzynce, z której pobrano mail.

## Pytania do projektu

**Szukaj lokalnie** wyszukuje pasujące maile i pokazuje ich fragmenty bez kosztów API. To prosty tryb demonstracyjny, który nie syntetyzuje wielowątkowej odpowiedzi. **Zapytaj AI** jest dostępne po konfiguracji `OPENAI_API_KEY`; odpowiedź ma odnosić się wyłącznie do wiadomości projektu, a źródła można otworzyć. Klucz utworzony w środowisku przygotowania nie jest dołączony do ZIP. Test na tamtym koncie zwrócił `credit_balance_exhausted`, więc przed użyciem AI potrzebny jest dostępny budżet API. Mail do AI przekazuje nadawcę, datę, temat i tekst wiadomości, bez binarnych załączników. Planowany lokalny serwer modeli można podłączyć później, gdy Darek go uruchomi.

Aplikacja pracuje tylko na tym komputerze (`127.0.0.1`). Dane przechowuje w pliku SQLite w folderze aplikacji. Nie udostępniaj pliku `.env.local` ani `maildesk.sqlite3` osobom postronnym.

## Kontrola techniczna

`python -m unittest discover -s tests -v` uruchamia testy IMAP, SMTP, projektów, filtrów, historii pytań i dziennika błędów na symulowanych usługach. Test połączenia z prawdziwymi serwerami z tego środowiska nie dotarł do etapu TCP: nazwy hostów nie zostały tu rozpoznane przez DNS. Próbę logowania należy wykonać po wpisaniu haseł lokalnie na komputerze z dostępem do serwerów.
