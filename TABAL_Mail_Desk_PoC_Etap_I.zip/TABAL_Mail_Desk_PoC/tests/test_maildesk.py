import io
import json
import os
import sys
import tempfile
import unittest
from email.message import EmailMessage
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import maildesk as app


class FakeIMAP:
    fetch_calls = 0
    def __init__(self, host, port):
        self.host, self.port = host, port
    def login(self, user, password):
        assert user == "martin@tabal.pl"
    def select(self, mailbox, readonly=False):
        assert readonly is True
        return "OK", [b"1"]
    def uid(self, action, *args):
        if action == "search":
            return "OK", [b"101"]
        assert args[-1] == "(BODY.PEEK[])"
        FakeIMAP.fetch_calls += 1
        msg = EmailMessage()
        msg["From"] = "Klient <klient@example.org>"
        msg["To"] = "martin@tabal.pl"
        msg["Subject"] = "Oferta tablic"
        msg["Message-ID"] = "<mail-101@example.org>"
        msg.set_content("Proszę o ofertę do piątku")
        return "OK", [(b"1 (BODY[] {100}", msg.as_bytes())]
    def logout(self):
        pass


class FakeSMTP:
    sent = []
    def __init__(self, host, port, timeout):
        assert (host,port) == ("smtp.example.org",587)
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def starttls(self,context): pass
    def login(self,user,password):
        assert user == "martin@tabal.pl"
    def send_message(self,msg):
        self.sent.append(msg)


class FakeResponse:
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def read(self,*args): return self.blob


class MailDeskTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ,{
            "TABAL_LOGIN":"martin@tabal.pl","TABAL_PASSWORD":"fake-test-password",
            "TABAL_IMAP_HOST":"imap.example.org","TABAL_SMTP_HOST":"smtp.example.org",
            "TABAL_SMTP_PORT":"587","TABAL_SMTP_SECURITY":"starttls",
            "OPENAI_API_KEY":"fake-test-key"})
        self.env.start()
        FakeIMAP.fetch_calls = 0
        FakeSMTP.sent = []
    def tearDown(self):
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()

    def test_full_flow_and_no_duplicate_send(self):
        first = app.sync_account("tabal", FakeIMAP)
        second = app.sync_account("tabal", FakeIMAP)
        self.assertEqual(first["imported"],1)
        self.assertEqual(second["skipped"],1)
        self.assertEqual(FakeIMAP.fetch_calls,1)
        with app.connect() as db:
            row = db.execute("SELECT * FROM messages").fetchone()
            message_id = row["id"]
        app.analyze(message_id,"demo")
        with self.assertRaises(ValueError):
            app.send_mail(message_id,"klient@example.org","Treść",False,FakeSMTP)
        result = app.send_mail(message_id,"klient@example.org","Odpowiedź testowa",True,FakeSMTP)
        self.assertEqual(result["from"],"martin@tabal.pl")
        self.assertEqual(len(FakeSMTP.sent),1)
        self.assertEqual(FakeSMTP.sent[0]["In-Reply-To"],"<mail-101@example.org>")
        with self.assertRaises(ValueError):
            app.send_mail(message_id,"klient@example.org","Ponownie",True,FakeSMTP)

    def test_demo_messages_cannot_send(self):
        app.demo_seed()
        with app.connect() as db:
            row = db.execute("SELECT id FROM messages LIMIT 1").fetchone()
        app.analyze(row["id"],"demo")
        with self.assertRaisesRegex(ValueError,"Przykładowe"):
            app.send_mail(row["id"],"klient@example.org","Szkic",True,FakeSMTP)
        self.assertFalse(FakeSMTP.sent)

    def test_api_analysis_structured_response_and_untrusted_email(self):
        app.sync_account("tabal",FakeIMAP)
        with app.connect() as db:
            row = dict(db.execute("SELECT * FROM messages").fetchone())
        expected = {"category":"Zapytanie","priority":"wysoki","summary":"Prośba o ofertę",
                    "action":"Przygotować ofertę","due":"piątek","draft":"Dzień dobry..."}
        output = {"output":[{"content":[{"type":"output_text","text":json.dumps(expected)}]}]}
        def fake_open(request,timeout):
            self.assertEqual(request.full_url,"https://api.openai.com/v1/responses")
            body = json.loads(request.data)
            self.assertFalse(body["store"])
            self.assertEqual(body["text"]["format"]["type"],"json_schema")
            response = FakeResponse()
            response.blob = json.dumps(output).encode()
            return response
        result = app.ai_analysis(row, fake_open)
        self.assertEqual(result,expected)


if __name__ == "__main__":
    unittest.main()
