# TABAL Mail Desk — Etap I PoC

Lokalna aplikacja do testów na dwóch kontach `martin@`: TABAL/home.pl i Skyfens/iRedMail. Nie wymaga instalacji bibliotek Pythona. Python 3.10 lub nowszy.

## Uruchomienie

1. Rozpakuj ZIP. Na Windows kliknij `start_windows.bat`; na macOS/Linux uruchom `sh start_mac_linux.sh` w terminalu. Aplikacja działa pod adresem `http://127.0.0.1:8765` (wpisz go w przeglądarce).
2. Kliknij **Wczytaj przykłady**, wybierz wiadomość i **Analizuj demonstracyjnie**. Możesz przejrzeć i edytować szkic. Przykładowe wiadomości nie mogą zostać wysłane.
3. Aby włączyć AI i rzeczywiste konta testowe, skopiuj `.env.example` jako `.env.local` w folderze aplikacji. Uzupełnij klucz API oraz parametry od Darka. Zamknij i uruchom aplikację ponownie. Plik `.env.local` pozostaje lokalny i nie powinien trafiać do ZIP, repozytorium ani poczty.
4. Kliknij **Pobierz TABAL** lub **Pobierz Skyfens**. Aplikacja czyta ostatnie 50 wiadomości z INBOX (maksymalnie 2 MB każda) bez oznaczania ich jako przeczytane. Ponowne pobranie pomija już zapisane UID.
5. Wybierz mail i **Analizuj przez AI**. Sprawdź kategorię, streszczenie, proponowane działanie i szkic. Możesz poprawić odbiorcę i treść. Wysyłka wymaga zaznaczenia pola i dodatkowego potwierdzenia. Odpowiedź jest wysyłana przez SMTP tego samego konta, z którego pochodzi odebrana wiadomość.

## Konfiguracja

W `.env.example` są osobne ustawienia dla obu kont. SMTP obsługuje `starttls` i `ssl`; IMAP korzysta z SSL/TLS. Wartości hostów, portów, loginów i haseł muszą być potwierdzone przez Darka. Jeśli login martin@ ma inny adres niż w przykładzie, zmień go. Nie wpisuj haseł do interfejsu aplikacji.

Po udostępnieniu klucza API na swoim komputerze wpisz go do własnego `.env.local`; klucz utworzony w środowisku przygotowania PoC nie jest dołączony do pobieranego ZIP. Analiza AI wysyła do OpenAI nadawcę, temat, treść i nazwy załączników; pliki załączników nie są przekazywane. Użyty model można zmienić przez `OPENAI_MODEL`.

Podczas przygotowania PoC test połączenia z API zwrócił `credit_balance_exhausted` (HTTP 429). Aby przetestować analizę AI na żywo, konto projektu API musi mieć dostępny budżet. Do tego czasu możesz sprawdzić cały interfejs i przebieg na analizie demonstracyjnej.

## Granice PoC

- Dane i historia są zapisywane w `maildesk.sqlite3` w folderze aplikacji; nie udostępniaj tego pliku osobom postronnym. Serwer nasłuchuje tylko na `127.0.0.1`.
- Nie ma automatycznych odpowiedzi ani cyklicznej synchronizacji. Każda wysyłka wymaga ręcznej decyzji.
- Analiza obejmuje jedną wiadomość, nie rekonstruuje całych wątków, nie czyta załączników i nie weryfikuje faktów z systemami TABAL.
- Przycisk demonstracyjny wykorzystuje proste reguły i nie zastępuje AI. Szkice AI także należy sprawdzać.
- Na tym etapie aplikacja nie jest wieloużytkownikowa ani przygotowana do wystawienia do Internetu.

## Testy automatyczne

`python -m unittest discover -s tests -v`

Testy symulują IMAP, SMTP i odpowiedź API; nie łączą się z prawdziwą pocztą. Jeśli adres 8765 jest zajęty, uruchom `python maildesk.py --port 8766`.
