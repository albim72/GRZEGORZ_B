# Mail Desk 5.13 — TABAL i Skyfens

Lokalna aplikacja dla Grzegorza do pracy z wieloletnią pocztą firmową. Od wersji 5.7 najprostszy sposób na dużą skrzynkę wygląda tak: **Thunderbird pobiera pocztę, a Mail Desk ją przeszukuje.**

## Nowa poczta co 5 minut, czat i odpowiedzi (5.13)

### Dlaczego wcześniej nie było widać nowej poczty

Wersja 5.12 czytała pliki Thunderbirda tylko przy starcie. Jeśli program był otwarty od rana, nie widział niczego, co Thunderbird pobrał później. Do tego projekty miały stałą datę końcową, więc nowe maile do nich nie trafiały.

### Jak to działa teraz

- **Co 5 minut** Mail Desk sprawdza, co Thunderbird dopisał do swoich plików, i dodaje nowe maile do wyszukiwarki i projektów. Sprawdzenie bez zmian trwa ułamek sekundy. Bez Thunderbirda program pyta serwer IMAP.
- Częstotliwość zmienisz w panelu **Archiwum poczty → Sprawdzaj nową pocztę** (1–60 min albo wyłączone). Przycisk **Sprawdź teraz** jest na górze strony.
- **Projekty „na bieżąco”.** Archiwum poczty i nowe projekty kończące się dziś mają koniec zakresu przesuwany na dziś, więc nowe maile do nich trafiają. W projekcie przełączysz to przyciskiem **Nowe maile: dopisywane ✓**.
- **Strona odświeża się sama** i pokazuje „📬 Nowa poczta”. Gdy akurat coś piszesz, pojawia się tylko pasek **Odśwież widok**, żeby nie zgubić tekstu.
- **Najnowsza poczta** (nad wyszukiwarką): najnowsze maile z oznaczeniami *nowy*, *czeka* (bez odpowiedzi), *✓ odpowiedziano*, *szkic*. Filtr **tylko bez odpowiedzi** pokazuje maile z 14 dni, na które nie ma Twojej późniejszej wiadomości w tym samym wątku.

**Ważne w Thunderbirdzie:** Mail Desk widzi tylko to, co Thunderbird już pobrał, więc Thunderbird musi być otwarty. Ustaw w nim: prawy klik na konto → **Ustawienia** → **Ustawienia serwera** → **Sprawdzaj nowe wiadomości co 5 minut**. Synchronizacja offline z punktu „Archiwum z Thunderbirda” musi być włączona (zwykle jest). W podpowiedzi po najechaniu na „Nowa poczta co 5 min” widać, kiedy Thunderbird ostatnio zapisał pocztę.

### Czat z pocztą

- **Zapytaj AI o ten mail** (w mailu albo w Najnowszej poczcie) przypina mail do rozmowy. Asystent czyta przypięte maile przed odpowiedzią. Przypiąć można do 8 maili, a ✕ odpina.
- **Szybkie pytania**: „Co nowego od wczoraj?”, „Na co nie odpowiedziałem?”, „Podsumuj tydzień”, „Terminy i zobowiązania”.
- Asystent ma dwa nowe narzędzia: **maile bez odpowiedzi** i **zapisz szkic odpowiedzi**. Możesz napisać np. „przygotuj odpowiedź do Kowalskiego, że montaż od 15.11”. Szkic pojawi się jako karta **Otwórz, sprawdź i wyślij**. Asystent nigdy nic nie wysyła.
- Pod odpowiedzią są **Źródła** (data, nadawca, temat; klik otwiera mail) oraz przyciski **Kopiuj**, **Zapytaj ponownie** i **Użyj jako odpowiedź na mail…**. Po najechaniu na numer maila widać jego temat.
- **■ Zatrzymaj** przerywa pracę asystenta. Pytanie wraca wtedy do pola wpisywania.

### Odpowiedzi: szkic → zatwierdzenie → wysyłka

1. W mailu kliknij **↩ Odpowiedz**, **↩ Odpowiedz wszystkim** albo **✨ Przygotuj odpowiedź z AI**. W polu poleceń dla AI napisz, co ma się znaleźć w odpowiedzi, np. „podziękuj, montaż od 15.11, fundament nie jest w cenie”. Wybierz też ton, język (domyślnie taki jak język maila) i długość. AI czyta mail, cały wątek i załączniki. Nie wymyśla cen ani terminów: brakujące dane oznacza jako **[[do uzupełnienia]]**. Gotowy szkic możesz poprawić drugim poleceniem („krócej”, „po angielsku”).
2. Popraw **Do / DW / Temat / Treść**. Możesz dołączyć cytat oryginału i ustawić **podpis** dla każdej skrzynki, który dopisuje się automatycznie. **Zapisz szkic** zachowuje go na później. Wszystkie otwarte szkice widać po lewej, w sekcji **Odpowiedzi do wysłania**.
3. **Zatwierdź treść →** pokazuje mail dokładnie w takiej postaci, w jakiej wyjdzie. Program nie zatwierdzi odpowiedzi bez odbiorcy ani z niewypełnionym [[…]]. Adresy spoza wątku trzeba potwierdzić osobnym znaczkiem. Każda zmiana po zatwierdzeniu cofa odpowiedź do szkicu.
4. **✉ Wyślij teraz** (z dodatkowym potwierdzeniem). Mail wychodzi jako odpowiedź w tym samym wątku. Kopia trafia do folderu **Wysłane** na serwerze, więc Thunderbird też ją pokaże. Mail od razu pojawia się w archiwum, a rozmowa dostaje oznaczenie „✓ odpowiedziano”. Tej samej odpowiedzi nie da się wysłać drugi raz. Przy błędzie (np. złe hasło) program pokazuje, co się stało, i pozwala spróbować ponownie.

Do wysyłki potrzebny jest login i hasło skrzynki w **Konfiguracja kont i AI**, bo Thunderbird nie udostępnia hasła innym programom. Bez tego można przygotowywać i zatwierdzać szkice, ale nie wysyłać.

Ustawienia w `.env.local` (opcjonalne):
- `MAILDESK_REFRESH_MINUTES=5` to domyślna częstotliwość (ustawienie z panelu ma pierwszeństwo).
- `MAILDESK_OWN_ADDRESSES=gbartosik@tabal.pl,grzegorz.bartosik@skyfens.pl` to Twoje adresy. Służą do rozpoznawania „czeka / odpowiedziano”. Zwykle nie trzeba ich wpisywać: program bierze loginy skrzynek i nadawcę z folderu Wysłane.

## Szybkie wyszukiwanie i szybszy czat (5.11–5.12)

Przy dużym archiwum (setki tysięcy maili) wyszukiwanie w 5.10 przeglądało po kolei tekst każdego maila, a czat robi kilka wyszukiwań na jedno pytanie. Od 5.11 program ma **indeks wyszukiwania**, więc od razu wie, w których mailach może być szukany fragment. W 5.12 ten indeks jest zbudowany inaczej: jest ok. 16 razy mniejszy i buduje się 2,5 raza szybciej, a wyszukiwanie jest tak samo szybkie.

- **Wyniki są takie same jak w 5.10.** Indeks tylko pomija maile, które na pewno nie pasują. O trafieniu nadal decyduje dokładne porównanie, więc fragmenty słów, odmiana, pola `od:`/`temat:`, wykluczenia i frazy działają bez zmian. Sprawdzają to testy, w tym 300 losowych fragmentów porównanych z pełnym przeglądaniem.
- **Pomiar** (150 000 syntetycznych maili, maszyna testowa z 2 rdzeniami):

  | | 5.10 | 5.11 | 5.12 |
  |---|---|---|---|
  | numer zamówienia `ZAM-12345` | 1,61 s | 0,04 s | 0,04 s |
  | nazwisko z odmianą `Kowalskiego` | 1,39 s | 0,23 s | 0,21 s |
  | fragment adresu `leonardo@empresa` | 1,51 s | 0,08 s | 0,09 s |
  | fraza w cudzysłowie | 1,53 s | 0,36 s | 0,27 s |
  | `bauer \| ruiz` | 2,48 s | 0,09 s | 0,10 s |
  | słowo w prawie każdym mailu `oferta` | 0,76 s | 1,05 s | 0,84 s |
  | czat: liczenie maili od firmy | 1,15 s | 0,18 s | 0,19 s |
  | **rozmiar bazy** | 1,70 GB | 3,04 GB | **1,78 GB** |
  | budowa indeksu przy pierwszym starcie | – | 79 s | **29 s** |

- **Słowa, które są w większości maili** (np. „oferta”): program sam rozpoznaje, że indeks nic nie da, i przegląda maile jak 5.10.
- **Fragmenty krótsze niż 3 znaki** (np. `ab`) nie korzystają z indeksu. Takie wyszukiwanie działa jak w 5.10, czyli poprawnie, ale wolniej.
- **Pierwsze uruchomienie:**
  - z bazą z 5.10 program jednorazowo buduje indeks;
  - z bazą z 5.11 program wymienia duży indeks na mały i zwalnia miejsce na dysku (150 000 maili: ok. 70 s).

  Postęp widać w oknie Terminala. **Przed pierwszym uruchomieniem zrób kopię `maildesk.sqlite3`.**
- **Duże indeksowanie Thunderbirda** (np. pierwsze) buduje indeks raz, na końcu. W tym czasie wyszukiwanie działa bez indeksu i niczego nie blokuje. Małe, codzienne dopisywanie aktualizuje indeks na bieżąco.
- **Czat (5.12):**
  - gdy asystent zleca kilka wyszukiwań naraz, program wykonuje je równolegle;
  - podczas odpowiedzi na bieżąco widać, co asystent robi (szukam…, policzono…, przeczytano…) i jak długo pracuje.

  Najwięcej czasu zajmuje jednak sam model. Szybsze odpowiedzi daje staranność „niska” albo model Terra.
- Indeks można wyłączyć wpisem `MAILDESK_FTS=0` w `.env.local`. Gdy SQLite na komputerze nie obsługuje indeksu (wersje sprzed 3.34), program sam działa jak 5.10.

## Modele GPT-5.6 (5.10)

W „Konfiguracja kont i AI” → **Model do czatu i raportów** można wybrać:

| Model | Do czego | Cena (USD / 1 mln tokenów: wejście / wyjście) |
|---|---|---|
| **GPT-5.6 Sol** | najlepsza jakość: szerokie pytania, wnioskowanie, raporty | 4 / 20 |
| **GPT-5.6 Terra** | bardzo dobry, wyraźnie tańszy | 2 / 12 |
| GPT-4.1 | starszy, bez rozumowania | 2 / 8 |
| GPT-4.1 mini | najtańszy, do prostych pytań | 0,4 / 1,6 |

Ceny pochodzą z cennika OpenAI z października 2026. Ceny GPT-5.6 są promocyjne co najmniej do 21.11.2026. Ponowne wysłanie tej samej rozmowy (tzw. cache) kosztuje 10% ceny wejścia, a program to uwzględnia.

- **Staranność** (niska / średnia / wysoka) dotyczy modeli GPT-5.6. Wyższa staranność oznacza, że model dłużej „myśli”: odpowiedź jest dokładniejsza, ale drożej i wolniej. Zalecana jest średnia.
- Po zmianie modelu program od razu sprawdza, czy klucz ma do niego dostęp.
- **Analiza zbiorcza:** wyciągi z tysięcy maili robi tani model (`OPENAI_MODEL`, domyślnie GPT-4.1 mini), a streszczenia i raport model wybrany do czatu, np. Sol.
- Modele GPT-5.6 „rozumują” przed odpowiedzią. Program przekazuje to rozumowanie między kolejnymi wyszukiwaniami i daje mu odpowiednio większy limit długości. Bez tego takie modele gubiłyby wątek między krokami albo ucinały odpowiedzi.
- Koszt widać przy każdej odpowiedzi. Orientacyjnie z Sol przy średniej staranności: proste pytanie kosztuje kilka centów, a szerokie pytanie wymagające wielu wyszukiwań kilkadziesiąt centów.
- Ceny można zmienić w `.env.local`, np. `OPENAI_PRICE_GPT_5_6_SOL=4,0.4,20` (wejście, wejście z cache, wyjście).

## Czat z pocztą (5.9)

Zakładka **Rozmowa → „Zapytaj AI”** działa teraz jak normalny czat:

- **Pamięta rozmowę.** Można dopytywać: „rozwiń”, „a w 2023?”, „przetłumacz na angielski”, „zrób z tego tabelę”, „napisz z tego maila do klienta”. **Nowa rozmowa** zaczyna temat od zera.
- **Asystent sam przeszukuje pocztę**, kilka razy, jeśli trzeba. Ma do dyspozycji:
  - wyszukiwarkę (fragmenty nazw, odmiana, daty, pola `od:`/`do:`/`temat:`/`plik:`);
  - czytanie pełnych maili bez cytowanej historii, razem z tekstem załączników;
  - liczenie (ile maili, w których miesiącach, od kogo, z jakich firm);
  - wyciągi z Analizy zbiorczej, do pytań szerokich.
- **Przy każdym fakcie podaje numer maila** (klikalny). Numery maili, których asystent nie widział, są automatycznie usuwane. Gdy czegoś nie znajdzie, ma to powiedzieć wprost.
- **„Co sprawdził asystent”** pokazuje, czego szukał, co policzył i które maile przeczytał. Przy odpowiedzi widać też model i koszt.
- **Odpowiada w języku pytania** albo w tym, o który użytkownik poprosi.
- **Model do czatu** wybiera się w „Konfiguracja kont i AI”:
  - **GPT-4.1 mini** jest tani, dobry do prostych pytań;
  - **GPT-4.1** lepiej radzi sobie z pytaniami szerokimi i rzadziej się myli, ale kosztuje około 5× więcej;
  - można też wpisać inny model.

  Wyciągi w Analizie zbiorczej nadal robi tańszy model.

**Dla pytań bardzo szerokich**, obejmujących wiele lat i setki maili, najlepiej najpierw przygotować wyciągi: Analiza zbiorcza → „Tylko przygotuj wyciągi” dla danej firmy lub okresu. Wtedy czat korzysta z nich i widzi cały zakres, a nie tylko kilkadziesiąt przeczytanych maili.

## Analiza zbiorcza (5.8)

Zakładka **Analiza zbiorcza** (obok „Rozmowa” i „Wiadomość”) analizuje wiele maili naraz, także z wielu lat, i składa raport z odnośnikami do źródeł.

**Jak to działa:**
1. **Wyciągi.** Model czyta każdy mail **jeden raz** i robi z niego krótki wyciąg: streszczenie, kogo dotyczy, kwoty, terminy, ustalenia, problemy, zadania. Wcześniej program wycina cytowaną historię wątku i stopki, więc każdy fakt jest liczony raz i przypisany do maila, w którym się pojawił. Wyciągi zapisują się w bazie, więc kolejne analizy tych samych maili ich nie powtarzają.
2. **Streszczenia okresów.** Przy dużym zakresie wyciągi są streszczane chronologicznie, okres po okresie, pod kątem celu analizy.
3. **Raport.** Sekcje: podsumowanie, przebieg w czasie, tabela kluczowych liczb, problemy i ryzyka, otwarte sprawy. **Każde zdanie ma odnośnik do maili** (klikalne numery). Odnośniki do maili spoza wybranego zakresu są automatycznie usuwane.

**Użycie:**
1. Opcjonalnie wyszukaj zakres, np. `aliplast` z datami 2021–2025.
2. W zakładce wpisz cel, np. „Przebieg współpracy z Aliplast: ceny, terminy dostaw, reklamacje, otwarte sprawy”.
3. Wybierz zakres: wyniki wyszukiwania, cały projekt albo całe archiwum.
4. Kliknij **Oszacuj koszt**. Program pokaże liczbę maili, ile wyciągów już jest gotowych, szacowany koszt i czas.
5. Zaznacz zgodę na wysłanie tych maili do OpenAI i kliknij **Uruchom analizę**.

Raport można pobrać jako `.md`. **Tabela faktów (.csv)** zawiera wszystkie kwoty, terminy, ustalenia i problemy z wyciągów, z numerem maila; otwiera się w Excelu.

**„Tylko przygotuj wyciągi”** przetwarza np. całe archiwum jeden raz, najlepiej na noc. Potem każda analiza (różne firmy, tematy, okresy) kosztuje tylko złożenie raportu.

**Koszt i bezpieczeństwo:**
- **Limit kosztu** w USD zatrzymuje pracę po jego osiągnięciu. Program sprawdza go przed każdym zapytaniem.
- Zatrzymanie, limit albo błąd sieci nie kasuje gotowych wyciągów. Ponowne uruchomienie dokańcza pracę.
- Szacunek liczony jest wg cen w `.env.local`: `OPENAI_PRICE_IN` i `OPENAI_PRICE_OUT` (USD za 1 mln tokenów, domyślnie 0,40 / 1,60 dla gpt-4.1-mini). Sprawdź aktualny cennik OpenAI. Zapytania wysyłane są z wyłączonym zapisem po stronie OpenAI (`store: false`).
- Do OpenAI trafia treść wybranych maili (bez cytowanej historii) i odczytany tekst załączników, maksymalnie 3 na mail. Przy danych osobowych klientów sprawdź umowę powierzenia danych z OpenAI (RODO).

**Lepszy odczyt dokumentów (5.8):**
- **Excel** czytany jest jako wiersze z nazwą arkusza, np. „Panel 3D | 120”, więc ceny zostają przy swoich pozycjach.
- **Word** jest odczytywany poprawnie także wtedy, gdy dzieli wyrazy na fragmenty. Wcześniej słowo mogło zostać rozbite i nie dawało się go znaleźć. Dokumenty zindeksowane wcześniej odczytają się poprawnie po ponownym „Wczytaj do analizy” albo przy nowym indeksowaniu.

## Archiwum z Thunderbirda (5.7, zalecane przy dużej poczcie)

Thunderbird pobiera całą pocztę na komputer. Mail Desk **tylko czyta jego pliki**, niczego w nich nie zmienia. Buduje z nich szybki indeks wyszukiwania i otwiera załączniki prosto z plików Thunderbirda, więc nie ma drugiej kopii poczty na dysku. Hasło do skrzynki nie jest Mail Deskowi potrzebne do wyszukiwania, tylko do wysyłania odpowiedzi.

### 1. Thunderbird (raz)

1. Dodaj konto TABAL jako **IMAP** (nie POP3): serwer `tabal.home.pl`, port 993, SSL/TLS. Wychodząca: `tabal.home.pl`, port 465, SSL/TLS. Login to pełny adres e-mail.
2. Prawy klik na konto → **Ustawienia** → **Synchronizacja i miejsce na dysku**:
   - zaznacz **Przechowuj wiadomości z tego konta na tym komputerze**;
   - wybierz synchronizację **wszystkich** wiadomości, bez ograniczenia wieku. Do testów wystarczy np. ostatni miesiąc;
   - **odznacz „Nie pobieraj wiadomości większych niż…”**, inaczej duże maile przyjdą bez załączników. Mail Desk wykrywa takie maile i ostrzega;
   - **Zaawansowane…**: zaznacz wszystkie foldery.
3. **Plik → Pracuj offline → Pobierz/Synchronizuj teraz…** → Wiadomości. Przy dużej poczcie zostaw komputer na noc i wyłącz usypianie.

### 2. Mail Desk

- **W aplikacji:** panel **Archiwum poczty** → **Archiwum z Thunderbirda**. Profil jest wykrywany automatycznie (Mac, Windows, Linux); można też wkleić ścieżkę do folderu. Kliknij **Sprawdź konta i foldery**, przypisz konto do TABAL lub Skyfens (rozpoznaje je po nazwie serwera), potem **Indeksuj archiwum Thunderbirda**.
- **Bez przeglądarki:** Mac: `indeksuj_thunderbird.command`, dwuklik; za pierwszym razem prawy klik → Otwórz. Windows: `indeksuj_thunderbird.bat`. Można też podać ścieżkę: `python3 maildesk.py --thunderbird "/ścieżka/do/profilu"`.
- Potem otwórz projekt **Archiwum poczty (całość)**.

Gdzie jest profil Thunderbirda:
- **Mac:** `~/Library/Thunderbird/Profiles/xxxx.default-release`
- **Windows:** `%APPDATA%\Thunderbird\Profiles\xxxx.default-release`

W Thunderbirdzie znajdziesz go też w menu Pomoc → Więcej informacji dla rozwiązywania problemów → Folder profilu. Poczta jest w podfolderze `ImapMail/<serwer>`: pliki bez rozszerzenia to foldery poczty, a katalogi `.sbd` to podfoldery.

### Jak to działa na co dzień

- **Kolejne indeksowanie czyta tylko to, co Thunderbird dopisał.** Gdy nic się nie zmieniło, trwa ułamek sekundy. Przy starcie aplikacji dzieje się to samo w tle (można wyłączyć).
- **Maile usunięte w Thunderbirdzie są pomijane.** Mail Desk rozpoznaje je po znacznikach Thunderbirda.
- **Oznaczenie maila jako przeczytany nie tworzy duplikatów.**
- **„Kompaktowanie” folderów jest wykrywane.** Thunderbird przepisuje wtedy pliki, a Mail Desk sam poprawia położenie maili, także przy otwieraniu załącznika.
- Ostatni mail, który Thunderbird właśnie zapisuje, zostaje pominięty do następnego indeksowania.
- Indeksowanie korzysta ze wszystkich rdzeni procesora.
- **Pomijane foldery:** Kosz, Spam, Szkice, Szablony i Niewysłane. „Lokalne foldery” (np. archiwa ręcznie przenoszone przez Grzegorza) są dołączane dopiero po przypisaniu ich w panelu do skrzynki.
- Obsługiwany jest standardowy format Thunderbirda (mbox) i opcjonalny Maildir.

**Szybkość** (testowy profil na 2-rdzeniowej maszynie): 15 000 maili w 111 folderach (595 MB) zindeksowane w 62 s na jednym rdzeniu i 44 s na dwóch. Ponowne sprawdzenie bez zmian trwało 0,06 s. Wyszukiwanie w tym archiwum trwa ok. 0,1 s. Najdłużej trwa odczyt tekstu z PDF-ów i Exceli. Na Macu z wieloma rdzeniami będzie szybciej.

## Archiwum pobierane bezpośrednio z serwera (5.6, bez Thunderbirda)

**Pierwsze pobranie** (najlepiej wieczorem, na noc):

1. Uruchom aplikację (`start_windows.bat` albo `start_mac_linux.sh`) i w **Konfiguracja kont i AI** wpisz login i hasło skrzynek. Hasło zostaje tylko na tym komputerze.
2. Wybierz jeden ze sposobów:
   - **w aplikacji:** w panelu **Archiwum poczty** (po lewej) zostaw datę 2021-01-01 i kliknij **Pobierz archiwum**;
   - **bez otwierania przeglądarki:** zamknij aplikację i uruchom `pobierz_archiwum.bat` (Windows) albo `pobierz_archiwum.sh` (Mac). Postęp i szacowany czas do końca widać w oknie.
3. Program sprawdza wszystkie foldery obu skrzynek, najpierw liczy, ile jest do pobrania, a potem pobiera paczkami. W tym czasie nie pozwala komputerowi zasnąć (Windows i Mac).
4. Przerwanie (zamknięcie okna, **Zatrzymaj**, brak Internetu, zerwane połączenie) jest bezpieczne. Następne uruchomienie dokończy od miejsca przerwania, niczego nie pobierając drugi raz. Zerwane połączenie program sam wznawia do 5 razy.

**Potem:**
- W projekcie **Archiwum poczty (całość)** jest cała poczta: wyszukiwarka, Rozmowa i załączniki.
- Nowy projekt od razu wypełnia się mailami z archiwum, bez łączenia z serwerem. Przycisk **Odśwież z archiwum** robi to ponownie.
- Przy każdym starcie aplikacja w tle dociąga nowe maile. Bez Internetu po prostu pracuje na archiwum. Można to wyłączyć w panelu.

**Pełne kopie maili:** domyślnie każdy mail jest zapisywany w całości, z załącznikami, w folderze `archiwum_maili` obok bazy (skompresowane pliki `.eml.gz`). Dzięki temu załączniki otwierają się offline, a archiwum nie zależy od tego, co zostanie na serwerze. Zajmuje to mniej więcej tyle miejsca, ile skrzynka na serwerze. Po odznaczeniu tej opcji zapisywany jest tylko tekst (mała baza), a pliki są pobierane z serwera na żądanie. Kopie można też dopisać później do istniejącego archiwum. Program pobierze wtedy tylko brakujące kopie.

**Pomijane foldery:** Kosz, Spam i Szkice (Wersje robocze).

**Bezpieczeństwo:** baza i folder `archiwum_maili` zawierają całą korespondencję firmy. Włącz szyfrowanie dysku (BitLocker albo FileVault), rób kopię zapasową obu i nie wysyłaj ich mailem. AI dostaje tylko wybrane fragmenty i tylko po kliknięciu „Zapytaj AI” albo „Analizuj przez AI”. Ta funkcja jako jedyna wymaga Internetu.

**Ograniczenia:** skany PDF bez warstwy tekstowej (wymagające OCR) nie są przeszukiwane. Maile ponad 30 MB są pomijane i zapisywane w dzienniku błędów.

## Zmiany w 5.5 (wyszukiwanie i szybkość)

**Szybkość (zmierzone na testowej skrzynce, nie na serwerze home.pl):**

| | 5.4 | 5.5 |
|---|---|---|
| Wyszukiwanie w 20 000 maili | ok. 13 s | ok. 0,2 s |
| Lokalny zapis 20 000 maili | 653 s, coraz wolniej | 23 s, stałe tempo |
| Pobranie 2 000 maili (opóźnienie sieci 30 ms) | 77 s | 7,6 s |

- Maile są pobierane paczkami (do 40 naraz) zamiast pojedynczo, więc jest jedno odwołanie do serwera na paczkę.
- Rozmiar maili jest sprawdzany przed pobraniem, więc maile ponad 30 MB nie są niepotrzebnie ściągane.
- Kopia tego samego maila w innym folderze (np. Wysłane i Archiwum) jest zapamiętywana i nie jest pobierana przy każdej synchronizacji.
- Stary indeks, który przy każdym zapisie przeglądał całą bazę, został usunięty.

**Co teraz jest znajdowane, a wcześniej nie było:**
- Foldery ze spacją w nazwie (np. „Sent Items”, „Elementy wysłane”). Wcześniej serwer odrzucał ich otwarcie i cały folder był pomijany.
- Fraza w cudzysłowie przełamana w mailu do nowej linii.
- Odmiana: „Kowalski” znajduje też „Kowalskiego”, „Kowalskim”, „Kowalska”, a „ogrodzenie” także „ogrodzenia”. Można to wyłączyć.
- Pełna lista odbiorców (wcześniej pole „Do” było obcinane po 500 znakach).
- Maile, w których zwykły tekst był tylko zaślepką, a treść była w HTML.
- Daty: każdy mail ma teraz jedną, poprawną datę, więc działa filtr dat i sortowanie od najnowszych.

**Nowe w wyszukiwarce:** pola „Od daty / Do daty”, szybkie zakresy, szukanie w wybranym polu, wykluczanie, podświetlone fragmenty i informacja, gdzie znaleziono słowo (nadawca, temat, treść, załącznik).

**Rozmowa** rozumie daty w pytaniu: „Co pisał Kowalski w marcu 2024?”, „Ile maili od Bauera w zeszłym roku?”, „15.03.2024”, „od 2023 do 2024”, „w tym roku”, „ostatni miesiąc”.

### Pierwsze uruchomienie z bazą z 5.4 lub starszej

Przy pierwszym starcie 5.5 jednorazowo buduje nowy indeks i porządkuje bazę. Postęp widać w oknie Terminala. Dla 20 000 maili trwało to ok. 17 s. Na dysku potrzeba chwilowo tyle wolnego miejsca, ile zajmuje plik `maildesk.sqlite3`. **Przed pierwszym uruchomieniem zrób kopię pliku `maildesk.sqlite3`.**

## Uruchomienie

### macOS / Linux

1. Rozpakuj ZIP do osobnego folderu.
2. Otwórz Terminal, wpisz `sh ` ze spacją i przeciągnij do Terminala plik `start_mac_linux.sh`.
3. Naciśnij Enter. Przy pierwszym uruchomieniu przygotowanie środowiska może doinstalować `pypdf`.
4. Aplikacja powinna otworzyć `http://127.0.0.1:8765`. Terminal musi pozostać otwarty.
5. Zatrzymanie: `Ctrl+C`.

### Windows

Uruchom `start_windows.bat`. Aplikacja działa pod `http://127.0.0.1:8765`.

## Konfiguracja kont

W **Konfiguracja kont i AI** wpisz pełny login i hasło do skrzynki TABAL i/lub Skyfens. Następnie kliknij odpowiedni przycisk **Sprawdź IMAP**.

Dane logowania oraz klucz API są zapisywane lokalnie w `.env.local`. Tego pliku nie wysyłaj innym osobom i nie dołączaj do kolejnych ZIP-ów.

Do analizy AI potrzebny jest osobny klucz OpenAI API firmy. Bez klucza działa lokalne indeksowanie i wyszukiwanie.

## Wyszukiwanie

1. Utwórz projekt, ustaw daty i skrzynki. **Wstępny filtr projektu** możesz zostawić pusty.
2. Kliknij **Indeksuj / synchronizuj pocztę** i poczekaj na koniec pobierania.
3. W polu **Szukaj w pobranej poczcie** wpisz kryterium i ewentualnie zmień daty:

| Wpisz | Co znajdzie |
|---|---|
| `Kowalski oferta` | oba fragmenty w jednym mailu (imię, nazwisko, firma, adres, numer – dowolny fragment) |
| `"oferta na ogrodzenie"` | dokładną frazę |
| `Leonardo \| Bauer` | jedno albo drugie |
| `-faktura` | pomija maile zawierające „faktura” |
| `od:Kowalski` | tylko w nadawcy |
| `do:@firma.pl` | tylko w odbiorcach i DW |
| `temat:umowa` | tylko w temacie |
| `plik:cennik` | tylko w nazwach załączników |
| `data:2024-03` | tylko marzec 2024 (także `data:2024`, `data:15.03.2024`) |
| `od:2024-01-01 do:2024-06-30` | zakres dat wpisany w zapytaniu |
| puste pole + daty | wszystkie maile z okresu, od najnowszych |

Domyślnie daty wyszukiwania to daty projektu. Przycisk **Cała pobrana poczta** usuwa limit dat. Wtedy przeszukiwane są wszystkie maile tych skrzynek pobrane na komputer, także przez inne projekty.

Wielkość liter i polskie znaki nie mają znaczenia. Fragment słowa wystarczy: `bau` znajdzie `Bauer`. Program nie dopisuje synonimów ani tłumaczeń. Jeśli możliwe jest `Hiszpania`, `Spain` lub `España`, wpisz `Hiszpania | Spain | España`.

Program przeszukuje tylko maile już pobrane na ten komputer. Jeśli czegoś nie ma, sprawdź zakres dat albo zsynchronizuj projekt obejmujący dany okres.

## Szybkość home.pl i zakres wyników

Pierwsze pobranie wieloletniej skrzynki nadal zależy od serwera i łącza, bo trzeba przesłać wszystkie maile z załącznikami. Wersja 5.5 pobiera je paczkami, więc opóźnienie sieci liczy się raz na paczkę, a nie raz na każdy mail. Kolejne synchronizacje pobierają tylko nowe wiadomości. Maile ponad 30 MB są pomijane bez pobierania i zapisywane w dzienniku błędów.

## Załączniki

Przy pierwszym pobraniu nowej wiadomości program zapisuje metadane wszystkich załączników. Tekst jest automatycznie wydobywany z obsługiwanych typów:

- TXT, CSV, MD, JSON, XML, HTML,
- DOCX,
- XLSX,
- tekstowy PDF.

Nie są automatycznie odczytywane skany PDF wymagające OCR, obrazy, stare DOC/XLS i pliki zabezpieczone hasłem. Takie pliki pozostają widoczne w indeksie metadanych po nazwie.

Przycisk **Uzupełnij indeks załączników** służy głównie do starszych wiadomości już zapisanych przez wcześniejsze wersje aplikacji albo do ponowienia odczytu dokumentów.

Limity bezpieczeństwa pozostają: pełna wiadomość 30 MB, pojedynczy załącznik 15 MB.

## Aktualizacja z wcześniejszej wersji

Z 5.12 (i starszych): skopiuj do folderu 5.13 pliki `.env.local` i `maildesk.sqlite3` (najpierw zrób kopię bazy). Baza sama dostanie nowe pola (odpowiedzi, projekty „na bieżąco”).

Jeżeli używasz tych samych skrzynek Grzegorza, możesz skopiować do folderu 5.6:

- `.env.local`
- `maildesk.sqlite3`

Baza zostanie automatycznie rozszerzona o nowe pola i indeks (zob. „Pierwsze uruchomienie z bazą z 5.4”). Potem kliknij **Indeksuj / synchronizuj pocztę**. 5.5 dopobierze foldery, których 5.4 nie mogła otworzyć (np. „Sent Items”).

Jeżeli zmieniasz konto z testowego `martin@...` na właściwe konto Grzegorza, zacznij w czystym folderze i nie kopiuj starej bazy.

## Bezpieczeństwo i wysyłka

- Aplikacja nasłuchuje wyłącznie lokalnie na `127.0.0.1`.
- Wiadomości oraz indeks są przechowywane lokalnie w `maildesk.sqlite3`.
- Treść trafia do OpenAI API dopiero po wybraniu trybu **Zapytaj AI** lub **Analizuj przez AI**.
- AI otrzymuje wybrane trafne źródła, nie całą skrzynkę.
- Wysyłka SMTP wymaga zatwierdzenia dokładnej treści i odbiorców oraz osobnego potwierdzenia „Wyślij teraz”. Asystent AI może tylko przygotować szkic.

## Testy

Uruchom:

```bash
python3 -m unittest discover -s tests -v
```

Paczka 5.13 przechodzi 74 testy (66 z 5.12, w tym jeden zaktualizowany o nowe narzędzia czatu, i 8 nowych). Nowe testy 5.13 obejmują:
- nowy mail dopisany przez Thunderbirda trafia po sprawdzeniu do projektów „na bieżąco” i do Najnowszej poczty, a nie trafia do projektów z zamkniętym zakresem;
- harmonogram co N minut, zmianę częstotliwości i brak kolizji z innym pobieraniem;
- maile bez odpowiedzi (wątki, własne adresy, pomijanie newsletterów);
- szkic → zatwierdzenie → wysyłkę: blokady ([[…]], adresy spoza wątku, zmiana po zatwierdzeniu, podwójna wysyłka), nagłówki wątku, cytat, DW, kopię w Wysłanych;
- błąd SMTP i ponowną próbę;
- szkic z AI (wątek, ton, podpis, poprawianie szkicu) i szkic z czatu z przypiętym mailem, a także Stop;
- nowe adresy HTTP aplikacji.

Nie testowano na prawdziwym profilu Thunderbirda Grzegorza, z serwerem SMTP home.pl ani z prawdziwym API OpenAI.

Testy z 5.12 obejmują:
- 300 losowych fragmentów (polskie znaki, cudzysłowy, ukośniki, procenty, adresy) z wynikami identycznymi jak przy pełnym przeglądaniu;
- wymianę indeksu z 5.11 na mały ze zwolnieniem miejsca;
- brak przebudowy indeksu w trakcie importu;
- równoległe narzędzia czatu i podgląd pracy asystenta na żywo.

Nie testowano na prawdziwym profilu Thunderbirda Grzegorza ani z prawdziwym API OpenAI.

Testy z 5.10 dotyczą modeli GPT-5.6:
- odsyłanie rozumowania razem z wynikami narzędzi;
- staranność i limit długości;
- koszt z uwzględnieniem cache;
- tani model do wyciągów i mocny do raportu;
- test dostępu do modelu;
- obsługa uciętej odpowiedzi.

Nie testowano z prawdziwym API OpenAI.
