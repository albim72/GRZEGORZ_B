import io
import imaplib
import json
import os
import re
import socket
import sys
import tempfile
import time
import unittest
import urllib.error
import zipfile
from datetime import datetime, timezone
from email.message import EmailMessage
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import maildesk as app


class FakeIMAP:
    fetch_calls = 0
    header_calls = 0
    def __init__(self, host, port):
        self.host, self.port = host, port
    def login(self, user, password):
        assert user == "martin@tabal.pl"
    def select(self, mailbox, readonly=False):
        assert readonly is True
        return "OK", [b"1"]
    def uid(self, action, *args):
        if action == "search":
            return "OK", [b"101"]
        assert args[-1] in ("(BODY.PEEK[])", "(BODY.PEEK[] INTERNALDATE)", "(BODY.PEEK[HEADER] INTERNALDATE)")
        if args[-1] in ("(BODY.PEEK[])", "(BODY.PEEK[] INTERNALDATE)"):
            FakeIMAP.fetch_calls += 1
        else:
            FakeIMAP.header_calls += 1
        msg = EmailMessage()
        msg["From"] = "Klient <klient@example.org>"
        msg["To"] = "martin@tabal.pl"
        msg["Subject"] = "Oferta tablic"
        msg["Message-ID"] = "<mail-101@example.org>"
        msg["Date"] = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
        msg.set_content("Proszę o ofertę do piątku")
        return "OK", [(b"1 (BODY[] {100}", msg.as_bytes())]
    def logout(self):
        pass


class FakeSMTP:
    sent = []
    def __init__(self, host, port, timeout):
        assert (host,port) == ("smtp.example.org",587)
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def starttls(self,context): pass
    def login(self,user,password):
        assert user == "martin@tabal.pl"
    def send_message(self,msg):
        self.sent.append(msg)


class FakeResponse:
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def read(self,*args): return self.blob


class MailDeskTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ,{
            "TABAL_LOGIN":"martin@tabal.pl","TABAL_PASSWORD":"fake-test-password",
            "TABAL_IMAP_HOST":"imap.example.org","TABAL_SMTP_HOST":"smtp.example.org",
            "TABAL_SMTP_PORT":"587","TABAL_SMTP_SECURITY":"starttls",
            "OPENAI_API_KEY":"fake-test-key"})
        self.env.start()
        FakeIMAP.fetch_calls = 0
        FakeIMAP.header_calls = 0
        FakeSMTP.sent = []
        app.JOBS.clear()
        app.DOCUMENT_JOBS.clear()
    def tearDown(self):
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()

    def test_full_flow_and_no_duplicate_send(self):
        first = app.sync_account("tabal", FakeIMAP)
        second = app.sync_account("tabal", FakeIMAP)
        self.assertEqual(first["imported"],1)
        self.assertEqual(second["skipped"],1)
        self.assertEqual(FakeIMAP.fetch_calls,1)
        self.assertEqual(FakeIMAP.header_calls,0)
        with app.connect() as db:
            row = db.execute("SELECT * FROM messages").fetchone()
            message_id = row["id"]
        app.analyze(message_id,"demo")
        with self.assertRaises(ValueError):
            app.send_mail(message_id,"klient@example.org","Treść",False,FakeSMTP)
        result = app.send_mail(message_id,"klient@example.org","Odpowiedź testowa",True,FakeSMTP)
        self.assertEqual(result["from"],"martin@tabal.pl")
        self.assertEqual(len(FakeSMTP.sent),1)
        self.assertEqual(FakeSMTP.sent[0]["In-Reply-To"],"<mail-101@example.org>")
        with self.assertRaises(ValueError):
            app.send_mail(message_id,"klient@example.org","Ponownie",True,FakeSMTP)

    def test_demo_messages_cannot_send(self):
        app.demo_seed()
        with app.connect() as db:
            row = db.execute("SELECT id FROM messages LIMIT 1").fetchone()
        app.analyze(row["id"],"demo")
        with self.assertRaisesRegex(ValueError,"Przykładowe"):
            app.send_mail(row["id"],"klient@example.org","Szkic",True,FakeSMTP)
        self.assertFalse(FakeSMTP.sent)

    def test_api_analysis_structured_response_and_untrusted_email(self):
        app.sync_account("tabal",FakeIMAP)
        with app.connect() as db:
            row = dict(db.execute("SELECT * FROM messages").fetchone())
        expected = {"category":"Zapytanie","priority":"wysoki","summary":"Prośba o ofertę",
                    "action":"Przygotować ofertę","due":"piątek","draft":"Dzień dobry..."}
        output = {"output":[{"content":[{"type":"output_text","text":json.dumps(expected)}]}]}
        def fake_open(request,timeout):
            self.assertEqual(request.full_url,"https://api.openai.com/v1/responses")
            body = json.loads(request.data)
            self.assertFalse(body["store"])
            self.assertEqual(body["text"]["format"]["type"],"json_schema")
            response = FakeResponse()
            response.blob = json.dumps(output).encode()
            return response
        result = app.ai_analysis(row, fake_open)
        self.assertEqual(result,expected)

    def test_project_date_company_sync_and_question_history(self):
        today = app.date.today().isoformat()
        project = app.create_project("Klient Example",today,today,"example.org","tabal")
        result = app.sync_project_account(project["id"],"tabal",FakeIMAP)
        self.assertEqual((result["checked"],result["added"]),(1,1))
        self.assertEqual(app.sync_project_account(project["id"],"tabal",FakeIMAP)["added"],0)
        answer = app.ask_project(project["id"],"Jaka oferta i termin?","local")
        self.assertIn("Oferta tablic",answer["answer"])
        self.assertEqual(len(answer["sources"]),1)
        saved = app.project_data(project["id"])
        self.assertEqual(saved["history"][0]["question"],"Jaka oferta i termin?")
        self.assertEqual(saved["messages"][0]["account"],"tabal")
        self.assertTrue(app.sender_matches("Firma ABC <zakupy@abc.pl>","ABC"))
        self.assertFalse(app.sender_matches("Firma ABC <zakupy@abc.pl>","Inna"))

    def test_date_filter_and_error_log_redacts_password(self):
        old = (app.date.today()-app.timedelta(days=3)).isoformat()
        project = app.create_project("Stary projekt",old,old,"","tabal")
        result = app.sync_project_account(project["id"],"tabal",FakeIMAP)
        self.assertEqual(result["added"],0)  # server mocked; header date still checked locally
        class BrokenIMAP(FakeIMAP):
            def login(self,user,password):
                raise imaplib.IMAP4.error("LOGIN failed: " + password)
        with self.assertRaises(imaplib.IMAP4.error):
            app.sync_project_account(project["id"],"tabal",BrokenIMAP)
        with app.connect() as db:
            detail = db.execute("SELECT detail FROM mail_errors ORDER BY id DESC LIMIT 1").fetchone()[0]
        self.assertIn("[REDACTED]",detail)
        self.assertNotIn("fake-test-password",detail)
        self.assertIn("odrzucił login lub hasło",app.sync_error_message(
            imaplib.IMAP4.error("[AUTHENTICATIONFAILED] Authentication failed.")))
        self.assertNotIn("fake-test-password",app.sync_error_message(
            RuntimeError("server error: fake-test-password")))

    def test_demo_project_and_both_mail_smtp_config(self):
        today=app.date.today().isoformat()
        project=app.create_project("Pokaz",today,today,"","both")
        self.assertEqual(app.add_demo_to_project(project["id"])["added"],3)
        self.assertEqual(len(app.project_data(project["id"])["messages"]),3)
        with patch.dict(os.environ,{"TABAL_SMTP_PORT":"465","TABAL_SMTP_SECURITY":"ssl"}):
            cfg=app.env_account("tabal")
            self.assertEqual((cfg["smtp_port"],cfg["smtp_security"]),(465,"ssl"))
        sky=app.env_account("skyfens")
        self.assertEqual((sky["imap_host"],sky["smtp_port"],sky["smtp_security"]),
                         ("mail.skyfens.pl",587,"starttls"))

    def test_imap_connection_check_separates_network_and_login(self):
        class GoodIMAP:
            def __init__(self,host,port,timeout):
                self.assertion = (host,port,timeout)
            def login(self,user,password):
                self.user = user
            def logout(self): pass
        good=app.check_imap_account("tabal",GoodIMAP)
        self.assertTrue(good["ok"])
        self.assertEqual(good["stage"],"login")
        class RejectedIMAP(GoodIMAP):
            def login(self,user,password):
                raise imaplib.IMAP4.error("[AUTHENTICATIONFAILED] " + password)
        rejected=app.check_imap_account("tabal",RejectedIMAP)
        self.assertEqual(rejected["stage"],"login")
        self.assertNotIn("fake-test-password",rejected["message"])
        def no_dns(host,port,timeout):
            raise socket.gaierror(-3,"temporary DNS error")
        network=app.check_imap_account("tabal",no_dns)
        self.assertEqual(network["stage"],"connection")
        self.assertIn("DNS",network["message"])
        with app.connect() as db:
            detail=db.execute("SELECT detail FROM mail_errors WHERE operation='IMAP login test'").fetchone()[0]
        self.assertNotIn("fake-test-password",detail)

    def test_ai_check_separates_invalid_key_and_billing(self):
        def error_response(http_status, error_code):
            blob=io.BytesIO(json.dumps({"error":{"code":error_code}}).encode())
            return urllib.error.HTTPError("https://api.openai.com/v1/responses",http_status,"failure",{},blob)
        def invalid(request,timeout):
            self.assertEqual(json.loads(request.data)["model"],"gpt-4.1-mini")
            raise error_response(401,"invalid_api_key")
        failed=app.check_ai(invalid)
        self.assertEqual(failed["stage"],"key")
        self.assertIn("HTTP 401",failed["message"])
        def no_credit(request,timeout):
            raise error_response(429,"credit_balance_exhausted")
        billing=app.check_ai(no_credit)
        self.assertEqual(billing["stage"],"billing")
        self.assertIn("HTTP 429",billing["message"])
        def success(request,timeout):
            response=FakeResponse()
            response.blob=json.dumps({"status":"completed","model":"gpt-4.1-mini",
                "output":[{"content":[{"type":"output_text","text":"OK"}]}]}).encode()
            return response
        self.assertTrue(app.check_ai(success)["ok"])

    def test_project_ai_answer_uses_only_eligible_sources(self):
        today=app.date.today().isoformat()
        project=app.create_project("Źródła",today,today,"","tabal")
        app.sync_project_account(project["id"],"tabal",FakeIMAP)
        m=app.project_data(project["id"])["messages"][0]
        output={"output":[{"content":[{"type":"output_text","text":json.dumps({
            "answer":"Termin to piątek.","source_ids":[m["id"],999999]})}]}]}
        def fake_open(request,timeout):
            body=json.loads(request.data)
            self.assertFalse(body["store"])
            self.assertIn(str(m["id"]),body["input"])
            response=FakeResponse()
            response.blob=json.dumps(output).encode()
            return response
        answer, ids=app.answer_with_ai("Jaki termin?",[m],fake_open)
        self.assertIn("piątek",answer)
        self.assertEqual(ids,[m["id"]])

    def test_setup_saves_company_credentials_and_api_key_locally(self):
        with patch.object(app,"ROOT",Path(self.temp.name)):
            with self.assertRaisesRegex(ValueError,"@tabal.pl"):
                app.save_account_settings("tabal","someone@gmail.com","secret")
            result=app.save_account_settings("tabal","gbartosik@tabal.pl","test=secret")
            self.assertEqual(result,{"saved":True,"account":"tabal"})
            app.save_account_settings("tabal","gbartosik@tabal.pl","")
            api_key="sk-proj-"+"x"*40
            self.assertEqual(app.save_ai_settings(api_key)["model"],"gpt-4.1-mini")
            cfg=Path(self.temp.name)/".env.local"
            contents=cfg.read_text()
            self.assertEqual(contents.count("TABAL_PASSWORD="),1)
            self.assertIn("TABAL_PASSWORD=test=secret",contents)
            self.assertIn("OPENAI_API_KEY="+api_key,contents)
            self.assertEqual(cfg.stat().st_mode & 0o777,0o600)
            self.assertNotIn("test=secret",app.redact_secrets("failed test=secret"))
            self.assertNotIn(api_key,app.redact_secrets("failed "+api_key))
            self.assertEqual(set(app.ACCOUNTS),{"tabal","skyfens"})

    def test_switching_mailbox_login_cannot_mix_cached_messages(self):
        app.sync_account("tabal",FakeIMAP)
        with self.assertRaisesRegex(ValueError,"osobnym folderze"):
            app.save_account_settings("tabal","gbartosik@tabal.pl","different-password")
        self.assertEqual(app.env_account("tabal")["login"],"martin@tabal.pl")

    def test_many_years_partial_sender_failed_uid_and_full_project_search(self):
        class ManyIMAP:
            full_fetches = 0
            def __init__(self,host,port): pass
            def login(self,user,password): pass
            def select(self,name,readonly=False): return "OK",[b"300"]
            def uid(self, action, *args):
                if action == "search": return "OK",[b" ".join(str(i).encode() for i in range(1,301))]
                uid=int(args[0]); spec=args[1]
                if uid == 137 and spec == "(BODY.PEEK[] INTERNALDATE)": return "NO",[]
                msg=EmailMessage()
                msg["From"]=("Peter Bauer" if uid<=260 else "Inny Klient")+" <pb@example.org>"
                msg["To"]="martin@tabal.pl"
                msg["Subject"]="kontrakt archeologiczny" if uid==1 else "Oferta nr "+str(uid)
                msg["Date"]="Mon, 01 Oct 2012 10:00:00 +0000"
                msg.set_content("Szczegóły współpracy " + str(uid))
                if spec=="(BODY.PEEK[] INTERNALDATE)": ManyIMAP.full_fetches+=1
                return "OK",[(b'1 (INTERNALDATE "01-Oct-2012 10:00:00 +0000")',msg.as_bytes())]
            def logout(self): pass
        project=app.create_project("Wiele lat","2012-01-01",app.date.today().isoformat(),"baue","tabal")
        result=app.sync_project_account(project["id"],"tabal",ManyIMAP)
        self.assertEqual((result["available"],result["checked"],result["added"],result["failed"]),(300,300,259,1))
        # 5.2 deliberately indexes every message in the selected date range once,
        # even if the project filter does not match, so later people/company
        # searches can reuse the local archive without another full download.
        self.assertEqual(ManyIMAP.full_fetches,299)
        first=app.project_data(project["id"])
        self.assertEqual((first["total_messages"],len(first["messages"])),(259,50))
        self.assertEqual(len(app.project_data(project["id"],200)["messages"]),50)
        answer=app.ask_project(project["id"],"kontrakt archeologiczny","local")
        self.assertIn("kontrakt archeologiczny",answer["answer"])
        with app.connect() as db:
            errors=db.execute("SELECT operation FROM mail_errors").fetchall()
        self.assertTrue(any("137" in x[0] for x in errors))
        self.assertTrue(app.sender_matches("Piotr Łęcki <sprzedaz@tabal.pl>","lecki"))
        self.assertTrue(app.sender_matches("Peter Bauer <pb@example.org>","pb@exa"))

    def test_all_folders_cc_company_attachment_index_and_hidden_message_list(self):
        today=datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
        class FolderIMAP:
            def __init__(self,host,port): self.folder="INBOX"
            def login(self,user,password): pass
            def list(self):
                return "OK",[b'(\\HasNoChildren) "/" "INBOX"',
                             b'(\\Sent \\HasNoChildren) "/" "Sent"',
                             b'(\\Trash \\HasNoChildren) "/" "Trash"']
            def select(self,name,readonly=False): self.folder=name; return "OK",[b"1"]
            def uid(self,action,*args):
                if action=="search": return "OK",[b"11" if self.folder=="INBOX" else b"22"]
                uid=int(args[0]); spec=args[1]
                msg=EmailMessage()
                if self.folder=="INBOX":
                    msg["From"]="Losowy <x@example.org>"; msg["To"]="martin@tabal.pl"
                    msg["Subject"]="Inny temat"; msg.set_content("Bez związku")
                else:
                    msg["From"]="martin@tabal.pl"
                    msg["To"]="Agnieszka Kafel <agnieszka.kafel@comarch.pl>"
                    msg["Cc"]="Biuro COMARCH <biuro@comarch.pl>"
                    msg["Subject"]="Oferta analityczna"
                    msg.set_content("Ustalenia dotyczące szkolenia")
                    msg.add_attachment(b"sekretny kod: ALFA-2042",maintype="text",subtype="plain",filename="ustalenia.txt")
                msg["Message-ID"]=f"<{self.folder}-{uid}@example.org>"; msg["Date"]=today
                meta=f'1 (INTERNALDATE "{datetime.now(timezone.utc).strftime("%d-%b-%Y %H:%M:%S +0000")}")'.encode()
                return "OK",[(meta,msg.as_bytes())]
            def logout(self): pass
        project=app.create_project("COMARCH",app.date.today().isoformat(),app.date.today().isoformat(),"comarch","tabal")
        result=app.sync_project_account(project["id"],"tabal",FolderIMAP)
        self.assertEqual(result["imported"],2)
        self.assertEqual(result["added"],1)
        self.assertEqual([x["folder"] for x in result["folders"]],["INBOX","Sent"])
        compact=app.project_data(project["id"],include_messages=False)
        self.assertEqual(compact["messages"],[])
        self.assertEqual(compact["total_messages"],1)
        self.assertEqual(compact["stats"]["attachments"],1)
        self.assertEqual(compact["stats"]["indexed_attachments"],1)
        answer=app.ask_project(project["id"],"sekretny kod ALFA-2042","local")
        self.assertTrue(answer["sources"])
        with app.connect() as db:
            entities=[r[0] for r in db.execute("SELECT normalized FROM message_entities WHERE normalized LIKE '%comarch%'")]
        self.assertTrue(entities)

    def test_universal_archive_search_across_initial_project_filter(self):
        today=app.date.today().isoformat()
        project=app.create_project("Leonardo",today,today,"Leonardo","tabal")
        self.assertTrue(app.project_query_matches({
            "sender":"Leonardo Ruiz <leonardo@empresa.es>", "recipient":"", "cc":"",
            "subject":"Oferta", "body":"Buenos días", "attachments":"[]"},"leonardo@empresa | BAUER"))
        with app.connect() as db:
            message={"message_id":"<leo@empresa.es>","sender":"Leonardo Ruiz <leo@empresa.es>",
                     "recipient":"martin@tabal.pl","cc":"","subject":"Oferta projektowa",
                     "received":today,"body":"Propuesta de proyecto", "attachments":"[]"}
            mid,_=app.save_message(db,"tabal","leo-test","INBOX",message)
            db.execute("INSERT INTO project_messages(project_id,message_id) VALUES (?,?)",(project["id"],mid))
            other=dict(message,message_id="<bauer@example.org>",sender="Peter Bauer <pb@example.org>",
                       subject="Raport techniczny",body="Ustalenia i wycena",attachments='["ceny.xlsx"]')
            other_id,_=app.save_message(db,"tabal","bauer-test","INBOX",other)
            app.index_attachment_record(db,other_id,0,"ceny.xlsx","Koszt montażu ogrodzenia", "text/plain",30)
            outside=dict(other,message_id="<outside@example.org>",received="2010-01-01",sender="Anna <anna@example.org>")
            app.save_message(db,"tabal","outside-test","INBOX",outside)
        self.assertEqual(app.search_archive(project["id"],"leo@empresa")["total"],1)
        self.assertEqual(app.search_archive(project["id"],'"oferta projektowa"')["messages"][0]["id"],mid)
        self.assertEqual(app.search_archive(project["id"],"bau")["messages"][0]["id"],other_id)
        self.assertEqual(app.search_archive(project["id"],"Leonardo | Bauer")["total"],2)
        self.assertEqual(app.search_archive(project["id"],"Leonardo Bauer")["total"],0)
        self.assertEqual(app.search_archive(project["id"],"montażu ogrodz")["messages"][0]["id"],other_id)
        self.assertEqual(app.search_archive(project["id"],"anna")["total"],0)
        with self.assertRaises(ValueError): app.search_archive(project["id"],'"niedomknięta')
        with self.assertRaises(ValueError): app.search_archive(project["id"],"A |")

    def test_archive_search_post_endpoint_and_pagination(self):
        today=app.date.today().isoformat()
        project=app.create_project("Archiwum",today,today,"Inny filtr","tabal")
        with app.connect() as db:
            for i in range(56):
                m={"message_id":f"<m{i}@example.org>","sender":"Klient <klient@example.org>",
                   "recipient":"martin@tabal.pl","cc":"","subject":f"Projekt {i}",
                   "received":today,"body":"Kod ALFA-2042", "attachments":"[]"}
                app.save_message(db,"tabal",str(800+i),"INBOX",m)
        first=app.search_archive(project["id"],"alfa-2042")
        self.assertEqual((first["total"],len(first["messages"])),(56,50))
        self.assertEqual(len(app.search_archive(project["id"],"alfa-2042",50)["messages"]),6)
        payload=json.dumps({"id":project["id"],"query":"@example.org | ALFA-2042","offset":50}).encode()
        handler=app.Handler.__new__(app.Handler)
        handler.headers={"Host":"127.0.0.1:8765","Content-Length":str(len(payload))}
        handler.path="/api/project/search"
        handler.rfile=io.BytesIO(payload)
        replies=[]
        handler.json_response=lambda status,data: replies.append((status,data))
        handler.do_POST()
        self.assertEqual(replies[0][0],200)
        result=replies[0][1]
        self.assertEqual((result["total"],len(result["messages"])),(56,6))

    def test_folder_parser_excludes_trash_junk_and_drafts(self):
        class Listing:
            def list(self): return "OK",[
                b'(\\HasNoChildren) "/" "INBOX"', b'(\\Sent) "/" "Sent Items"',
                b'(\\Trash) "/" "Trash"', b'(\\Junk) "/" "Junk"', b'(\\Drafts) "/" "Drafts"']
        self.assertEqual(app.list_mail_folders(Listing()),["INBOX","Sent Items"])

    def test_attachment_read_index_and_download_source(self):
        doc=io.BytesIO()
        with zipfile.ZipFile(doc,"w") as archive:
            archive.writestr("word/document.xml",'<w:document xmlns:w="x"><w:body><w:p><w:r><w:t>Termin targów 2030</w:t></w:r></w:p></w:body></w:document>')
        msg=EmailMessage()
        msg["From"]="Klient <klient@example.org>"
        msg["To"]="martin@tabal.pl"
        msg["Subject"]="Oferta"
        msg.set_content("Treść główna")
        msg.add_attachment(doc.getvalue(),maintype="application",subtype="vnd.openxmlformats-officedocument.wordprocessingml.document",filename="oferta.docx")
        raw=msg.as_bytes()
        class AttachedIMAP:
            def __init__(self,host,port): pass
            def login(self,user,password): pass
            def select(self,name,readonly=False): return "OK",[b"1"]
            def uid(self,action,*args):
                if action=="search": return "OK",[b"501"]
                return "OK",[(b"data",raw)]
            def logout(self): pass
        project=app.create_project("Załączniki",app.date.today().isoformat(),app.date.today().isoformat(),"klient","tabal")
        app.sync_project_account(project["id"],"tabal",AttachedIMAP)
        m=app.project_data(project["id"])["messages"][0]
        self.assertEqual(m["attachments"],["oferta.docx"])
        name,mime,blob=app.attachment_bytes(m["id"],0,AttachedIMAP)
        self.assertEqual((name,blob),("oferta.docx",doc.getvalue()))
        extracted=app.index_attachment(m["id"],0,AttachedIMAP)
        self.assertIn("Termin targów",extracted["text"])
        self.assertIn("Termin targów",app.attachment_text(m["id"],0)["text"])
        answer=app.ask_project(project["id"],"targów 2030","local")
        self.assertIn("targów",answer["answer"])

    def test_xlsx_shared_strings_and_pdf_text(self):
        sheet=io.BytesIO()
        with zipfile.ZipFile(sheet,"w") as archive:
            archive.writestr("xl/sharedStrings.xml",'<sst xmlns="x"><si><t>Grzegorz oferta</t></si></sst>')
            archive.writestr("xl/worksheets/sheet1.xml",'<worksheet xmlns="x"><sheetData><row><c t="s"><v>0</v></c><c><v>2027</v></c></row></sheetData></worksheet>')
        self.assertIn("Grzegorz oferta",app.extract_document("ceny.xlsx","application/octet-stream",sheet.getvalue()))
        try:
            from reportlab.pdfgen import canvas
            import pypdf
        except ImportError:
            return  # PDF dependency is installed by the launch script; XLSX still tested.
        pdf=io.BytesIO()
        c=canvas.Canvas(pdf)
        c.drawString(50,750,"Termin umowy 2027")
        c.save()
        self.assertIn("Termin umowy 2027",app.extract_document("umowa.pdf","application/pdf",pdf.getvalue()))

    def test_bulk_document_index_is_explicit_and_reports_progress(self):
        today=app.date.today().isoformat()
        project=app.create_project("Z dokumentami",today,today,"","tabal")
        with app.connect() as db:
            cur=db.execute("""INSERT INTO messages(account,uid,message_id,sender,recipient,subject,received,body,attachments)
                VALUES (?,?,?,?,?,?,?,?,?)""",("tabal","600","<600>","A <a@example.org>","martin@tabal.pl","Test",today,"Opis",'["plik.txt"]'))
            message_id=cur.lastrowid
            db.execute("INSERT INTO project_messages(project_id,message_id) VALUES (?,?)",(project["id"],message_id))
        with patch.object(app,"index_attachment",return_value={"indexed":True}) as mocked:
            app.start_document_index(project["id"])
            for _ in range(100):
                if not app.DOCUMENT_JOBS[project["id"]]["running"]: break
                time.sleep(.01)
            job=app.DOCUMENT_JOBS[project["id"]]
            self.assertFalse(job["running"])
            self.assertEqual((job["checked"],job["indexed"],job["total"]),(1,1,1))
            mocked.assert_called_once_with(message_id,0)


class SearchEngine55Tests(unittest.TestCase):
    """Mail Desk 5.5: fast SQL search, dates, fields, inflection, batch IMAP."""
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ,{"TABAL_LOGIN":"martin@tabal.pl","TABAL_PASSWORD":"fake-test-password",
                                          "TABAL_IMAP_HOST":"imap.example.org"})
        self.env.start()
        self.project = app.create_project("Szukanie","2023-01-01",app.date.today().isoformat(),"","tabal")
        self.ids = {}
        mails = [
            ("kow", "Jan Kowalski <jan@budimex.pl>", "Oferta na ogrodzenie", "2024-03-05T10:00:00+01:00",
             "Dzień dobry,\nprzesyłam ofertę na\nogrodzenie panelowe dla Pana Nowakowskiego.", "[]"),
            ("dat", "Biuro <biuro@stal.pl>", "Potwierdzenie", "Mon, 15 Jan 2024 09:00:00 +0100",
             "W imieniu Kowalskiego potwierdzam termin montażu w Łodzi.", "[]"),
            ("bau", "Peter Bauer <pb@bauer-zaun.de>", "Faktura 12/2024", "2024-06-20T08:00:00+02:00",
             "Rechnung im Anhang. Faktura do zapłaty.", '["cennik_2024.xlsx"]'),
            ("old", "Anna Zielińska <anna@zielinska.pl>", "Stara sprawa", "2023-02-01T08:00:00+01:00",
             "Spotkanie w sprawie bramy.", "[]"),
        ]
        with app.connect() as db:
            for key, sender, subject, received, body, files in mails:
                m = {"message_id":f"<{key}@t>","sender":sender,"recipient":"Grzegorz <gbartosik@tabal.pl>",
                     "cc":"Kierownik Budowy <kb@comarch.pl>" if key=="kow" else "","subject":subject,
                     "received":received,"body":body,"attachments":files}
                self.ids[key], _ = app.save_message(db,"tabal",key,"INBOX",m)
            app.index_attachment_record(db,self.ids["bau"],0,"cennik_2024.xlsx","Panel ogrodzeniowy antracyt 120 zł")
    def tearDown(self):
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()
    def search(self, query, **kw):
        return app.search_archive(self.project["id"], query, **kw)
    def found(self, query, **kw):
        return {m["id"] for m in self.search(query, **kw)["messages"]}

    def test_inflection_finds_polish_forms_and_can_be_disabled(self):
        self.assertEqual(self.found("Kowalski"), {self.ids["kow"], self.ids["dat"]})
        self.assertEqual(self.found("Kowalskiemu"), {self.ids["kow"], self.ids["dat"]})
        self.assertEqual(self.found("Kowalskiemu", inflect=False), set())
        self.assertEqual(self.found("ogrodzenia", inflect=False), set())
        self.assertEqual(self.found("Łódź"), {self.ids["dat"]})  # Łodzi; accents ignored
        self.assertEqual(self.found("lodz"), {self.ids["dat"]})
        self.assertIn(self.ids["kow"], self.found("ogrodzenia"))

    def test_phrase_matches_across_line_breaks(self):
        self.assertEqual(self.found('"ofertę na ogrodzenie"'), {self.ids["kow"]})

    def test_fields_and_exclusion(self):
        self.assertEqual(self.found("od:kowalski"), {self.ids["kow"]})
        self.assertEqual(self.found("do:comarch"), {self.ids["kow"]})
        self.assertEqual(self.found("temat:faktura"), {self.ids["bau"]})
        self.assertEqual(self.found("plik:cennik"), {self.ids["bau"]})
        self.assertEqual(self.found("antracyt"), {self.ids["bau"]})  # attachment text
        self.assertEqual(self.found("kowalski -montaz"), {self.ids["kow"]})
        self.assertEqual(self.found("https://x.pl"), set())  # unknown prefix stays plain text

    def test_dates_from_fields_operators_and_empty_query(self):
        self.assertEqual(self.found("", date_from="2024-01-01", date_to="2024-03-31"),
                         {self.ids["kow"], self.ids["dat"]})
        self.assertEqual(self.found("kowalski data:2024-01"), {self.ids["dat"]})
        self.assertEqual(self.found("od:2024-03-01 do:2024-12-31"), {self.ids["kow"], self.ids["bau"]})
        self.assertEqual(self.found("brama"), {self.ids["old"]})
        self.assertEqual(self.found("brama", date_from="2024-01-01", date_to=""), set())
        result = self.search("", date_from="", date_to="")
        self.assertEqual(result["total"], 4)
        self.assertEqual([m["id"] for m in result["messages"]][0], self.ids["bau"])  # newest first
        with self.assertRaises(ValueError):
            app.search_archive(self.project["id"], "x | ")
        with self.assertRaises(ValueError):
            app.search_archive(self.project["id"], "", date_from="2024-05-01", date_to="2024-01-01")

    def test_result_has_highlighted_snippet_and_place_of_match(self):
        hit = next(m for m in self.search("lodz")["messages"])
        self.assertEqual(hit["snippet"]["match"], "Łodz")
        self.assertIn("treść", hit["found_in"])
        hit = self.search("antracyt")["messages"][0]
        self.assertTrue(any(x.startswith("załącznik") for x in hit["found_in"]))
        self.assertEqual(hit["snippet"]["match"], "antracyt")
        hit = self.search("kowalski")["messages"][0]
        self.assertTrue(hit["day"])

    def test_question_dates(self):
        today = app.date(2026, 10, 9)
        self.assertEqual(app.question_dates("Co pisał Kowalski w marcu 2024?", today)[:2], ("2024-03-01","2024-03-31"))
        self.assertEqual(app.question_dates("maile od 2023 do 2024", today)[:2], ("2023-01-01","2024-12-31"))
        self.assertEqual(app.question_dates("termin 15.03.2024", today)[:2], ("2024-03-15","2024-03-15"))
        self.assertEqual(app.question_dates("oferty w zeszłym roku", today)[:2], ("2025-01-01","2025-12-31"))
        self.assertEqual(app.question_dates("cena 1999 zł za bramę", today)[:2], ("",""))
        self.assertEqual(app.question_dates("zamówienie ZAM-2024/15", today)[:2], ("",""))

    def test_chat_uses_dates_and_inflection(self):
        app.relink_project(self.project["id"])
        answer = app.ask_project(self.project["id"], "Co pisał Kowalskiemu biuro w styczniu 2024?", "local")
        self.assertEqual(answer["sources"][0], self.ids["dat"])
        self.assertEqual(answer["date_from"], "2024-01-01")
        self.assertIn("styczeń" if False else "2024-01-01", answer["answer"])
        count = app.ask_project(self.project["id"], "Ile maili od Kowalskiego?", "local")
        self.assertEqual(count["match_count"], 2)

    def test_project_filter_is_applied_in_sql(self):
        p = app.create_project("Bauer", "2024-01-01", "2024-12-31", "bauer | comarch", "tabal")
        self.assertEqual(p["local_messages"], 2)  # 5.6: filled from the local archive at once
        self.assertEqual(app.relink_project(p["id"]), 0)

    def test_old_database_is_migrated(self):
        with app.connect() as db:
            db.execute("""INSERT INTO messages(account,uid,message_id,sender,recipient,subject,received,body,attachments)
                          VALUES ('tabal','legacy','<l>','Stary <s@x.pl>','g@tabal.pl','Archiwum',
                          'Wed, 03 Apr 2024 10:00:00 +0200','Umowa ramowa z 2019','[]')""")
            db.execute("CREATE VIRTUAL TABLE search_documents USING fts5(content)")
        self.assertEqual(app.migrate_search_index(progress=None), 1)
        self.assertEqual(self.search('"umowa ramowa"')["total"], 1)
        with app.connect() as db:
            self.assertIsNone(db.execute("SELECT 1 FROM sqlite_master WHERE name='search_documents'").fetchone())
            self.assertEqual(db.execute("SELECT received_day FROM messages WHERE uid='legacy'").fetchone()[0], "2024-04-03")


class Imap55Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ,{"TABAL_LOGIN":"martin@tabal.pl","TABAL_PASSWORD":"fake-test-password",
                                          "TABAL_IMAP_HOST":"imap.example.org"})
        self.env.start()
    def tearDown(self):
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()

    def test_folder_names_quoting_decoding_and_name_exclusion(self):
        self.assertEqual(app.quote_mailbox("INBOX"), "INBOX")
        self.assertEqual(app.quote_mailbox("Sent Items"), '"Sent Items"')
        self.assertEqual(app.imap_utf7_decode("INBOX.Wys&AUI-ane"), "INBOX.Wysłane")
        self.assertEqual(app.imap_utf7_decode("Elementy usuni&ARk-te"), "Elementy usunięte")
        class Listing:
            def list(self): return "OK",[b'(\\HasNoChildren) "." "INBOX"', b'(\\HasNoChildren) "." "INBOX.Trash"',
                                         b'(\\HasNoChildren) "." "INBOX.Kosz"', b'(\\HasNoChildren) "." "INBOX.Wys&AUI-ane"',
                                         b'(\\HasNoChildren) "." "INBOX.Spam"']
        self.assertEqual(app.list_mail_folders(Listing()), ["INBOX","INBOX.Wys&AUI-ane"])

    def test_batch_download_size_check_and_duplicate_copies(self):
        def mail(uid, size_pad=0):
            m = EmailMessage()
            m["From"] = "Klient <k@firma.pl>"; m["To"] = "martin@tabal.pl"
            m["Subject"] = f"Wiadomość {uid}"; m["Message-ID"] = f"<{uid % 100}@firma.pl>"
            m["Date"] = "Tue, 05 Mar 2024 10:00:00 +0100"
            m.set_content("Treść " + str(uid) + "x" * size_pad)
            return m.as_bytes()
        folders = {"INBOX": {str(u): mail(u) for u in range(1, 51)},
                   "Sent Items": {"7": mail(7)}}  # identical copy of INBOX 7 -> stored once
        folders["INBOX"]["50"] = mail(50)
        class BatchIMAP:
            commands = []
            def __init__(self, host, port): self.folder = None
            def login(self, u, p): pass
            def list(self): return "OK",[b'(\\HasNoChildren) "/" "INBOX"', b'(\\Sent) "/" "Sent Items"']
            def select(self, name, readonly=False):
                if " " in name and not name.startswith('"'):
                    raise imaplib.IMAP4.error("BAD Extra arguments")
                self.folder = name.strip('"'); return "OK",[b"1"]
            def uid(self, action, *args):
                BatchIMAP.commands.append((action, args[-1]))
                box = folders[self.folder]
                if action == "search": return "OK",[" ".join(box).encode()]
                wanted = []
                spec = args[0].decode() if isinstance(args[0], bytes) else args[0]
                for part in spec.split(","):
                    a, _, b = part.partition(":")
                    wanted += [str(i) for i in range(int(a), int(b or a) + 1) if str(i) in box]
                if args[1] == "(RFC822.SIZE)":
                    return "OK",[f"1 (UID {u} RFC822.SIZE {40_000_000 if u=='50' else len(box[u])})".encode() for u in wanted]
                data = []
                for u in wanted:
                    # Some servers send UID after the message body.
                    data += [(b'1 (INTERNALDATE " 5-Mar-2024 10:00:00 +0100" BODY[] {9}', box[u]), f" UID {u})".encode()]
                return "OK", data
            def logout(self): pass
        p = app.create_project("Paczki","2024-01-01","2024-12-31","","tabal")
        result = app.sync_project_account(p["id"],"tabal",BatchIMAP)
        self.assertEqual(result["imported"], 49)
        self.assertEqual(result["too_large"], 1)
        with app.connect() as db:
            errors = [tuple(r) for r in db.execute("SELECT operation, detail FROM mail_errors")]
        self.assertEqual(result["failed"], 0, errors)
        fetches = [c for c in BatchIMAP.commands if c[1] == "(UID INTERNALDATE BODY.PEEK[])"]
        self.assertLessEqual(len(fetches), 3)  # 49 mails in a couple of round trips, not 49
        with app.connect() as db:
            day = db.execute("SELECT received_day FROM messages WHERE uid='1'").fetchone()[0]
        self.assertEqual(day, "2024-03-05")
        BatchIMAP.commands = []
        again = app.sync_project_account(p["id"],"tabal",BatchIMAP)
        self.assertEqual(again["imported"], 0)
        downloads = [c for c in BatchIMAP.commands if "BODY.PEEK[]" in c[1]]
        self.assertEqual(downloads, [])  # duplicate copy in Sent Items is remembered, not re-downloaded

    def test_html_stub_and_long_recipient_list(self):
        m = EmailMessage()
        m["From"] = "a@b.pl"
        m["To"] = ", ".join(f"Osoba {i} <osoba{i}@firma.pl>" for i in range(60)) + ", Zenon Ostatni <z@firma.pl>"
        m["Subject"] = "Test"
        m.set_content("Wiadomość w HTML")
        m.add_alternative("<html><head><style>.x{color:red}</style></head><body><p>" + "Szczegóły oferty. " * 60 +
                          "</p><p>Numer umowy UM-77</p></body></html>", subtype="html")
        parsed = app.parse_mail(m.as_bytes())
        self.assertIn("UM-77", parsed["body"])
        self.assertNotIn("color:red", parsed["body"])
        self.assertIn("Zenon Ostatni", parsed["recipient"])


def archive_server(folders_spec, drop_after=None):
    """Fake IMAP server with real UID sets, sizes, quoting rules and optional connection drop."""
    store = {}
    for folder, uids in folders_spec.items():
        store[folder] = {}
        for uid in uids:
            m = EmailMessage()
            m["From"] = "Jan Kowalski <jan@budimex.pl>" if uid % 2 else "Peter Bauer <pb@bauer.de>"
            m["To"] = "gbartosik@tabal.pl"; m["Subject"] = f"{folder} wiadomość {uid}"
            m["Message-ID"] = f"<{folder}-{uid}@sim>"; m["Date"] = "Tue, 05 Mar 2024 10:00:00 +0100"
            m.set_content(f"Treść {uid} oferta ogrodzenia")
            if uid % 5 == 0:
                m.add_attachment(f"Cennik {uid} antracyt".encode(), maintype="text", subtype="plain", filename=f"cennik_{uid}.txt")
            store[folder][str(uid)] = m.as_bytes()
    state = {"fetched": 0, "logins": 0, "dropped": False}

    class Server:
        def __init__(self, host, port, timeout=None): self.folder = None
        def login(self, u, p): state["logins"] += 1
        def list(self):
            return "OK", [f'(\\HasNoChildren) "/" "{f}"'.encode() for f in store]
        def select(self, name, readonly=False):
            if " " in name and not name.startswith('"'):
                raise imaplib.IMAP4.error("BAD Extra arguments")
            self.folder = name.strip('"'); return "OK", [b"1"]
        def uid(self, action, *args):
            box = store[self.folder]
            if action == "search": return "OK", [" ".join(box).encode()]
            spec = args[0].decode() if isinstance(args[0], bytes) else args[0]
            wanted = []
            for part in spec.split(","):
                a, _, b = part.partition(":")
                wanted += [str(i) for i in range(int(a), int(b or a) + 1) if str(i) in box]
            if args[1] == "(RFC822.SIZE)":
                return "OK", [f"1 (UID {u} RFC822.SIZE {len(box[u])})".encode() for u in wanted]
            if drop_after is not None and state["fetched"] >= drop_after and not state["dropped"]:
                state["dropped"] = True
                raise imaplib.IMAP4.abort("socket error: EOF")
            data = []
            for u in wanted:
                state["fetched"] += 1
                data += [(f'1 (UID {u} INTERNALDATE "05-Mar-2024 10:00:00 +0100" BODY[] {{1}}'.encode(), box[u]), b")"]
            return "OK", data
        def logout(self): pass
    return Server, state


class Archive56Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ,{"TABAL_LOGIN":"martin@tabal.pl","TABAL_PASSWORD":"fake-test-password",
                                          "TABAL_IMAP_HOST":"imap.example.org","SKYFENS_LOGIN":"","SKYFENS_PASSWORD":""})
        self.env.start()
        app.ARCHIVE_JOB.update({"running":False, "stop":False})
        self.sleep = patch.object(app.time, "sleep", lambda s: None)
        self.sleep.start()
    def tearDown(self):
        self.sleep.stop()
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()

    def test_archive_downloads_all_folders_keeps_copies_and_works_offline(self):
        Server, state = archive_server({"INBOX": range(1, 61), "Sent Items": range(1, 31), "Projekty/Bauer": range(1, 11)})
        results = app.run_archive("2021-01-01", True, Server)
        self.assertEqual(results[0]["imported"], 100)
        self.assertEqual(results[0]["raw_saved"], 100)
        status = app.archive_status()
        tabal = status["accounts"][0]
        self.assertEqual((tabal["messages"], tabal["with_copy"]), (100, 100))
        self.assertEqual({f["folder"] for f in tabal["folders"]}, {"INBOX", "Sent Items", "Projekty/Bauer"})
        self.assertTrue(status["settings"]["last_update"])
        project_id = status["settings"]["project_id"]
        self.assertEqual(app.project_data(project_id, include_messages=False)["total_messages"], 100)
        # Offline: the server is unreachable, attachments still open from the local copy.
        def offline(host, port, timeout=None):
            raise socket.gaierror(-2, "Name or service not known")
        with app.connect() as db:
            mid = db.execute("SELECT id FROM messages WHERE attachments!='[]' LIMIT 1").fetchone()[0]
        name, mime, blob = app.attachment_bytes(mid, 0, offline)
        self.assertTrue(name.startswith("cennik_"))
        self.assertIn(b"antracyt", blob)
        self.assertIn("antracyt", app.index_attachment(mid, 0, offline)["text"])
        # A new project is filled locally, without connecting anywhere.
        p = app.create_project("Bauer offline", "2024-01-01", "2024-12-31", "od:bauer", "tabal")
        self.assertEqual(p["local_messages"], 50)
        self.assertIn("offline", app.sync_error_message(socket.gaierror(-2, "Name or service not known")))
        # Second run only checks: nothing is downloaded again.
        before = state["fetched"]
        again = app.run_archive("2021-01-01", True, Server)
        self.assertEqual((again[0]["imported"], state["fetched"] - before), (0, 0))

    def test_copies_are_backfilled_without_duplicates(self):
        Server, state = archive_server({"INBOX": range(1, 21)})
        app.run_archive("2021-01-01", False, Server)
        self.assertEqual(app.archive_status()["accounts"][0]["with_copy"], 0)
        result = app.run_archive("2021-01-01", True, Server)[0]
        self.assertEqual((result["imported"], result["raw_saved"]), (0, 20))
        with app.connect() as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM messages").fetchone()[0], 20)

    def test_dropped_connection_is_resumed(self):
        Server, state = archive_server({"INBOX": range(1, 121)}, drop_after=45)
        result = app.run_archive("2021-01-01", True, Server)[0]
        self.assertTrue(state["dropped"])
        self.assertGreaterEqual(state["logins"], 2)
        self.assertEqual((result["imported"], result["failed"]), (120, 0))
        with app.connect() as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM messages").fetchone()[0], 120)

    def test_stop_and_continue_later(self):
        Server, state = archive_server({"INBOX": range(1, 101)})
        calls = {"n": 0}
        def stop_soon():
            calls["n"] += 1
            return calls["n"] > 2
        first = app.sync_range("tabal", app.date(2021,1,1), app.date.today(), Server, store_raw=True,
                               backfill_raw=True, should_stop=stop_soon)
        self.assertTrue(first["stopped"])
        self.assertLess(first["imported"], 100)
        rest = app.run_archive("2021-01-01", True, Server)[0]
        self.assertEqual(first["imported"] + rest["imported"], 100)

    def test_cli_without_accounts_explains_what_to_do(self):
        with patch.dict(os.environ, {"TABAL_LOGIN":"", "TABAL_PASSWORD":""}):
            out = io.StringIO()
            with patch("sys.stdout", out):
                self.assertEqual(app.archive_cli("2021-01-01", True), 2)
            self.assertIn("Konfiguracja kont", out.getvalue())


def tb_mail(n, status="0001", status2="00000000", subject=None, sender=None, attachment=True, extra_body=""):
    m = EmailMessage()
    m["From"] = sender or ("Jan Kowalski <jan@budimex.pl>" if n % 2 else "Peter Bauer <pb@bauer.de>")
    m["To"] = "Grzegorz Bartosik <gbartosik@tabal.pl>"
    m["Subject"] = subject or f"Oferta nr {n}"
    m["Message-ID"] = f"<tb-{n}@test>"
    m["Date"] = f"Tue, {1 + n % 27:02d} Feb 2024 10:00:00 +0100"
    m.set_content(f"Dzień dobry,\nprzesyłam ofertę {n} na ogrodzenie.\nFrom my phone{extra_body}\n")
    if attachment and n % 3 == 0:
        m.add_attachment(f"Cennik {n}: panel antracyt".encode(), maintype="text", subtype="plain", filename=f"cennik_{n}.txt")
    raw = m.as_bytes().replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
    raw = raw.replace(b"\r\nFrom my phone", b"\r\n>From my phone")  # Thunderbird escapes body "From " lines
    head = f"From - Tue Feb  6 10:00:00 2024\r\nX-Mozilla-Status: {status}\r\nX-Mozilla-Status2: {status2}\r\nX-Mozilla-Keys:                                                                                 \r\n".encode()
    return head + raw + b"\r\n"


def write_mbox(path, mails, old=True):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"".join(mails))
    (path.parent / (path.name + ".msf")).write_bytes(b"// <!-- <mdb:mork:z v=\"1.4\"/> -->")
    if old:
        os.utime(path, (time.time() - 3600, time.time() - 3600))


class Thunderbird57Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        root = Path(self.temp.name)
        app.DB_PATH = root / "app" / "test.sqlite3"
        app.DB_PATH.parent.mkdir()
        app.connect().close()
        self.env = patch.dict(os.environ,{"TABAL_LOGIN":"","TABAL_PASSWORD":"","SKYFENS_LOGIN":"","SKYFENS_PASSWORD":""})
        self.env.start()
        app.ARCHIVE_JOB.update({"running":False, "stop":False})
        self.profile = root / "Profiles" / "abcd.default-release"
        self.acc = self.profile / "ImapMail" / "tabal.home.pl"
        self.inbox = [tb_mail(n) for n in range(1, 31)]
        self.inbox[4] = tb_mail(5, status="0009")              # deleted, not compacted yet
        self.inbox[6] = tb_mail(7, status2="00200000")         # IMAP "marked as deleted"
        self.inbox[8] = tb_mail(9, status="0401")              # downloaded without body
        write_mbox(self.acc / "INBOX", self.inbox)
        write_mbox(self.acc / "Sent", [tb_mail(n, sender="Grzegorz <gbartosik@tabal.pl>") for n in range(100, 110)])
        write_mbox(self.acc / "Trash", [tb_mail(n) for n in range(200, 205)])
        write_mbox(self.acc / "INBOX.sbd" / "Klienci.sbd" / "Firma ABC", [tb_mail(n) for n in range(300, 305)])
        (self.acc / "INBOX.sbd" / "Klienci").write_bytes(b"")  # empty parent folder file
        (self.acc / "INBOX.sbd" / "Klienci.msf").write_bytes(b"")
        write_mbox(self.profile / "Mail" / "Local Folders" / "Archiwum 2021", [tb_mail(n) for n in range(400, 403)])
    def tearDown(self):
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()
    def count(self):
        with app.connect() as db:
            return db.execute("SELECT COUNT(*) FROM messages").fetchone()[0]

    def test_inspect_finds_accounts_folders_and_guesses_mailbox(self):
        info = app.tb_inspect(str(self.profile))
        names = {a["name"]: a for a in info["accounts"]}
        self.assertEqual(names["tabal.home.pl"]["account"], "tabal")
        self.assertEqual(names["Local Folders"]["account"], "")  # not guessed -> skipped unless assigned
        folders = [f[0] for f in app.tb_folders(self.acc)]
        self.assertEqual(sorted(folders), ["INBOX", "INBOX/Klienci/Firma ABC", "Sent"])  # Trash skipped

    def test_index_search_and_offline_attachment(self):
        result = app.run_thunderbird(str(self.profile), workers=1)
        self.assertEqual(result["imported"], 30 - 2 + 10 + 5)
        self.assertEqual((result["deleted_skipped"], result["partial"], result["failed"]), (2, 1, 0))
        project_id = int(app.get_setting("archive_project_id"))
        self.assertEqual(app.project_data(project_id, include_messages=False)["total_messages"], 43)
        hits = app.search_archive(project_id, "antracyt od:kowalski", date_from="", date_to="")
        self.assertTrue(hits["total"] > 0)
        self.assertEqual(app.search_archive(project_id, '"from my phone"', date_from="", date_to="")["total"], 43)
        with app.connect() as db:
            mid, folder = db.execute("SELECT id, folder FROM messages WHERE subject='Oferta nr 3'").fetchone()
            day = db.execute("SELECT received_day FROM messages WHERE id=?", (mid,)).fetchone()[0]
        self.assertEqual((folder, day), ("INBOX", "2024-02-04"))
        def offline(*a, **k): raise socket.gaierror(-2, "offline")
        name, mime, blob = app.attachment_bytes(mid, 0, offline)
        self.assertEqual((name, blob), ("cennik_3.txt", b"Cennik 3: panel antracyt"))
        # Local Folders can be assigned to a mailbox explicitly.
        mapping = {str(self.acc): "tabal", str(self.profile / "Mail" / "Local Folders"): "tabal"}
        again = app.run_thunderbird(str(self.profile), mapping, workers=1)
        self.assertEqual(again["imported"], 3)

    def test_incremental_flags_compaction_and_still_writing(self):
        app.run_thunderbird(str(self.profile), workers=1)
        base = self.count()
        # Thunderbird appends new mail; the last one is still being written (fresh mtime).
        with open(self.acc / "INBOX", "ab") as f:
            f.write(tb_mail(31) + tb_mail(32))
        seen = {}
        r = app.run_thunderbird(str(self.profile), workers=1, progress=lambda p: seen.update(p))
        self.assertEqual(r["imported"], 1)
        self.assertLess(seen["bytes_total"], 20_000)  # only appended bytes were read
        os.utime(self.acc / "INBOX", (time.time() - 3600, time.time() - 3600))
        self.assertEqual(app.run_thunderbird(str(self.profile), workers=1)["imported"], 1)
        self.assertEqual(self.count(), base + 2)
        # Mail marked as read: Thunderbird rewrites X-Mozilla-Status in place -> no duplicates.
        data = (self.acc / "INBOX").read_bytes().replace(b"X-Mozilla-Status: 0001", b"X-Mozilla-Status: 0003", 1)
        write_mbox(self.acc / "INBOX", [data])
        r = app.run_thunderbird(str(self.profile), workers=1)
        self.assertEqual((r["imported"], self.count()), (0, base + 2))
        # Compaction: deleted mails physically removed, every position shifts.
        compacted = [m for m in self.inbox if b"X-Mozilla-Status: 0009" not in m][3:] + [tb_mail(31), tb_mail(32)]
        write_mbox(self.acc / "INBOX", compacted)
        with app.connect() as db:
            mid = db.execute("SELECT id FROM messages WHERE subject='Oferta nr 12'").fetchone()[0]
        name, _, blob = app.attachment_bytes(mid, 0, None)  # positions repaired automatically
        self.assertEqual(blob, b"Cennik 12: panel antracyt")
        r = app.run_thunderbird(str(self.profile), workers=1)
        self.assertEqual(r["imported"], 0)
        self.assertEqual(self.count(), base + 2)

    def test_large_import_builds_full_text_index_once(self):
        """5.11: big imports suspend the index and rebuild it at the end; small ones update it live."""
        app.ensure_fts()
        phases = []
        with patch.object(app, "FTS_BULK_MIN_BYTES", 0):
            r = app.run_thunderbird(str(self.profile), workers=1, progress=lambda p: phases.append(p.get("phase")))
        self.assertIn("fts", phases)
        self.assertTrue(app.fts_ready())
        project_id = int(app.get_setting("archive_project_id"))
        self.assertIn("mail_fts", app.query_condition(app.parse_query("antracyt", True))[0])
        self.assertEqual(app.search_archive(project_id, '"from my phone"', date_from="", date_to="")["total"], 43)
        # Small incremental update: the index follows through the triggers.
        os.utime(self.acc / "INBOX", (time.time() - 3600, time.time() - 3600))
        with open(self.acc / "INBOX", "ab") as f:
            f.write(tb_mail(33))
        os.utime(self.acc / "INBOX", (time.time() - 3600, time.time() - 3600))
        phases.clear()
        app.run_thunderbird(str(self.profile), workers=1, progress=lambda p: phases.append(p.get("phase")))
        self.assertNotIn("fts", phases)
        self.assertEqual(app.search_archive(project_id, '"from my phone"', date_from="", date_to="")["total"], 44)
        with app.connect() as db:
            db.execute("INSERT INTO mail_fts(mail_fts, rank) VALUES('integrity-check', 1)")

    def test_interrupted_large_import_rebuilds_index_on_next_start(self):
        app.ensure_fts()
        app.ARCHIVE_JOB["stop"] = True
        with patch.object(app, "FTS_BULK_MIN_BYTES", 0):
            app.run_thunderbird(str(self.profile), workers=1)
        app.ARCHIVE_JOB["stop"] = False
        self.assertFalse(app.fts_ready())        # search falls back to the full scan meanwhile
        app.migrate_search_index(progress=None)  # what the program does at start
        self.assertTrue(app.fts_ready())
        with app.connect() as db:
            db.execute("INSERT INTO mail_fts(mail_fts, rank) VALUES('integrity-check', 1)")

    def test_maildir_folder(self):
        cur = self.profile / "ImapMail" / "mail.skyfens.pl" / "INBOX" / "cur"
        cur.mkdir(parents=True)
        for n in range(500, 504):
            (cur / f"{n}.eml").write_bytes(tb_mail(n).split(b"\r\n", 1)[1])
        r = app.run_thunderbird(str(self.profile), workers=1)
        with app.connect() as db:
            sky = db.execute("SELECT COUNT(*) FROM messages WHERE account='skyfens'").fetchone()[0]
        self.assertEqual(sky, 4)
        self.assertEqual(r["failed"], 0)

    def test_cli(self):
        out = io.StringIO()
        with patch("sys.stdout", out):
            self.assertEqual(app.thunderbird_cli(str(self.profile)), 0)
        text = out.getvalue()
        self.assertIn("tabal.home.pl", text)
        self.assertIn("POMIJAM", text)  # Local Folders not assigned
        self.assertIn("Gotowe", text)


class FakeOpenAI:
    """Simulated Responses API: answers by schema name and records every call."""
    def __init__(self, fail_after=None):
        self.calls = []
        self.fail_after = fail_after
    def __call__(self, request, timeout):
        body = json.loads(request.data)
        name = body["text"]["format"]["name"]
        payload = json.loads(body["input"])
        self.calls.append((name, payload))
        if self.fail_after is not None and len(self.calls) > self.fail_after:
            raise urllib.error.HTTPError("u", 500, "x", {}, io.BytesIO(b"{}"))
        if name == "mail_extracts":
            out = {"mails":[{"id":m["id"], "summary":"Streszczenie " + m["text"].split("Temat: ")[1].split("\n")[0],
                             "topic":"oferta", "parties":["Aliplast"], "amounts":[{"value":"120 zł/m", "what":"panel"}],
                             "dates":[{"date":"2024-03-10", "what":"dostawa"}], "decisions":[], "issues":[], "actions":[]}
                            for m in payload["mails"]]}
        elif name == "period_note":
            first = re.search(r"\[(\d+)\]", payload["material"]).group(1)
            out = {"note":f"Ceny paneli 120 zł/m [{first}]."}
        else:
            ids = re.findall(r"\[(\d+)", payload["notatki"])
            out = {"report":f"## Podsumowanie\nWspółpraca stabilna [{ids[0]}] [999999].\n"}
        response = FakeResponse()
        response.blob = json.dumps({"status":"completed", "usage":{"input_tokens":1000, "output_tokens":200},
                                    "output":[{"content":[{"type":"output_text","text":json.dumps(out, ensure_ascii=False)}]}]}).encode()
        return response


class Analysis58Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ, {"OPENAI_API_KEY":"sk-test-" + "x"*30, "OPENAI_PRICE_IN":"0.40",
                                           "OPENAI_PRICE_OUT":"1.60"})
        self.env.start()
        self.sleep = patch.object(app.time, "sleep", lambda s: None); self.sleep.start()
        app.ANALYSIS_JOB.clear(); app.ANALYSIS_JOB.update({"running":False, "stop":False})
        self.project = app.create_project("Aliplast", "2021-01-01", app.date.today().isoformat(), "", "tabal")["id"]
        with app.connect() as db:
            for n in range(60):
                body = (f"Dzień dobry,\nw załączeniu oferta {n} na panele.\nPozdrawiam\n\n"
                        f"W dniu 1 marca 2024 Jan Kowalski <jan@x.pl> napisał:\n> stara treść wątku {n}\n> cena 999 zł")
                m = {"message_id":f"<a{n}@t>", "sender":"Aliplast <oferty@aliplast.pl>" if n % 2 else "Inny <i@x.pl>",
                     "recipient":"gbartosik@tabal.pl", "cc":"", "subject":f"Re: Oferta {n}",
                     "received":f"2024-{1 + n % 12:02d}-10T10:00:00+01:00", "body":body, "attachments":"[]"}
                app.save_message(db, "tabal", f"a{n}", "INBOX", m)
        app.relink_project(self.project)
    def tearDown(self):
        self.sleep.stop(); self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()

    def test_quote_stripping_and_thread_key(self):
        text = "Proszę o wycenę.\n\nW dniu 3.03.2024 o 10:00 Jan <j@x.pl> napisał:\n> Stara cena 999 zł"
        self.assertEqual(app.strip_quoted(text), "Proszę o wycenę.")
        outlook = "Potwierdzam.\n\nOd: Jan Kowalski <j@x.pl>\nWysłano: wtorek, 5 marca 2024\nDo: x\nTemat: Oferta"
        self.assertEqual(app.strip_quoted(outlook), "Potwierdzam.")
        self.assertEqual(app.strip_quoted("-----Original Message-----\nFrom: a\nTreść przekazana"), "From: a\nTreść przekazana")
        self.assertEqual(app.thread_key("RE: Odp: FW: [EXT] Oferta 12"), "oferta 12")

    def test_estimate_extract_cache_report_and_citations(self):
        est = app.estimate_analysis(self.project, "search", "aliplast", "", "")
        self.assertEqual((est["messages"], est["to_extract"]), (30, 30))
        self.assertGreater(est["cost_usd"], 0)
        fake = FakeOpenAI()
        r = app.run_analysis(self.project, "search", "Ceny w ofertach Aliplast", "aliplast", "", "", opener=fake, workers=2)
        self.assertEqual(r["status"], "gotowe", r["error"])
        maps = [c for c in fake.calls if c[0] == "mail_extracts"]
        self.assertEqual(sum(len(c[1]["mails"]) for c in maps), 30)
        self.assertNotIn("stara treść wątku", json.dumps([c[1] for c in maps], ensure_ascii=False))  # quotes removed
        self.assertNotIn("999999", r["report"])  # invented citation dropped
        self.assertTrue(r["sources"])
        self.assertAlmostEqual(r["cost_usd"], app.usd(r["input_tokens"], r["output_tokens"]), places=4)
        # A second analysis of the same mails reuses extracts: only the report call is paid.
        fake2 = FakeOpenAI()
        r2 = app.run_analysis(self.project, "project", "Terminy dostaw", opener=fake2)
        self.assertEqual(r2["status"], "gotowe")
        self.assertEqual(sum(len(c[1]["mails"]) for c in fake2.calls if c[0] == "mail_extracts"), 30)  # only the other 30
        self.assertEqual(app.estimate_analysis(self.project, "project")["to_extract"], 0)
        csv_text = app.analysis_facts_csv(self.project, "project")
        self.assertIn("120 zł/m", csv_text)
        self.assertEqual(app.analysis_list(self.project)[0]["status"], "gotowe")

    def test_large_selection_uses_period_notes(self):
        with patch.object(app, "FINAL_MAX_CHARS", 2000), patch.object(app, "REDUCE_CHUNK_CHARS", 1500):
            fake = FakeOpenAI()
            r = app.run_analysis(self.project, "project", "Przebieg współpracy", opener=fake, workers=1)
        self.assertEqual(r["status"], "gotowe", r["error"])
        self.assertGreater(len([c for c in fake.calls if c[0] == "period_note"]), 1)
        self.assertEqual(len([c for c in fake.calls if c[0] == "analysis_report"]), 1)

    def test_budget_limit_pauses_and_resume_continues(self):
        fake = FakeOpenAI()
        r = app.run_analysis(self.project, "project", "Cel", budget_usd=0.0005, opener=fake, workers=1)
        self.assertEqual(r["status"], "przerwane")
        self.assertIn("budżetu", r["error"])
        done = 60 - app.estimate_analysis(self.project, "project")["to_extract"]
        self.assertTrue(0 < done < 60)
        r = app.run_analysis(self.project, "project", "Cel", budget_usd=5, opener=FakeOpenAI(), workers=1)
        self.assertEqual(r["status"], "gotowe")

    def test_api_error_is_reported_and_work_kept(self):
        fake = FakeOpenAI(fail_after=1)
        r = app.run_analysis(self.project, "project", "Cel", opener=fake, workers=1)
        self.assertEqual(r["status"], "błąd")
        self.assertLess(app.estimate_analysis(self.project, "project")["to_extract"], 60)

    def test_start_requires_confirmation_and_key(self):
        with self.assertRaisesRegex(ValueError, "Potwierdź"):
            app.start_analysis({"id":self.project, "goal":"x"})
        with patch.dict(os.environ, {"OPENAI_API_KEY":""}):
            with self.assertRaisesRegex(ValueError, "klucza"):
                app.start_analysis({"id":self.project, "goal":"x", "confirm":True})

    def test_word_runs_and_excel_rows(self):
        doc = io.BytesIO()
        with zipfile.ZipFile(doc, "w") as z:
            z.writestr("word/document.xml", '<w:document xmlns:w="x"><w:body><w:p><w:r><w:t>Ofe</w:t></w:r>'
                       '<w:r><w:t>rta 7</w:t></w:r></w:p></w:body></w:document>')
        self.assertEqual(app.extract_document("o.docx", "", doc.getvalue()), "Oferta 7")
        sheet = io.BytesIO()
        with zipfile.ZipFile(sheet, "w") as z:
            z.writestr("xl/workbook.xml", '<workbook xmlns="x"><sheets><sheet name="Cennik"/></sheets></workbook>')
            z.writestr("xl/sharedStrings.xml", '<sst xmlns="x"><si><t>Panel 3D</t></si></sst>')
            z.writestr("xl/worksheets/sheet1.xml", '<worksheet xmlns="x"><sheetData><row><c t="s"><v>0</v></c>'
                       '<c><v>120</v></c></row></sheetData></worksheet>')
        self.assertEqual(app.extract_document("c.xlsx", "", sheet.getvalue()), "== Arkusz: Cennik ==\nPanel 3D | 120")


class ScriptedChatModel:
    """Fake Responses API with tool calls. Behaves like a model following the instructions."""
    def __init__(self, loop_forever=False):
        self.requests = []
        self.loop_forever = loop_forever
    def reply(self, output, tin=1500, tout=200):
        r = FakeResponse()
        r.blob = json.dumps({"usage":{"input_tokens":tin, "output_tokens":tout}, "output":output}).encode()
        return r
    def call(self, name, args, n):
        return {"type":"function_call", "id":f"fc_{n}", "call_id":f"call_{n}", "name":name,
                "arguments":json.dumps(args, ensure_ascii=False)}
    def text(self, t):
        return {"type":"message", "content":[{"type":"output_text", "text":t}]}
    def __call__(self, request, timeout):
        body = json.loads(request.data)
        self.requests.append(body)
        items = body["input"]
        user = [i for i in items if i.get("role") == "user"][-1]["content"]
        outputs = [json.loads(i["output"]) for i in items if i.get("type") == "function_call_output"]
        n = len(outputs)
        if self.loop_forever:
            if body["tool_choice"] == "none":
                return self.reply([self.text("Nie znalazłem jednoznacznej odpowiedzi.")])
            return self.reply([self.call("search_mail", {"query":f"x{n}", "date_from":"", "date_to":"", "limit":5}, n)])
        if "angielski" in user:
            previous = [i for i in items if i.get("role") == "assistant"][-1]["content"]
            ids = re.findall(r"\[(\d+)\]", previous)
            return self.reply([self.text(f"In 2024 Aliplast offered panels at 120 PLN/m [{ids[0]}].")])
        if "ile" in user.lower().split():
            if n == 0:
                return self.reply([self.call("mail_stats", {"query":"aliplast", "date_from":"", "date_to":"",
                                                            "group_by":"year"}, n)])
            counts = outputs[0]["counts"]
            return self.reply([self.text("Rocznie: " + ", ".join(f"{c['key']}: {c['count']}" for c in counts)
                                         + f" [{outputs[0]['example_ids'][0]}]")])
        if n == 0:
            return self.reply([self.call("search_mail", {"query":"aliplast", "date_from":"2024-01-01",
                                                         "date_to":"2024-12-31", "limit":10}, n)])
        if n == 1:
            ids = [r["id"] for r in outputs[0]["results"]][:3]
            return self.reply([self.call("read_mails", {"ids":ids}, n), self.call("get_extracts",
                               {"query":"aliplast", "date_from":"", "date_to":""}, n + 100)])
        mails = outputs[1]["mails"]
        return self.reply([self.text(f"W 2024 Aliplast oferował panele po 120 zł/m [{mails[0]['id']}]. "
                                     f"Termin dostawy przesunięto [{mails[1]['id']}, 999999].")])


class Chat59Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ, {"OPENAI_API_KEY":"sk-test-" + "x"*30, "OPENAI_CHAT_MODEL":"gpt-4.1"})
        self.env.start()
        self.sleep = patch.object(app.time, "sleep", lambda s: None); self.sleep.start()
        with app.connect() as db:
            for n in range(40):
                m = {"message_id":f"<c{n}@t>", "sender":"Aliplast <oferty@aliplast.pl>" if n % 2 else "Bauer <pb@bauer.de>",
                     "recipient":"gbartosik@tabal.pl", "cc":"", "subject":f"Oferta {n}",
                     "received":f"{2023 + n % 3}-0{1 + n % 9}-10T10:00:00+01:00",
                     "body":f"Cena panelu 120 zł/m, dostawa {n}.\n\nW dniu 1 marca 2024 X <x@x.pl> napisał:\n> stare",
                     "attachments":"[]"}
                app.save_message(db, "tabal", f"c{n}", "INBOX", m)
        self.project = app.create_project("Archiwum", "2021-01-01", app.date.today().isoformat(), "", "tabal")["id"]
    def tearDown(self):
        self.sleep.stop(); self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()

    def test_broad_question_then_translation_uses_memory(self):
        fake = ScriptedChatModel()
        first = app.ask_project(self.project, "Jak wyglądała współpraca z Aliplast w 2024?", "ai", opener=fake)
        self.assertIn("120 zł/m", first["answer"])
        self.assertNotIn("999999", first["answer"])            # invented citation removed
        self.assertTrue(first["sources"])
        self.assertTrue(any(t.startswith("szukano: aliplast") for t in first["trace"]))
        self.assertEqual(fake.requests[0]["model"], "gpt-4.1")
        names = {t["name"] for t in fake.requests[0]["tools"]}
        self.assertEqual(names, {"search_mail", "read_mails", "mail_stats", "get_extracts",
                                 "unanswered_mails", "save_reply_draft"})  # 5.13: two new tools
        # The model asked for read_mails: bodies come without quoted history.
        read = [json.loads(i["output"]) for i in fake.requests[-1]["input"] if i.get("type") == "function_call_output"]
        self.assertTrue(all("stare" not in m["body"] for m in read[1]["mails"]))
        self.assertIn("note", read[2])                           # extracts missing -> hint returned
        calls_before = len(fake.requests)
        second = app.ask_project(self.project, "Przetłumacz to na angielski", "ai", opener=fake)
        self.assertTrue(second["answer"].startswith("In 2024 Aliplast"))
        self.assertEqual(second["sources"], [first["sources"][0]])  # citation from history kept
        self.assertEqual(len(fake.requests) - calls_before, 1)       # no new search needed
        history = fake.requests[-1]["input"]
        self.assertEqual([i.get("role") for i in history[:3]], ["user", "assistant", "user"])
        self.assertGreater(second["cost_usd"], 0)

    def test_new_conversation_forgets_and_stats_tool(self):
        fake = ScriptedChatModel()
        app.ask_project(self.project, "Jak wyglądała współpraca z Aliplast w 2024?", "ai", opener=fake)
        app.new_chat_thread(self.project)
        self.assertEqual(app.project_data(self.project)["history"], [])
        r = app.ask_project(self.project, "Ile maili od Aliplast?", "ai", opener=fake)
        self.assertIn("2023: 7", r["answer"])
        self.assertEqual([i.get("role") for i in fake.requests[-1]["input"] if i.get("role")], ["user"])
        self.assertEqual(len(app.project_data(self.project)["recent_questions"]), 2)

    def test_tool_loop_is_capped(self):
        fake = ScriptedChatModel(loop_forever=True)
        r = app.ask_project(self.project, "Coś trudnego", "ai", opener=fake)
        self.assertEqual(len(fake.requests), app.CHAT_MAX_ROUNDS + 1)
        self.assertEqual(fake.requests[-1]["tool_choice"], "none")
        self.assertIn("Nie znalazłem", r["answer"])

    def test_tools_directly(self):
        res = app.tool_search_mail(self.project, {"query":"od:aliplast", "date_from":"2024-01-01", "date_to":"2024-12-31", "limit":3})
        self.assertEqual(res["shown"], 3)
        self.assertTrue(all("aliplast" in h["from"].lower() for h in res["results"]))
        stats = app.tool_mail_stats(self.project, {"query":"", "date_from":"", "date_to":"", "group_by":"domain"})
        self.assertEqual({c["key"] for c in stats["counts"]}, {"aliplast.pl", "bauer.de"})
        read = app.tool_read_mails(self.project, {"ids":[res["results"][0]["id"], 987654]})
        self.assertIn("error", read["mails"][1])


class ReasoningModel510Tests(unittest.TestCase):
    """GPT-5.6 (Sol/Terra/Luna) are reasoning models: reasoning items must be replayed with tool results."""
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ, {"OPENAI_API_KEY":"sk-test-" + "x"*30, "OPENAI_CHAT_MODEL":"gpt-5.6-sol",
                                           "OPENAI_REASONING_EFFORT":"medium", "OPENAI_MODEL":"gpt-5.6-luna"})
        self.env.start()
        with app.connect() as db:
            for n in range(6):
                app.save_message(db, "tabal", f"r{n}", "INBOX", {"message_id":f"<r{n}@t>", "sender":"Aliplast <a@aliplast.pl>",
                    "recipient":"g@tabal.pl", "cc":"", "subject":f"Oferta {n}", "received":"2024-05-10T10:00:00+01:00",
                    "body":"Cena 120 zł/m", "attachments":"[]"})
        self.project = app.create_project("A", "2021-01-01", app.date.today().isoformat(), "", "tabal")["id"]
    def tearDown(self):
        self.env.stop(); app.DB_PATH = self.old_db; self.temp.cleanup()

    def test_reasoning_items_replayed_effort_and_cost(self):
        requests = []
        def fake(request, timeout):
            body = json.loads(request.data); requests.append(body)
            r = FakeResponse()
            usage = {"input_tokens":10000, "input_tokens_details":{"cached_tokens":8000},
                     "output_tokens":3000, "output_tokens_details":{"reasoning_tokens":2500}}
            if len(requests) == 1:
                out = [{"type":"reasoning", "id":"rs_1", "summary":[], "encrypted_content":"ENC123"},
                       {"type":"function_call", "id":"fc_1", "call_id":"c1", "name":"search_mail",
                        "arguments":json.dumps({"query":"aliplast", "date_from":"", "date_to":"", "limit":5})}]
            else:
                ids = re.findall(r'"id": (\d+)', [i for i in body["input"] if i.get("type") == "function_call_output"][0]["output"])
                out = [{"type":"reasoning", "id":"rs_2", "summary":[], "encrypted_content":"ENC456"},
                       {"type":"message", "role":"assistant", "content":[{"type":"output_text", "text":f"Cena 120 zł/m [{ids[0]}]."}]}]
            r.blob = json.dumps({"status":"completed", "usage":usage, "output":out}).encode()
            return r
        result = app.chat_ai(self.project, "Ceny Aliplast?", [], fake)
        self.assertEqual(requests[0]["model"], "gpt-5.6-sol")
        self.assertEqual(requests[0]["reasoning"], {"effort":"medium"})
        self.assertGreaterEqual(requests[0]["max_output_tokens"], 18000)
        replay = requests[1]["input"]
        self.assertIn({"type":"reasoning", "id":"rs_1", "summary":[], "encrypted_content":"ENC123"}, replay)
        self.assertTrue(any(i.get("type") == "function_call" and i["call_id"] == "c1" for i in replay))
        self.assertTrue(result["sources"])
        # 2 calls x (2000 uncached*$4 + 8000 cached*$0.40 + 3000 out*$20) / 1M
        self.assertAlmostEqual(result["cost_usd"], 2 * (0.008 + 0.0032 + 0.06), places=4)

    def test_extracts_use_cheap_model_and_report_uses_chat_model(self):
        seen = []
        fake = FakeOpenAI()
        def spy(request, timeout):
            body = json.loads(request.data); seen.append((body["text"]["format"]["name"], body["model"], body.get("reasoning")))
            return fake(request, timeout)
        r = app.run_analysis(self.project, "project", "Ceny", opener=spy, workers=1)
        self.assertEqual(r["status"], "gotowe", r["error"])
        self.assertIn(("mail_extracts", "gpt-5.6-luna", {"effort":"low"}), seen)
        self.assertIn(("analysis_report", "gpt-5.6-sol", {"effort":"medium"}), seen)
        est = app.estimate_analysis(self.project, "project")
        self.assertEqual((est["model"], est["report_model"]), ("gpt-5.6-luna", "gpt-5.6-sol"))

    def test_access_check_and_truncated_answer(self):
        def ok(request, timeout):
            body = json.loads(request.data)
            self.assertEqual(body["reasoning"], {"effort":"low"})
            r = FakeResponse(); r.blob = json.dumps({"status":"completed", "model":body["model"],
                "output":[{"type":"reasoning","id":"x","summary":[]},
                          {"type":"message","content":[{"type":"output_text","text":"OK"}]}]}).encode(); return r
        self.assertTrue(app.check_ai(ok, model="gpt-5.6-sol")["ok"])
        def no_access(request, timeout):
            raise urllib.error.HTTPError("u", 404, "x", {}, io.BytesIO(b'{"error":{"code":"model_not_found"}}'))
        self.assertEqual(app.check_ai(no_access, model="gpt-5.6-sol")["stage"], "model")
        def truncated(request, timeout):
            r = FakeResponse(); r.blob = json.dumps({"status":"incomplete", "usage":{}, "output":[
                {"type":"reasoning","id":"x","summary":[]}]}).encode(); return r
        self.assertIn("limit długości", app.chat_ai(self.project, "Pytanie", [], truncated)["answer"])
        with patch.dict(os.environ, {"OPENAI_PRICE_GPT_5_6_SOL":"5,0.5,30"}):
            self.assertEqual(app.model_prices("gpt-5.6-sol"), (5.0, 0.5, 30.0))


class FullText511Tests(unittest.TestCase):
    """Mail Desk 5.11: full-text prefilter gives the same results as the full scan, only faster."""
    setUp = SearchEngine55Tests.setUp
    tearDown = SearchEngine55Tests.tearDown
    search = SearchEngine55Tests.search
    found = SearchEngine55Tests.found

    QUERIES = ["Kowalski", "Kowalskiemu", "ogrodzenia", "Łódź", "lodz", '"ofertę na ogrodzenie"',
               "od:kowalski", "do:comarch", "temat:faktura", "plik:cennik", "antracyt", "kowalski -montaz",
               "kowalski data:2024-01", "brama", "bauer | comarch", "leonardo | bauer", "ab", "bau",
               "-faktura", "x ogrodzenie", "zaun.de", "12/2024", "nieistniejace"]

    def ids_for(self, query, fts, inflect=True):
        parsed = app.parse_query(query, inflect)
        condition, params = app.query_condition(parsed, fts=fts)
        with app.connect() as db:
            return {r[0] for r in db.execute(f"SELECT message_id FROM mail_search WHERE {condition}", params)}

    def integrity_ok(self):
        with app.connect() as db:
            db.execute("INSERT INTO mail_fts(mail_fts, rank) VALUES('integrity-check', 1)")

    def test_index_is_built_and_results_are_identical(self):
        self.assertTrue(app.ensure_fts())
        self.assertTrue(app.fts_ready())
        for query in self.QUERIES:
            for inflect in (True, False):
                with self.subTest(query=query, inflect=inflect):
                    self.assertEqual(self.ids_for(query, True, inflect), self.ids_for(query, False, inflect))
        self.integrity_ok()

    def test_prefilter_is_used_only_when_it_can_help(self):
        app.ensure_fts()
        uses = lambda q: "mail_fts" in app.query_condition(app.parse_query(q, True))[0]
        self.assertTrue(uses("kowalski"))
        self.assertTrue(uses("temat:faktura"))
        self.assertTrue(uses("bauer | comarch"))
        self.assertFalse(uses("ab"))                 # fragment too short for the index
        self.assertFalse(uses("bauer | ab"))         # one alternative cannot use it
        self.assertFalse(uses("-faktura"))           # exclusion only
        self.assertTrue(uses("kowalski -montaz"))    # exclusion checked exactly afterwards
        self.assertEqual(self.found("kowalski -montaz"), {self.ids["kow"]})
        self.assertEqual(self.found("bauer | ab"), self.ids_for("bauer | ab", False))  # as in 5.10

    def test_index_follows_changes(self):
        app.ensure_fts()
        with app.connect() as db:
            m = {"message_id":"<new@t>","sender":"Nowy <n@aliplast.pl>","recipient":"g@tabal.pl","cc":"",
                 "subject":"Reklamacja","received":"2024-05-05T10:00:00+02:00","body":"Pierwsza wersja",
                 "attachments":"[]"}
            new_id, _ = app.save_message(db, "tabal", "new", "INBOX", m)
        self.assertEqual(self.found("aliplast"), {new_id})
        with app.connect() as db:
            app.index_attachment_record(db, new_id, 0, "protokol.pdf", "Uszkodzona brama przesuwna")
            app.refresh_search_row(db, new_id)
        self.assertIn(new_id, self.found('"brama przesuwna"'))
        with app.connect() as db:
            db.execute("DELETE FROM messages WHERE id=?", (new_id,))
            db.execute("DELETE FROM mail_search WHERE message_id NOT IN (SELECT id FROM messages)")
        self.assertEqual(self.found("aliplast"), set())
        self.integrity_ok()

    def test_database_from_5_10_gets_index_on_migration(self):
        with patch.dict(os.environ, {"MAILDESK_FTS": "0"}):
            self.assertFalse(app.ensure_fts())
            self.assertFalse(app.fts_ready())
            self.assertEqual(self.found("Kowalski"), {self.ids["kow"], self.ids["dat"]})
        self.assertFalse(app.fts_ready())  # 5.10 database: no index yet
        messages = []
        app.migrate_search_index(progress=messages.append)
        self.assertTrue(app.fts_ready())
        self.assertTrue(any("Buduję szybki indeks" in m for m in messages))
        self.assertEqual(self.found("Kowalski"), {self.ids["kow"], self.ids["dat"]})
        self.integrity_ok()

    def test_local_chat_ranking_uses_index_with_same_answer(self):
        app.relink_project(self.project["id"])
        with patch.dict(os.environ, {"MAILDESK_FTS": "0"}):
            before = app.project_search_sources(self.project["id"], "Ile maili od Kowalskiego o ogrodzeniu?")
        app.ensure_fts()
        after = app.project_search_sources(self.project["id"], "Ile maili od Kowalskiego o ogrodzeniu?")
        self.assertEqual([s["id"] for s in after[0]], [s["id"] for s in before[0]])
        self.assertEqual(after[1], before[1])


class Speed512Tests(unittest.TestCase):
    """5.12: small positionless index (same results), migration from 5.11, faster chat."""
    setUp = SearchEngine55Tests.setUp
    tearDown = SearchEngine55Tests.tearDown
    found = SearchEngine55Tests.found
    search = SearchEngine55Tests.search
    ids_for = FullText511Tests.ids_for

    def test_random_fragments_match_full_scan(self):
        import random
        rnd = random.Random(7)
        with app.connect() as db:
            for n in range(60):
                words = " ".join(rnd.choice(["Żaba", "panel 3D", "brama-przesuwna", "ZAM/2024/17", "o'connor", "x@y.pl",
                                             "dostawa", "120 zł", "Łódź", '"cytat"', "100%", "a_b", "kolor RAL 7016"])
                                 for _ in range(12))
                app.save_message(db, "tabal", f"rnd{n}", "INBOX", {"message_id":f"<rnd{n}@t>", "sender":f"K{n} <k{n}@f{n % 7}.pl>",
                    "recipient":"g@tabal.pl", "cc":"", "subject":f"Temat {n}", "received":"2024-04-04T10:00:00+02:00",
                    "body":words, "attachments":"[]"})
            hays = [r[0] for r in db.execute("SELECT hay FROM mail_search")]
        self.assertTrue(app.ensure_fts())
        checked = 0
        for _ in range(300):
            hay = rnd.choice(hays)
            start = rnd.randrange(0, max(1, len(hay) - 3))
            frag = hay[start:start + rnd.randint(3, 14)].strip()
            if len(frag) < 3 or "\n" in frag:
                continue
            query = '"' + frag.replace('"', "") + '"'
            if len(query) < 5:
                continue
            with self.subTest(fragment=frag):
                self.assertEqual(self.ids_for(query, True, False), self.ids_for(query, False, False))
            checked += 1
        self.assertGreater(checked, 200)

    def test_large_5_11_index_is_replaced_by_small_one(self):
        with app.connect() as db:
            db.executescript("""CREATE VIRTUAL TABLE mail_fts USING fts5(f_from, f_to, f_subject, f_files, hay,
                content='mail_search', content_rowid='message_id', tokenize='trigram');
                INSERT INTO mail_fts(mail_fts) VALUES('rebuild');""")
            db.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES ('fts_version','1')")
        self.assertFalse(app.fts_ready())
        messages = []
        app.migrate_search_index(progress=messages.append)
        self.assertTrue(app.fts_ready())
        self.assertTrue(any("5.11" in m for m in messages))
        with app.connect() as db:
            sql = db.execute("SELECT sql FROM sqlite_master WHERE name='mail_fts'").fetchone()[0]
            db.execute("INSERT INTO mail_fts(mail_fts, rank) VALUES('integrity-check', 1)")
        self.assertIn("detail='none'", sql)
        self.assertEqual(self.found("Kowalski"), {self.ids["kow"], self.ids["dat"]})
        self.assertEqual(self.found('"ofertę na ogrodzenie"'), {self.ids["kow"]})

    def test_no_rebuild_from_search_while_import_runs(self):
        app.fts_suspend()
        app.ARCHIVE_JOB["running"] = True
        try:
            self.assertEqual(self.found("Kowalski"), {self.ids["kow"], self.ids["dat"]})  # full scan, no rebuild
            self.assertFalse(app.fts_ready())
        finally:
            app.ARCHIVE_JOB["running"] = False
        self.found("Kowalski")
        self.assertTrue(app.fts_ready())

    def test_parallel_tools_and_live_progress(self):
        app.relink_project(self.project["id"])
        steps_seen = []
        class TwoTools(ScriptedChatModel):
            def __call__(self, request, timeout):
                body = json.loads(request.data)
                outs = [i for i in body["input"] if i.get("type") == "function_call_output"]
                if not outs:
                    return self.reply([self.call("search_mail", {"query":"kowalski", "date_from":"", "date_to":"", "limit":5}, 0),
                                       self.call("mail_stats", {"query":"kowalski", "date_from":"", "date_to":"", "group_by":"year"}, 1)])
                ids = re.findall(r'"id": (\d+)', outs[0]["output"])
                return self.reply([self.text(f"Kowalski pisał w 2024 r. [{ids[0]}].")])
        with patch.dict(os.environ, {"OPENAI_API_KEY":"sk-test-" + "x"*30}):
            r = app.chat_ai(self.project["id"], "Kiedy pisał Kowalski?", [], TwoTools(), progress=steps_seen.append)
        self.assertEqual([t.split(":")[0] for t in r["trace"]], ["szukano", "policzono"])
        self.assertTrue(r["sources"])
        self.assertTrue(any("szukano: kowalski" in s for steps in steps_seen for s in steps))
        # Background question with polling (what the page does).
        with patch.dict(os.environ, {"OPENAI_API_KEY":"sk-test-" + "x"*30}), \
             patch.object(app.urllib.request, "urlopen", TwoTools()):
            job = app.start_ask(self.project["id"], "Kiedy pisał Kowalski? (w tle)", "ai")["job"]
            for _ in range(200):
                st = app.ask_status(job)
                if not st["running"]:
                    break
                time.sleep(0.02)
        self.assertFalse(st["running"])
        self.assertEqual(st["error"], "")
        self.assertEqual(app.project_data(self.project["id"])["history"][-1]["question"], "Kiedy pisał Kowalski? (w tle)")
        self.assertTrue(any(s.startswith("szukano") for s in st["steps"]))


# ---------------------------------------------------------------------------
# 5.13: new mail every few minutes, replies (draft -> approve -> send), chat
# ---------------------------------------------------------------------------
class SentIMAP:
    """Fake IMAP server for the copy of a sent reply in the Sent folder."""
    appended = []
    def __init__(self, host, port, timeout=None):
        pass
    def login(self, user, password):
        pass
    def list(self):
        return "OK", [b'(\\HasNoChildren) "/" "INBOX"', b'(\\HasNoChildren \\Sent) "/" "Wys&AUI-ane"']
    def append(self, folder, flags, when, data):
        SentIMAP.appended.append((folder, flags, data))
        return "OK", [b"APPEND completed"]
    def logout(self):
        pass


class ReplySMTP:
    sent = []
    fail = None
    def __init__(self, host, port, timeout):
        self.host = host
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def starttls(self, context): pass
    def login(self, user, password):
        if ReplySMTP.fail:
            raise ReplySMTP.fail
    def send_message(self, msg):
        ReplySMTP.sent.append(msg)


def day_ago(n, hour=10):
    d = datetime.now(timezone.utc) - app.timedelta(days=n)
    return d.replace(hour=hour, minute=0, second=0, microsecond=0).isoformat()


class Refresh513Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        root = Path(self.temp.name)
        app.DB_PATH = root / "app" / "test.sqlite3"
        app.DB_PATH.parent.mkdir()
        app.connect().close()
        self.env = patch.dict(os.environ, {"TABAL_LOGIN":"", "TABAL_PASSWORD":"", "SKYFENS_LOGIN":"", "SKYFENS_PASSWORD":"",
                                           "MAILDESK_REFRESH_MINUTES":"5"})
        self.env.start()
        app.ARCHIVE_JOB.update({"running":False, "stop":False})
        app.REFRESH.update({"running":False, "seq":0, "new_ids":[], "last_error":"", "next_at":0.0, "checks":0})
        app._OWN.update(at=0.0, value=[])
        self.profile = root / "Profiles" / "abcd.default-release"
        self.acc = self.profile / "ImapMail" / "tabal.home.pl"
        write_mbox(self.acc / "INBOX", [tb_mail(n) for n in range(1, 11)])
        write_mbox(self.acc / "Sent", [tb_mail(100, sender="Grzegorz <gbartosik@tabal.pl>", subject="Re: Oferta nr 3")])
        app.run_thunderbird(str(self.profile), workers=1)
    def tearDown(self):
        self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()

    def append_mail(self, *mails):
        with open(self.acc / "INBOX", "ab") as f:
            f.write(b"".join(mails))
        os.utime(self.acc / "INBOX", (time.time() - 3600, time.time() - 3600))  # Thunderbird finished writing

    def test_new_thunderbird_mail_reaches_live_projects_and_page(self):
        live = app.create_project("Na bieżąco", "2024-01-01", app.date.today().isoformat(), "", "both", live=True)["id"]
        closed = app.create_project("Styczeń", "2024-01-01", "2024-01-31", "", "both")["id"]
        with app.connect() as db:   # a live project whose end date is old (program left open for days)
            db.execute("UPDATE projects SET date_to='2024-03-01' WHERE id=?", (live,))
        archive = int(app.get_setting("archive_project_id"))
        before = {p: app.project_data(p, include_messages=False)["total_messages"] for p in (live, closed, archive)}
        self.assertEqual(app.refresh_source(), "thunderbird")
        nothing = app.refresh_now("test")
        self.assertEqual((nothing["last_imported"], nothing["seq"]), (0, 0))
        self.append_mail(tb_mail(11, subject="Zapytanie o bramę przesuwną"), tb_mail(12))
        snap = app.refresh_now("test")
        self.assertEqual((snap["last_imported"], snap["seq"], snap["last_error"]), (2, 1, ""))
        after = {p: app.project_data(p, include_messages=False)["total_messages"] for p in (live, closed, archive)}
        self.assertEqual(after[live], before[live] + 2)
        self.assertEqual(after[archive], before[archive] + 2)
        self.assertEqual(after[closed], before[closed])                 # mails from February stay outside
        self.assertEqual(app.get_project(live)["date_to"], app.date.today().isoformat())
        latest = app.latest_mail(archive, 20)
        fresh = [m for m in latest["messages"] if m["fresh"]]
        self.assertEqual({m["subject"] for m in fresh}, {"Zapytanie o bramę przesuwną", "Oferta nr 12"})
        self.assertTrue(app.search_archive(archive, "przesuwn", date_from="", date_to="")["total"] == 1)
        # Thunderbird's Sent folder tells whose address is Grzegorz's -> answered flags.
        self.assertIn("gbartosik@tabal.pl", app.own_addresses())
        flags = {m["subject"]: m["answered"] for m in latest["messages"]}
        self.assertTrue(flags["Oferta nr 3"])
        self.assertFalse(flags["Oferta nr 5"])
        self.assertIsNone(flags["Re: Oferta nr 3"])                    # his own mail

    def test_loop_checks_on_schedule_and_settings(self):
        self.assertEqual(app.set_refresh_minutes(0)["minutes"], 0)
        with self.assertRaises(ValueError):
            app.set_refresh_minutes(999)
        self.assertEqual(app.set_refresh_minutes(2)["minutes"], 2)
        self.append_mail(tb_mail(13))
        stop = app.threading.Event()
        thread = app.threading.Thread(target=app.refresh_loop, kwargs={"first_delay":0, "stop":stop}, daemon=True)
        thread.start()
        for _ in range(300):
            if app.REFRESH["checks"]:
                break
            time.sleep(0.02)
        stop.set(); app.REFRESH_WAKE.set(); thread.join(5)
        self.assertEqual(app.REFRESH["last_imported"], 1)
        self.assertGreater(app.REFRESH["next_at"], time.time() + 60)    # next check in ~2 minutes
        # While another download runs, the check waits instead of colliding.
        app.ARCHIVE_JOB["running"] = True
        try:
            self.assertIn("Trwa inne pobieranie", app.refresh_now("test")["last_error"])
        finally:
            app.ARCHIVE_JOB["running"] = False

    def test_http_routes(self):
        server = app.ThreadingHTTPServer(("127.0.0.1", 0), app.Handler)
        port = server.server_address[1]
        app.threading.Thread(target=server.serve_forever, daemon=True).start()
        def call(path, data=None):
            req = app.urllib.request.Request(f"http://127.0.0.1:{port}{path}", method="POST" if data is not None else "GET",
                                             data=json.dumps(data).encode() if data is not None else None,
                                             headers={"Content-Type":"application/json"})
            with app.urllib.request.urlopen(req, timeout=10) as r:
                return json.load(r)
        try:
            self.assertEqual(call("/api/refresh/status")["minutes"], 5)
            self.assertEqual(call("/api/refresh/settings", {"minutes":10})["minutes"], 10)
            archive = int(app.get_setting("archive_project_id"))
            latest = call(f"/api/project/latest?id={archive}&limit=3")
            self.assertEqual(len(latest["messages"]), 3)
            mid = latest["messages"][0]["id"]
            msg = call(f"/api/message?id={mid}")
            self.assertIn("replies", msg); self.assertIn("thread", msg)
            r = call("/api/reply/create", {"message_id":mid, "body":"Dzień dobry,\n\ndziękuję.\n\nPozdrawiam,"})
            self.assertEqual(r["status"], "szkic")
            self.assertEqual(call("/api/replies/pending")["replies"][0]["id"], r["id"])
            self.assertEqual(call(f"/api/unanswered?id={archive}&days=90")["since"],
                             (app.date.today() - app.timedelta(days=90)).isoformat())
            self.assertTrue(call("/api/reply/delete", {"id":r["id"]})["deleted"])
        finally:
            server.shutdown(); server.server_close()


class Reply513Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = app.DB_PATH
        app.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        app.connect().close()
        self.env = patch.dict(os.environ, {"TABAL_LOGIN":"gbartosik@tabal.pl", "TABAL_PASSWORD":"fake-test-password",
                                           "TABAL_IMAP_HOST":"imap.example.org", "TABAL_SMTP_HOST":"smtp.example.org",
                                           "TABAL_SMTP_PORT":"587", "TABAL_SMTP_SECURITY":"starttls",
                                           "OPENAI_API_KEY":"", "OPENAI_CHAT_MODEL":"gpt-4.1"})
        self.env.start()
        app._OWN.update(at=0.0, value=[])
        ReplySMTP.sent, ReplySMTP.fail, SentIMAP.appended = [], None, []
        self.sleep = patch.object(app.time, "sleep", lambda s: None); self.sleep.start()
        mails = [
            ("<a1@k>", "Jan Kowalski <jan@budimex.pl>", "gbartosik@tabal.pl", "Anna Nowak <anna@budimex.pl>",
             "Zapytanie o ogrodzenie panelowe", day_ago(3), "Proszę o wycenę 120 mb ogrodzenia, kolor antracyt."),
            ("<a2@k>", "Grzegorz Bartosik <gbartosik@tabal.pl>", "jan@budimex.pl", "",
             "Re: Zapytanie o ogrodzenie panelowe", day_ago(2), "Dzień dobry, wycena w załączniku."),
            ("<a3@k>", "Jan Kowalski <jan@budimex.pl>", "gbartosik@tabal.pl", "",
             "Odp: Zapytanie o ogrodzenie panelowe", day_ago(1), "Dziękuję. Kiedy możliwy montaż?"),
            ("<b1@k>", "Peter Bauer <pb@bauer.de>", "gbartosik@tabal.pl", "",
             "Angebot Schiebetor", day_ago(5), "Bitte um ein Angebot für ein Schiebetor 5 m."),
            ("<c1@k>", "Newsletter <noreply@sklep.pl>", "gbartosik@tabal.pl", "", "Promocja", day_ago(1), "Rabaty!"),
        ]
        self.ids = {}
        with app.connect() as db:
            for mid, sender, to, cc, subject, when, body in mails:
                m = {"message_id":mid, "sender":sender, "recipient":to, "cc":cc, "subject":subject, "received":when,
                     "body":body, "attachments":"[]"}
                folder = "Sent" if "gbartosik" in sender else "INBOX"
                self.ids[mid], _ = app.save_message(db, "tabal", mid.strip("<>"), folder, m)
        self.project = app.create_project("Bieżące", (app.date.today() - app.timedelta(days=30)).isoformat(),
                                          app.date.today().isoformat(), "", "tabal", live=True)["id"]
    def tearDown(self):
        self.sleep.stop(); self.env.stop()
        app.DB_PATH = self.old_db
        self.temp.cleanup()

    def test_unanswered_mails(self):
        r = app.unanswered_mails(self.project, 14)
        subjects = [x["subject"] for x in r["results"]]
        # Kowalski asked again after Grzegorz's answer -> waiting; Bauer never answered; newsletter skipped.
        self.assertEqual(subjects, ["Odp: Zapytanie o ogrodzenie panelowe", "Angebot Schiebetor"])
        self.assertEqual(r["results"][1]["days_waiting"], 5)
        self.assertEqual(app.unanswered_mails(self.project, 14, "bauer")["total"], 1)
        self.assertEqual(app.unanswered_mails(self.project, 2)["total"], 1)

    def test_draft_approve_send_and_safety_checks(self):
        mid = self.ids["<a3@k>"]
        app.set_reply_signature("tabal", "Grzegorz Bartosik\nTABAL")
        r = app.create_reply(mid, "Dzień dobry,\n\nmontaż możliwy od [[data]].\n\nPozdrawiam,", reply_all=True)
        self.assertEqual(r["to_addr"], "Jan Kowalski <jan@budimex.pl>")
        self.assertEqual(r["subject"], "Odp: Zapytanie o ogrodzenie panelowe")
        self.assertTrue(r["body"].endswith("Grzegorz Bartosik\nTABAL"))
        self.assertIn("placeholder", {w["code"] for w in r["warnings"]})
        with self.assertRaises(ValueError):                        # [[...]] must be filled in first
            app.approve_reply(r["id"], {})
        body = r["body"].replace("[[data]]", "15 listopada")
        with self.assertRaises(ValueError):                        # not approved yet
            app.send_reply(r["id"], "", True, ReplySMTP, ReplySMTP, SentIMAP)
        with self.assertRaises(ValueError):                        # address from outside the thread needs a tick
            app.approve_reply(r["id"], {"body":body, "cc":"Anna Nowak <anna@budimex.pl>, obcy@gmail.com"})
        a = app.approve_reply(r["id"], {"body":body, "cc":"Anna Nowak <anna@budimex.pl>, obcy@gmail.com"}, acknowledge=True)
        self.assertEqual(a["status"], "zatwierdzony")
        # Any change after approval sends it back to draft; the old approval no longer works.
        edited = app.update_reply(r["id"], {"cc":"Anna Nowak <anna@budimex.pl>"})
        self.assertEqual(edited["status"], "szkic")
        with self.assertRaises(ValueError):
            app.send_reply(r["id"], a["approved_hash"], True, ReplySMTP, ReplySMTP, SentIMAP)
        a = app.approve_reply(r["id"], {})
        self.assertEqual(app.update_reply(r["id"], {"body":body})["status"], "zatwierdzony")  # same text: still approved
        with self.assertRaises(ValueError):
            app.send_reply(r["id"], a["approved_hash"], False, ReplySMTP, ReplySMTP, SentIMAP)
        sent = app.send_reply(r["id"], a["approved_hash"], True, ReplySMTP, ReplySMTP, SentIMAP)
        self.assertEqual((sent["status"], sent["saved_to_sent"]), ("wysłany", "Wysłane"))
        mail = ReplySMTP.sent[0]
        self.assertEqual((mail["To"], mail["Cc"], mail["In-Reply-To"]), ("Jan Kowalski <jan@budimex.pl>",
                                                                         "Anna Nowak <anna@budimex.pl>", "<a3@k>"))
        text = mail.get_content()
        self.assertIn("montaż możliwy od 15 listopada", text)
        self.assertIn("> Dziękuję. Kiedy możliwy montaż?", text)   # quoted original
        self.assertEqual(SentIMAP.appended[0][0], "Wys&AUI-ane")
        with self.assertRaises(ValueError):                        # never twice
            app.send_reply(r["id"], a["approved_hash"], True, ReplySMTP, ReplySMTP, SentIMAP)
        with self.assertRaises(ValueError):
            app.update_reply(r["id"], {"body":"x"})
        # The sent mail is in the archive at once, so the conversation counts as answered.
        self.assertEqual([x["subject"] for x in app.unanswered_mails(self.project, 14)["results"]], ["Angebot Schiebetor"])
        self.assertEqual(len(ReplySMTP.sent), 1)

    def test_failed_send_is_reported_and_can_be_retried(self):
        r = app.create_reply(self.ids["<b1@k>"], "Sehr geehrter Herr Bauer,\n\nAngebot folgt.\n\nMit freundlichen Grüßen,")
        a = app.approve_reply(r["id"], {})
        ReplySMTP.fail = app.smtplib.SMTPAuthenticationError(535, b"bad")
        with self.assertRaises(RuntimeError) as ctx:
            app.send_reply(r["id"], a["approved_hash"], True, ReplySMTP, ReplySMTP, SentIMAP)
        self.assertIn("login lub hasło", str(ctx.exception))
        self.assertEqual(app.reply_get(r["id"])["status"], "błąd")
        ReplySMTP.fail = None
        a = app.approve_reply(r["id"], {})
        self.assertEqual(app.send_reply(r["id"], a["approved_hash"], True, ReplySMTP, ReplySMTP, SentIMAP)["status"], "wysłany")
        with app.connect() as db:
            self.assertIn("SMTP", db.execute("SELECT operation FROM mail_errors").fetchone()[0])

    def test_ai_draft_reads_thread_and_improves_draft(self):
        requests = []
        def fake(request, timeout):
            body = json.loads(request.data)
            requests.append(body)
            ctx = json.loads(body["input"])
            text = ("Sehr geehrter Herr Bauer,\n\ndas Angebot schicken wir bis [[Datum]].\n\nMit freundlichen Grüßen,"
                    if "current_draft" not in ctx else "Sehr geehrter Herr Bauer,\n\ndas Angebot folgt morgen.\n\nMit freundlichen Grüßen,")
            r = FakeResponse()
            r.blob = json.dumps({"usage":{"input_tokens":900, "output_tokens":120}, "output":[{"type":"message", "content":[
                {"type":"output_text", "text":json.dumps({"body":text, "missing":["Datum"], "language":"de"})}]}]}).encode()
            return r
        # Without a key: a template with a gap to fill in (nothing is invented).
        t = app.draft_reply_ai(self.ids["<b1@k>"])
        self.assertEqual((t["source"], t["missing"]), ("szablon", ["treść odpowiedzi"]))
        with patch.dict(os.environ, {"OPENAI_API_KEY":"sk-test-" + "x"*30}):
            app.set_reply_signature("tabal", "Grzegorz Bartosik")
            d = app.draft_reply_ai(self.ids["<a3@k>"], "napisz że montaż w listopadzie", "rzeczowy", "auto",
                                   opener=fake)
            ctx = json.loads(requests[0]["input"])
            self.assertEqual([m["subject"] for m in ctx["thread"]], ["Zapytanie o ogrodzenie panelowe",
                                                                     "Re: Zapytanie o ogrodzenie panelowe"])
            self.assertIn("rzeczowy", requests[0]["instructions"])
            self.assertEqual(requests[0]["model"], "gpt-4.1")
            self.assertEqual((d["source"], d["missing"], d["status"]), ("ai", ["Datum"], "szkic"))
            self.assertTrue(d["body"].endswith("Grzegorz Bartosik"))
            self.assertGreater(d["cost_usd"], 0)
            better = app.draft_reply_ai(self.ids["<a3@k>"], "konkretna data: jutro", reply_id=d["id"], opener=fake)
            self.assertEqual(better["id"], d["id"])
            self.assertIn("folgt morgen", better["body"])
            self.assertNotIn("Grzegorz Bartosik", json.loads(requests[1]["input"])["current_draft"])  # signature kept aside
            self.assertEqual(better["body"].count("Grzegorz Bartosik"), 1)
        self.assertFalse(ReplySMTP.sent)

    def test_chat_prepares_draft_with_pinned_mail_and_can_stop(self):
        mid = self.ids["<b1@k>"]
        class Drafting(ScriptedChatModel):
            def __call__(self, request, timeout):
                body = json.loads(request.data)
                self.requests.append(body)
                outs = [json.loads(i["output"]) for i in body["input"] if i.get("type") == "function_call_output"]
                if not outs:
                    return self.reply([self.call("save_reply_draft", {"message_id":mid, "reply_all":False,
                        "body":"Sehr geehrter Herr Bauer,\n\nvielen Dank.\n\nMit freundlichen Grüßen,"}, 0)])
                return self.reply([self.text(f"Szkic zapisany [{mid}] – czeka na zatwierdzenie.")])
        fake = Drafting()
        with patch.dict(os.environ, {"OPENAI_API_KEY":"sk-test-" + "x"*30}):
            r = app.ask_project(self.project, "Przygotuj odpowiedź po niemiecku", "ai", opener=fake, focus_ids=[mid])
        pinned = [i for i in fake.requests[0]["input"] if i.get("role") == "user"][0]["content"]
        self.assertIn("Schiebetor", pinned)
        self.assertIn("gbartosik@tabal.pl", fake.requests[0]["instructions"])
        self.assertEqual(len(r["drafts"]), 1)
        self.assertEqual(r["sources"], [mid])
        data = app.project_data(self.project)
        turn = data["history"][-1]
        self.assertEqual((turn["drafts"], turn["focus"]), (r["drafts"], [mid]))
        self.assertEqual(data["draft_info"][str(r["drafts"][0])]["status"], "szkic")
        self.assertEqual(data["meta"][str(mid)]["f"], "Peter Bauer")
        self.assertFalse(ReplySMTP.sent)
        with patch.dict(os.environ, {"OPENAI_API_KEY":"sk-test-" + "x"*30}):
            with self.assertRaises(app.ChatStopped):
                app.ask_project(self.project, "Coś", "ai", opener=Drafting(), should_stop=lambda: True)


if __name__ == "__main__":
    unittest.main()
