# Mail Desk 5.0 — TABAL i Skyfens

Lokalny prototyp dla Grzegorza. Obsługuje wyłącznie skrzynki TABAL i Skyfens. Nie ma dostępu do prywatnego Gmaila Marcina ani jego zapisanych zadań. Program działa na komputerze Grzegorza pod `http://127.0.0.1:8765`; wymaga Pythona 3.10+ i nie instaluje dodatkowych bibliotek. Projekty, wiadomości i historia pytań są w `maildesk.sqlite3`. Hasła i klucz API są w lokalnym `.env.local` (uprawnienia pliku 0600). ZIP nie zawiera tych plików.

## Mac — uruchomienie

1. Rozpakuj ZIP do własnego folderu. Otwórz Terminal, wpisz `sh ` (ze spacją), przeciągnij plik `start_mac_linux.sh` z folderu programu i naciśnij Enter.
2. Program spróbuje otworzyć przeglądarkę sam. Jeśli nie otworzy, wpisz `http://127.0.0.1:8765`.
3. Terminal pozostaw otwarty. Aby zakończyć pracę, użyj `Ctrl+C`. Na Windows uruchom `start_windows.bat`.

## Skrzynki firmowe

Otwórz **Konfiguracja kont i AI**. Do TABAL i Skyfens wpisz pełne loginy i hasła od administratora i kliknij **Zapisz i sprawdź**. Możesz na próbę użyć kont `martin@tabal.pl` / `martin@skyfens.pl`, jeśli administrator dał Ci do nich uprawnienia. Docelowe konta Grzegorza to `gbartosik@tabal.pl` i `grzegorz.bartosik@skyfens.pl`. Nie wpisuj cudzego loginu bez hasła i uprawnienia. Po pobraniu maili zmiana loginu tej samej skrzynki jest blokowana, aby nie pomieszać UID i wiadomości różnych osób. Do przejścia z kont testowych na właściwe rozpakuj nowy ZIP w **osobnym folderze** i wpisz tam nowe loginy i hasła.

Serwery są ustawione według danych Darka: TABAL IMAP `tabal.home.pl:993` SSL/TLS, SMTP `tabal.home.pl:465` SSL/TLS; Skyfens IMAP `mail.skyfens.pl:993` SSL/TLS, SMTP `mail.skyfens.pl:587` STARTTLS. Wynik **dane wpisane** nie oznacza jeszcze udanego połączenia — użyj przycisków sprawdzających IMAP.

## Płatny GPT dla TABAL

Do działania AI potrzebny jest **osobny projekt w OpenAI API**, z rozliczeniem firmy TABAL. Abonament ChatGPT nie opłaca API. Osoba uprawniona w TABAL zakłada konto na [platform.openai.com](https://platform.openai.com/), tworzy projekt, dodaje metodę płatności lub środki API oraz generuje klucz tego projektu. Warto ustawić mały budżet i powiadomienia o wykorzystaniu. Klucza nie trzeba przesyłać Marcinowi ani mailem do Grzegorza: najlepiej wprowadzić go bezpośrednio na komputerze, na którym działa aplikacja.

W **Konfiguracja kont i AI** wklej klucz `sk-...` i kliknij **Zapisz i sprawdź GPT-4.1 mini**. Test wysyła jedno krótkie żądanie bez treści maili. Dopiero komunikat o poprawnej odpowiedzi potwierdza, że klucz, model i środki działają. Błąd HTTP 401 oznacza problem z kluczem; `credit_balance_exhausted` / HTTP 429 oznacza brak dostępnych środków projektu. Zmiana klucza w panelu działa od razu, bez restartu.

**Zapytaj AI** i **Analizuj przez AI** przesyłają do API nadawcę, datę, temat i tekst wybranych maili (bez binarnych załączników). Przed uruchomieniem na właściwych skrzynkach TABAL powinien zaakceptować ten przepływ danych. Tryb **Szukaj lokalnie** i **Analizuj lokalnie (reguły)** działa bez klucza; to wyszukiwanie fragmentów i proste reguły, nie GPT.

## Scenariusz testowy

1. Najpierw utwórz projekt „Test PoC”, wybierz daty, pusty filtr nadawcy i skrzynkę TABAL. Bez podłączonej poczty kliknij **Dodaj przykłady**.
2. Wybierz przykładową wiadomość i **Analizuj lokalnie (reguły)**. Przykładowych wiadomości program nie wyśle.
3. W zakładce **Rozmowa** wpisz „Jakie terminy padły w mailach?” i wybierz **Szukaj lokalnie**. Otwórz źródło. Po zapisaniu pytania kliknij w historii **Użyj ponownie**, aby wstawić je z powrotem do pola pisania.
4. Po udanym teście IMAP utwórz nowy projekt dla TABAL lub Skyfens, z zakresem kilku dni i filtrem nadawcy. Kliknij **Pobierz z poczty**. Pobieranych jest najwyżej 100 najnowszych maili z zakresu (maks. 2 MB każdy), bez duplikatów.
5. Po udanym teście GPT kliknij **Zapytaj AI** w projekcie lub **Analizuj przez AI** przy mailu. Sprawdź źródła i treść szkicu. Wysyłka SMTP jest możliwa dopiero po edycji, zaznaczeniu potwierdzenia oraz dodatkowym potwierdzeniu w oknie; nie jest automatyczna. Na start wyślij ewentualną odpowiedź tylko na uzgodniony adres testowy.
6. Zamknij stronę, uruchom ją ponownie i sprawdź, czy projekt i pytania są na liście po lewej.

Błędy IMAP/SMTP są dostępne w **Dzienniku błędów poczty**; znane hasła i klucz są usuwane z zapisanych komunikatów. Nie udostępniaj `.env.local` ani `maildesk.sqlite3` osobom spoza uprawnionego zespołu.

## Kontrola techniczna

`python3 -m unittest discover -s tests -v` uruchamia testy bez rzeczywistych haseł. Testy symulują IMAP, SMTP i odpowiedzi API. Rzeczywiste logowanie firmowych kont i model GPT należy potwierdzić na komputerze Grzegorza po wpisaniu jego danych i uruchomieniu rozliczeń API.
